--
-- PostgreSQL database dump
--

\restrict h4GYfCR4xqn4Ewnw8nw7OMauOG2eGPrFp37zBnJRJt3SZwbLUW1oyjwQDp0Zaz0

-- Dumped from database version 17.9 (Debian 17.9-0+deb13u1)
-- Dumped by pg_dump version 17.9 (Debian 17.9-0+deb13u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: addresses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.addresses (
    id bigint NOT NULL,
    line_1 character varying(200),
    line_2 character varying(200),
    village character varying(100),
    district character varying(100),
    regency character varying(100),
    province character varying(100),
    postal_code character varying(10),
    latitude numeric(10,7),
    longitude numeric(10,7),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: addresses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.addresses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: addresses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.addresses_id_seq OWNED BY public.addresses.id;


--
-- Name: advocacy_actions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.advocacy_actions (
    id bigint NOT NULL,
    advocacy_program_id bigint NOT NULL,
    action_date date NOT NULL,
    action_type character varying(255) NOT NULL,
    notes text,
    outcome text,
    created_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT advocacy_actions_action_type_check CHECK (((action_type)::text = ANY ((ARRAY['meeting'::character varying, 'training'::character varying, 'campaign'::character varying, 'field_visit'::character varying, 'legal'::character varying, 'other'::character varying])::text[])))
);


--
-- Name: advocacy_actions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.advocacy_actions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: advocacy_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.advocacy_actions_id_seq OWNED BY public.advocacy_actions.id;


--
-- Name: advocacy_programs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.advocacy_programs (
    id bigint NOT NULL,
    program_code character varying(30) NOT NULL,
    title character varying(200) NOT NULL,
    description text NOT NULL,
    status character varying(255) DEFAULT 'planned'::character varying NOT NULL,
    start_date date,
    end_date date,
    lead_user_id bigint,
    location_text character varying(200),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    CONSTRAINT advocacy_programs_status_check CHECK (((status)::text = ANY ((ARRAY['planned'::character varying, 'active'::character varying, 'paused'::character varying, 'completed'::character varying])::text[])))
);


--
-- Name: advocacy_programs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.advocacy_programs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: advocacy_programs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.advocacy_programs_id_seq OWNED BY public.advocacy_programs.id;


--
-- Name: agrarian_case_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agrarian_case_files (
    id bigint NOT NULL,
    agrarian_case_id bigint NOT NULL,
    file_category character varying(80),
    label character varying(150),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: agrarian_case_files_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agrarian_case_files_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agrarian_case_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agrarian_case_files_id_seq OWNED BY public.agrarian_case_files.id;


--
-- Name: agrarian_case_parties; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agrarian_case_parties (
    id bigint NOT NULL,
    agrarian_case_id bigint NOT NULL,
    party_type character varying(255) NOT NULL,
    name character varying(200) NOT NULL,
    role character varying(150),
    contact character varying(150),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT agrarian_case_parties_party_type_check CHECK (((party_type)::text = ANY ((ARRAY['member'::character varying, 'community'::character varying, 'institution'::character varying, 'company'::character varying, 'government'::character varying, 'other'::character varying])::text[])))
);


--
-- Name: agrarian_case_parties_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agrarian_case_parties_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agrarian_case_parties_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agrarian_case_parties_id_seq OWNED BY public.agrarian_case_parties.id;


--
-- Name: agrarian_case_updates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agrarian_case_updates (
    id bigint NOT NULL,
    agrarian_case_id bigint NOT NULL,
    update_date date NOT NULL,
    summary text NOT NULL,
    next_step text,
    status character varying(255) NOT NULL,
    created_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT agrarian_case_updates_status_check CHECK (((status)::text = ANY ((ARRAY['reported'::character varying, 'under_review'::character varying, 'mediation'::character varying, 'legal_process'::character varying, 'resolved'::character varying, 'closed'::character varying])::text[])))
);


--
-- Name: agrarian_case_updates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agrarian_case_updates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agrarian_case_updates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agrarian_case_updates_id_seq OWNED BY public.agrarian_case_updates.id;


--
-- Name: agrarian_cases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agrarian_cases (
    id bigint NOT NULL,
    case_code character varying(30) NOT NULL,
    title character varying(200) NOT NULL,
    summary text NOT NULL,
    description text NOT NULL,
    location_text character varying(200),
    start_date date NOT NULL,
    status character varying(255) DEFAULT 'reported'::character varying NOT NULL,
    priority character varying(255) DEFAULT 'medium'::character varying NOT NULL,
    lead_user_id bigint,
    created_by bigint,
    updated_by bigint,
    closed_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    CONSTRAINT agrarian_cases_priority_check CHECK (((priority)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying, 'urgent'::character varying])::text[]))),
    CONSTRAINT agrarian_cases_status_check CHECK (((status)::text = ANY ((ARRAY['reported'::character varying, 'under_review'::character varying, 'mediation'::character varying, 'legal_process'::character varying, 'resolved'::character varying, 'closed'::character varying])::text[])))
);


--
-- Name: agrarian_cases_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agrarian_cases_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agrarian_cases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agrarian_cases_id_seq OWNED BY public.agrarian_cases.id;


--
-- Name: article_generation_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.article_generation_logs (
    id bigint NOT NULL,
    article_topic_id bigint,
    article_pool_id bigint,
    post_id bigint,
    status character varying(30) DEFAULT 'queued'::character varying NOT NULL,
    ai_provider character varying(50),
    ai_model character varying(80),
    prompt_used text,
    raw_response text,
    tokens_used integer,
    generation_time_ms integer,
    error_message text,
    triggered_by character varying(30) DEFAULT 'scheduler'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: article_generation_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.article_generation_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: article_generation_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.article_generation_logs_id_seq OWNED BY public.article_generation_logs.id;


--
-- Name: article_pool_topic; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.article_pool_topic (
    article_pool_id bigint NOT NULL,
    article_topic_id bigint NOT NULL
);


--
-- Name: article_pools; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.article_pools (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(120) NOT NULL,
    description text,
    schedule_frequency character varying(30) DEFAULT 'weekly'::character varying NOT NULL,
    schedule_day character varying(10),
    schedule_time time(0) without time zone DEFAULT '07:00:00'::time without time zone NOT NULL,
    articles_per_run smallint DEFAULT '1'::smallint NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    auto_publish boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: article_pools_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.article_pools_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: article_pools_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.article_pools_id_seq OWNED BY public.article_pools.id;


--
-- Name: article_topic_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.article_topic_tags (
    article_topic_id bigint NOT NULL,
    tag_id bigint NOT NULL
);


--
-- Name: article_topics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.article_topics (
    id bigint NOT NULL,
    title character varying(200) NOT NULL,
    slug character varying(200) NOT NULL,
    description text,
    thinking_framework character varying(100) DEFAULT 'marxist'::character varying NOT NULL,
    article_type character varying(50) DEFAULT 'essay'::character varying NOT NULL,
    key_references json,
    prompt_template text NOT NULL,
    weight integer DEFAULT 50 NOT NULL,
    max_uses integer,
    times_used integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    category_id bigint,
    created_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


--
-- Name: article_topics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.article_topics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: article_topics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.article_topics_id_seq OWNED BY public.article_topics.id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id bigint NOT NULL,
    actor_id bigint,
    action character varying(120) NOT NULL,
    subject_type character varying(120) NOT NULL,
    subject_id bigint NOT NULL,
    meta json,
    created_at timestamp(0) without time zone
);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: cache; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cache (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    expiration integer NOT NULL
);


--
-- Name: cache_locks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cache_locks (
    key character varying(255) NOT NULL,
    owner character varying(255) NOT NULL,
    expiration integer NOT NULL
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(120) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    color character varying(20),
    icon character varying(60),
    description text
);


--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: event_attendance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_attendance (
    id bigint NOT NULL,
    event_id bigint NOT NULL,
    member_id bigint NOT NULL,
    attendance_status character varying(255) DEFAULT 'present'::character varying NOT NULL,
    notes character varying(200),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT event_attendance_attendance_status_check CHECK (((attendance_status)::text = ANY ((ARRAY['present'::character varying, 'absent'::character varying, 'excused'::character varying])::text[])))
);


--
-- Name: event_attendance_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.event_attendance_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: event_attendance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.event_attendance_id_seq OWNED BY public.event_attendance.id;


--
-- Name: events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.events (
    id bigint NOT NULL,
    title character varying(200) NOT NULL,
    description text NOT NULL,
    event_date timestamp(0) without time zone NOT NULL,
    location_text character varying(200),
    status character varying(255) DEFAULT 'planned'::character varying NOT NULL,
    organizer_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    CONSTRAINT events_status_check CHECK (((status)::text = ANY ((ARRAY['planned'::character varying, 'done'::character varying, 'canceled'::character varying])::text[])))
);


--
-- Name: events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.events_id_seq OWNED BY public.events.id;


--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: gallery_albums; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gallery_albums (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    event_date date,
    location character varying(255),
    status character varying(255) DEFAULT 'draft'::character varying NOT NULL,
    published_at timestamp(0) without time zone,
    author_id bigint,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


--
-- Name: gallery_albums_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gallery_albums_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gallery_albums_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gallery_albums_id_seq OWNED BY public.gallery_albums.id;


--
-- Name: gallery_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gallery_items (
    id bigint NOT NULL,
    gallery_album_id bigint NOT NULL,
    type character varying(255) DEFAULT 'photo'::character varying NOT NULL,
    title character varying(255),
    caption text,
    video_url character varying(255),
    video_platform character varying(255),
    credit character varying(255),
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: gallery_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gallery_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gallery_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gallery_items_id_seq OWNED BY public.gallery_items.id;


--
-- Name: job_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.job_batches (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    total_jobs integer NOT NULL,
    pending_jobs integer NOT NULL,
    failed_jobs integer NOT NULL,
    failed_job_ids text NOT NULL,
    options text,
    cancelled_at integer,
    created_at integer NOT NULL,
    finished_at integer
);


--
-- Name: jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.jobs (
    id bigint NOT NULL,
    queue character varying(255) NOT NULL,
    payload text NOT NULL,
    attempts smallint NOT NULL,
    reserved_at integer,
    available_at integer NOT NULL,
    created_at integer NOT NULL
);


--
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.jobs_id_seq OWNED BY public.jobs.id;


--
-- Name: media; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.media (
    id bigint NOT NULL,
    model_type character varying(255) NOT NULL,
    model_id bigint NOT NULL,
    uuid uuid,
    collection_name character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    file_name character varying(255) NOT NULL,
    mime_type character varying(255),
    disk character varying(255) NOT NULL,
    conversions_disk character varying(255),
    size bigint NOT NULL,
    manipulations json NOT NULL,
    custom_properties json NOT NULL,
    generated_conversions json NOT NULL,
    responsive_images json NOT NULL,
    order_column integer,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: media_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.media_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: media_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.media_id_seq OWNED BY public.media.id;


--
-- Name: member_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_documents (
    id bigint NOT NULL,
    member_id bigint NOT NULL,
    document_type character varying(255) NOT NULL,
    title character varying(150),
    issued_at date,
    expires_at date,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT member_documents_document_type_check CHECK (((document_type)::text = ANY ((ARRAY['ktp'::character varying, 'kk'::character varying, 'card'::character varying, 'other'::character varying])::text[])))
);


--
-- Name: member_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_documents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: member_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_documents_id_seq OWNED BY public.member_documents.id;


--
-- Name: members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.members (
    id bigint NOT NULL,
    user_id bigint,
    member_code character varying(30) NOT NULL,
    full_name character varying(150) NOT NULL,
    gender character varying(255) NOT NULL,
    birth_place character varying(100),
    birth_date date,
    nik character varying(32),
    phone character varying(30),
    email character varying(150),
    address_id bigint,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    joined_at date,
    approved_at timestamp(0) without time zone,
    notes text,
    created_by bigint,
    updated_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    rejected_at timestamp(0) without time zone,
    rejection_reason text,
    approved_by bigint,
    CONSTRAINT members_gender_check CHECK (((gender)::text = ANY ((ARRAY['male'::character varying, 'female'::character varying, 'other'::character varying])::text[]))),
    CONSTRAINT members_status_check CHECK (((status)::text = ANY (ARRAY[('pending'::character varying)::text, ('active'::character varying)::text, ('inactive'::character varying)::text, ('resigned'::character varying)::text, ('deceased'::character varying)::text, ('rejected'::character varying)::text])))
);


--
-- Name: members_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.members_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.members_id_seq OWNED BY public.members.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: model_has_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_has_permissions (
    permission_id bigint NOT NULL,
    model_type character varying(255) NOT NULL,
    model_id bigint NOT NULL
);


--
-- Name: model_has_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_has_roles (
    role_id bigint NOT NULL,
    model_type character varying(255) NOT NULL,
    model_id bigint NOT NULL
);


--
-- Name: pages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pages (
    id bigint NOT NULL,
    title character varying(200) NOT NULL,
    slug character varying(200) NOT NULL,
    body text NOT NULL,
    status character varying(255) DEFAULT 'draft'::character varying NOT NULL,
    published_at timestamp(0) without time zone,
    author_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    meta_description character varying(300),
    CONSTRAINT pages_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'published'::character varying, 'archived'::character varying])::text[])))
);


--
-- Name: pages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pages_id_seq OWNED BY public.pages.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permissions (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    guard_name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: post_category; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.post_category (
    post_id bigint NOT NULL,
    category_id bigint NOT NULL
);


--
-- Name: post_tag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.post_tag (
    post_id bigint NOT NULL,
    tag_id bigint NOT NULL
);


--
-- Name: posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.posts (
    id bigint NOT NULL,
    title character varying(200) NOT NULL,
    slug character varying(200) NOT NULL,
    excerpt text,
    body text NOT NULL,
    status character varying(255) DEFAULT 'draft'::character varying NOT NULL,
    published_at timestamp(0) without time zone,
    author_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    source_type character varying(20) DEFAULT 'manual'::character varying NOT NULL,
    article_topic_id bigint,
    generation_log_id bigint,
    ai_disclosure boolean DEFAULT false NOT NULL,
    CONSTRAINT posts_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'published'::character varying, 'archived'::character varying])::text[])))
);


--
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.posts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.posts_id_seq OWNED BY public.posts.id;


--
-- Name: role_has_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_has_permissions (
    permission_id bigint NOT NULL,
    role_id bigint NOT NULL
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    guard_name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id character varying(255) NOT NULL,
    user_id bigint,
    ip_address character varying(45),
    user_agent text,
    payload text NOT NULL,
    last_activity integer NOT NULL
);


--
-- Name: site_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.site_settings (
    id bigint NOT NULL,
    setting_key character varying(120) NOT NULL,
    setting_value text,
    group_name character varying(80),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: site_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.site_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: site_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.site_settings_id_seq OWNED BY public.site_settings.id;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tags (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(120) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: tags_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tags_id_seq OWNED BY public.tags.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    remember_token character varying(100),
    is_active boolean DEFAULT true NOT NULL,
    last_login_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: addresses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.addresses ALTER COLUMN id SET DEFAULT nextval('public.addresses_id_seq'::regclass);


--
-- Name: advocacy_actions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.advocacy_actions ALTER COLUMN id SET DEFAULT nextval('public.advocacy_actions_id_seq'::regclass);


--
-- Name: advocacy_programs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.advocacy_programs ALTER COLUMN id SET DEFAULT nextval('public.advocacy_programs_id_seq'::regclass);


--
-- Name: agrarian_case_files id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_case_files ALTER COLUMN id SET DEFAULT nextval('public.agrarian_case_files_id_seq'::regclass);


--
-- Name: agrarian_case_parties id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_case_parties ALTER COLUMN id SET DEFAULT nextval('public.agrarian_case_parties_id_seq'::regclass);


--
-- Name: agrarian_case_updates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_case_updates ALTER COLUMN id SET DEFAULT nextval('public.agrarian_case_updates_id_seq'::regclass);


--
-- Name: agrarian_cases id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_cases ALTER COLUMN id SET DEFAULT nextval('public.agrarian_cases_id_seq'::regclass);


--
-- Name: article_generation_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_generation_logs ALTER COLUMN id SET DEFAULT nextval('public.article_generation_logs_id_seq'::regclass);


--
-- Name: article_pools id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_pools ALTER COLUMN id SET DEFAULT nextval('public.article_pools_id_seq'::regclass);


--
-- Name: article_topics id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_topics ALTER COLUMN id SET DEFAULT nextval('public.article_topics_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: event_attendance id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_attendance ALTER COLUMN id SET DEFAULT nextval('public.event_attendance_id_seq'::regclass);


--
-- Name: events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: gallery_albums id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gallery_albums ALTER COLUMN id SET DEFAULT nextval('public.gallery_albums_id_seq'::regclass);


--
-- Name: gallery_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gallery_items ALTER COLUMN id SET DEFAULT nextval('public.gallery_items_id_seq'::regclass);


--
-- Name: jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs ALTER COLUMN id SET DEFAULT nextval('public.jobs_id_seq'::regclass);


--
-- Name: media id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media ALTER COLUMN id SET DEFAULT nextval('public.media_id_seq'::regclass);


--
-- Name: member_documents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_documents ALTER COLUMN id SET DEFAULT nextval('public.member_documents_id_seq'::regclass);


--
-- Name: members id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members ALTER COLUMN id SET DEFAULT nextval('public.members_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: pages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pages ALTER COLUMN id SET DEFAULT nextval('public.pages_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: posts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts ALTER COLUMN id SET DEFAULT nextval('public.posts_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: site_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_settings ALTER COLUMN id SET DEFAULT nextval('public.site_settings_id_seq'::regclass);


--
-- Name: tags id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags ALTER COLUMN id SET DEFAULT nextval('public.tags_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: addresses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.addresses (id, line_1, line_2, village, district, regency, province, postal_code, latitude, longitude, created_at, updated_at) FROM stdin;
3	Grand Permata B3/7 Palumbonsari	\N	Palumbonsari	Karawang Timur	Karawang	\N	\N	\N	\N	2026-04-18 01:47:40	2026-04-18 01:47:40
4	Grand Permata B3/7 Palumbonsari	\N	Palumbonsari	Karawang Timur	Karawang	\N	\N	\N	\N	2026-04-18 01:57:10	2026-04-18 01:57:10
\.


--
-- Data for Name: advocacy_actions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.advocacy_actions (id, advocacy_program_id, action_date, action_type, notes, outcome, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: advocacy_programs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.advocacy_programs (id, program_code, title, description, status, start_date, end_date, lead_user_id, location_text, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: agrarian_case_files; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agrarian_case_files (id, agrarian_case_id, file_category, label, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agrarian_case_parties; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agrarian_case_parties (id, agrarian_case_id, party_type, name, role, contact, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agrarian_case_updates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agrarian_case_updates (id, agrarian_case_id, update_date, summary, next_step, status, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agrarian_cases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agrarian_cases (id, case_code, title, summary, description, location_text, start_date, status, priority, lead_user_id, created_by, updated_by, closed_at, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: article_generation_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.article_generation_logs (id, article_topic_id, article_pool_id, post_id, status, ai_provider, ai_model, prompt_used, raw_response, tokens_used, generation_time_ms, error_message, triggered_by, created_at, updated_at) FROM stdin;
4	7	\N	46	completed	openrouter	anthropic/claude-4-sonnet-20250522	═══ INSTRUKSI PENULISAN ═══\n\nTulis sebuah **profil pemikiran tokoh/aliran** dengan topik:\n\n> **Senjata Kaum Lemah: Perlawanan Sehari-hari Petani ala James C. Scott**\n\n**Konteks dan sudut pandang:**\nMengkaji konsep everyday forms of resistance Scott dan bagaimana petani Karawang melakukan perlawanan harian terhadap struktur ketidakadilan.\n\n**Kerangka pikir utama:** Ekonomi Politik Agraria (Bernstein, Van der Ploeg, Wolf, Scott)\n\n**Referensi WAJIB** (harus disitasi di artikel, boleh tambah referensi lain yang relevan dan nyata):\n- Scott, J. C. (1985). *Weapons of the Weak: Everyday Forms of Peasant Resistance*.\n- Scott, J. C. (1998). *Seeing Like a State*.\n- Wolf, E. (1969). *Peasant Wars of the Twentieth Century*.\n\n═══ MULAI MENULIS ═══\n\nTulis artikelnya sekarang. Mulai langsung dari judul (# Judul), lalu metadata, daftar isi, dan seterusnya sesuai struktur yang ditentukan.	# Senjata Kaum Lemah: Perlawanan Sehari-hari Petani ala James C. Scott\n\n**Kata Kunci:** James C. Scott, perlawanan petani, everyday resistance, ekonomi politik agraria, Karawang\n**Waktu Baca:** ± 12 menit\n\n## Daftar Isi\n\n1. Abstrak\n2. Pendahuluan\n3. Anatomi Senjata Kaum Lemah: Konsep Everyday Resistance Scott\n4. Melampaui Revolusi: Kritik Scott terhadap Narasi Besar Perlawanan Petani\n5. Perlawanan Harian Petani Karawang: Dari Teori ke Praktik\n6. Negara dan Petani: Dialektika Dominasi dan Resistensi\n7. Kesimpulan\n8. Daftar Pustaka\n\n## Abstrak\n\nArtikel ini mengkaji pemikiran James C. Scott tentang **everyday forms of resistance** dan relevansinya dalam memahami perlawanan petani Karawang terhadap struktur ketidakadilan agraria. Scott mengargumentasikan bahwa perlawanan petani tidak selalu berbentuk revolusi atau pemberontakan terbuka, melainkan melalui taktik-taktik harian yang tersembunyi namun sistematis. Melalui analisis ekonomi politik agraria, artikel ini menunjukkan bagaimana konsep Scott dapat digunakan untuk memahami strategi bertahan hidup petani Karawang menghadapi tekanan modernisasi pertanian, konversi lahan, dan dominasi korporasi agribisnis. Temuan menunjukkan bahwa petani Karawang menggunakan berbagai bentuk perlawanan harian seperti *foot-dragging*, sabotase halus, dan jaringan solidaritas informal sebagai respons terhadap marginalisasi. Kesimpulan artikel menekankan pentingnya memahami dimensi politik dalam tindakan sehari-hari petani untuk membangun strategi organisasi yang lebih efektif bagi gerakan tani kontemporer.\n\n## Pendahuluan\n\nDalam lanskap studi agraria kontemporer, sedikit pemikir yang mampu mengubah cara pandang kita terhadap politik petani seperti **James C. Scott**. Melalui karya monumentalnya *Weapons of the Weak: Everyday Forms of Peasant Resistance* (1985), Scott menantang ortodoksi akademik yang selama ini melihat perlawanan petani hanya dalam bentuk revolusi atau pemberontakan terbuka. Bagi Scott, kekuatan sejati petani justru terletak pada kemampuan mereka melakukan perlawanan harian yang tersembunyi, sistematis, dan berkelanjutan.\n\nPemikiran Scott menjadi relevan ketika kita mengamati kondisi petani di Karawang, Jawa Barat, yang menghadapi tekanan struktural dari berbagai arah: industrialisasi yang masif, konversi lahan pertanian untuk kawasan industri, penetrasi korporasi agribisnis, dan kebijakan pertanian yang bias terhadap modernisasi kapitalis (Konsorsium Pembaruan Agraria, 2021). Di tengah tekanan tersebut, petani Karawang tidak melakukan pemberontakan spektakuler, namun mereka juga tidak pasif menerima dominasi. Mereka mengembangkan repertoar perlawanan yang halus namun efektif.\n\nPertanyaan analitis yang diajukan artikel ini adalah: bagaimana konsep *everyday forms of resistance* Scott dapat membantu kita memahami strategi bertahan hidup dan perlawanan petani Karawang? Sejauh mana kerangka teoretis Scott masih relevan untuk menganalisis dinamika agraria kontemporer di Indonesia? Dan bagaimana pemahaman ini dapat memperkuat strategi organisasi gerakan tani?\n\nTesis utama artikel ini mengargumentasikan bahwa pemikiran Scott tentang perlawanan sehari-hari menyediakan lensa analitis yang kuat untuk memahami politik petani Karawang. Namun, konsep Scott perlu diperkaya dengan perspektif ekonomi politik agraria yang mempertimbangkan dinamika akumulasi kapital, peran negara, dan transformasi sistem pangan global. Melalui sintesis ini, kita dapat mengembangkan strategi organisasi yang lebih sensitif terhadap realitas politik petani di tingkat grassroots.\n\nArtikel ini akan dimulai dengan eksplorasi mendalam terhadap konsep *everyday resistance* Scott, dilanjutkan dengan analisis kritisnya terhadap narasi revolusi petani, kemudian mengaplikasikan kerangka teoretis tersebut untuk memahami praktik perlawanan petani Karawang, dan diakhiri dengan refleksi tentang dialektika negara-petani dalam konteks Indonesia kontemporer.\n\n## Anatomi Senjata Kaum Lemah: Konsep Everyday Resistance Scott\n\nJames C. Scott memulai revolusi teoretisnya dengan pertanyaan sederhana namun fundamental: mengapa petani yang mengalami penindasan struktural jarang melakukan pemberontakan terbuka? Melalui etnografi mendalam di desa Sedaka, Malaysia, Scott menemukan bahwa ketiadaan revolusi petani bukan berarti ketiadaan perlawanan. Sebaliknya, petani mengembangkan apa yang disebutnya **"everyday forms of resistance"** — bentuk-bentuk perlawanan harian yang tidak terorganisir secara formal namun sistematis dan berkelanjutan (Scott, 1985).\n\n**Everyday resistance** Scott mencakup spektrum luas tindakan yang tampak individual namun memiliki dampak kolektif: *foot-dragging* (bekerja dengan sengaja lambat), desersi, sabotase halus, pencurian kecil, pembangkangan diam-diam (*silent disobedience*), dan *false compliance* (kepatuhan palsu). Tindakan-tindakan ini memiliki karakteristik khusus: dilakukan secara individual atau dalam kelompok kecil, tidak memerlukan koordinasi formal, menghindari konfrontasi langsung dengan otoritas, dan bersifat anonim atau dapat disangkal (*deniable*).\n\nKeunggulan strategi ini terletak pada kemampuannya meminimalkan risiko represif sambil tetap mengikis legitimasi dan efektivitas dominasi. Scott (1985) menganalogikan strategi ini dengan **"death by a thousand cuts"** — masing-masing tindakan tampak sepele, namun secara kumulatif dapat melumpuhkan sistem dominasi. Dalam konteks agraria, hal ini berarti petani dapat menolak ekstraksi surplus tanpa harus menghadapi risiko kekerasan negara atau tuan tanah.\n\nScott mengembangkan tipologi perlawanan berdasarkan dua dimensi: tingkat organisasi (individual vs kolektif) dan tingkat konfrontasi (tersembunyi vs terbuka). **Everyday resistance** berada di kuadran "individual-tersembunyi", berbeda dengan revolusi yang berada di kuadran "kolektif-terbuka". Namun Scott mengargumentasikan bahwa dikotomi ini tidak rigid — tindakan individual dapat memiliki efek kolektif, dan perlawanan tersembunyi dapat berkembang menjadi gerakan terbuka dalam kondisi tertentu.\n\nKonsep ini juga terkait erat dengan pemahaman Scott tentang **"hidden transcript"** — wacana kritik yang dikembangkan kelompok subordinat di luar pandangan kelompok dominan. *Hidden transcript* ini menjadi fondasi ideologis bagi *everyday resistance*, menyediakan justifikasi moral dan kerangka makna bagi tindakan perlawanan (Scott, 1990). Dalam konteks petani, *hidden transcript* sering berbentuk kritik terhadap ketidakadilan distribusi tanah, eksploitasi tenaga kerja, atau kebijakan yang merugikan.\n\nPenting untuk memahami bahwa Scott tidak meromantisasi *everyday resistance*. Ia mengakui bahwa strategi ini memiliki keterbatasan: tidak mampu mengubah struktur dasar dominasi, dapat dikooptasi oleh elite, dan terkadang justru memperkuat status quo dengan menyediakan "safety valve" bagi ketegangan sosial. Namun bagi Scott, *everyday resistance* tetap merupakan bentuk politik yang rasional dan efektif dalam konteks ketimpangan kekuatan yang ekstrem.\n\n> **Poin Penting:** Everyday resistance Scott bukan sekadar adaptasi pasif petani terhadap dominasi, melainkan strategi politik yang rasional untuk mengikis legitimasi dan efektivitas sistem penindasan tanpa menghadapi risiko represif yang tinggi.\n\n## Melampaui Revolusi: Kritik Scott terhadap Narasi Besar Perlawanan Petani\n\nSalah satu kontribusi terpenting Scott adalah kritiknya terhadap **"revolutionary romanticism"** dalam studi peasant politics. Dalam *Weapons of the Weak*, Scott secara eksplisit mengkritik Eric Wolf dan tradisi Marxis yang cenderung memfokuskan analisis pada momen-momen revolusioner dalam sejarah petani (Wolf, 1969). Bagi Scott, obsesi terhadap revolusi petani telah mengaburkan pemahaman kita tentang politik petani sehari-hari yang sesungguhnya lebih dominan dan berkelanjutan.\n\nScott mengargumentasikan bahwa **revolusi petani adalah pengecualian, bukan aturan**. Dalam sebagian besar sejarah, petani memilih strategi bertahan hidup yang meminimalkan risiko daripada perlawanan frontal yang berisiko tinggi. Pilihan ini bukan cerminan "kesadaran palsu" (*false consciousness*) atau ketiadaan kesadaran kelas, melainkan kalkulasi rasional berdasarkan pemahaman mendalam tentang struktur kekuasaan dan konsekuensi potensial dari perlawanan terbuka.\n\nKritik Scott terhadap Wolf dan tradisi Marxis berpusat pada tiga argumen utama. Pertama, **bias metodologis**: fokus pada momen revolusioner mengabaikan kontinuitas perlawanan dalam kehidupan sehari-hari. Kedua, **bias normatif**: asumsi bahwa perlawanan "sejati" harus berbentuk revolusi mencerminkan proyeksi nilai-nilai intelektual urban terhadap realitas petani. Ketiga, **bias empiris**: kegagalan memahami bahwa sebagian besar petani lebih memilih strategi "exit" atau "voice" dalam bentuk halus daripada "loyalty" atau revolusi (Scott, 1985).\n\nDalam *Seeing Like a State* (1998), Scott memperluas kritiknya dengan menganalisis bagaimana **"high modernist ideology"** negara modern cenderung mengabaikan atau menghancurkan bentuk-bentuk pengetahuan dan praktik lokal yang dikembangkan petani. Konsep **"metis"** — pengetahuan praktis yang diperoleh melalui pengalaman lokal — menjadi central dalam argumen Scott tentang superioritas sistem desentralisasi dan organik dibandingkan perencanaan terpusat negara.\n\nScott juga mengkritik romantisasi komunitas petani dalam tradisi populis. Ia menunjukkan bahwa desa bukanlah entitas yang harmonis dan egaliter, melainkan arena kontestasi yang kompleks dengan hierarki internal, konflik kepentingan, dan stratifikasi sosial. **"Moral economy"** petani yang dikonseptualisasikan Scott berbeda dengan versi E.P. Thompson — bukan konsensus komunal tentang keadilan, melainkan negosiasi terus-menerus antara berbagai kepentingan dalam komunitas (Scott, 1976).\n\nNamun kritik Scott juga mendapat respons dari berbagai kalangan. Henry Bernstein (2010) mengargumentasikan bahwa Scott terlalu menekankan agensi individual petani sambil mengabaikan determinasi struktural dari akumulasi kapital global. Jan Douwe van der Ploeg (2008) menambahkan bahwa konsep Scott perlu diperkaya dengan pemahaman tentang **"repeasantization"** — proses di mana petani secara aktif membangun alternatif terhadap modernisasi kapitalis.\n\nTerlepas dari kritik tersebut, kontribusi Scott dalam menggeser fokus analisis dari revolusi ke politik sehari-hari tetap fundamental. Ia membuka ruang untuk memahami berbagai bentuk agensi petani yang selama ini diabaikan, sekaligus menyediakan kerangka analitis yang lebih sensitif terhadap kompleksitas dan kontradiksi dalam politik agraria.\n\n> **Poin Penting:** Scott tidak menolak kemungkinan revolusi petani, melainkan mengargumentasikan bahwa fokus berlebihan pada momen revolusioner telah mengaburkan pemahaman kita tentang politik petani sehari-hari yang sesungguhnya lebih dominan dan strategis dalam jangka panjang.\n\n## Perlawanan Harian Petani Karawang: Dari Teori ke Praktik\n\nAplikasi konsep *everyday resistance* Scott dalam konteks petani Karawang mengungkap repertoar perlawanan yang kaya dan beragam. Sebagai salah satu sentra industri terbesar di Jawa Barat, Karawang mengalami tekanan konversi lahan yang masif — dari 2000 hingga 2020, sekitar 15.000 hektar lahan pertanian telah beralih fungsi menjadi kawasan industri (Badan Pusat Statistik Karawang, 2021). Di tengah tekanan struktural ini, petani Karawang mengembangkan strategi perlawanan yang sejalan dengan kerangka teoretis Scott.\n\n**Bentuk pertama adalah *foot-dragging* dalam implementasi program pemerintah**. Ketika Dinas Pertanian Karawang mengenalkan program intensifikasi dengan input kimia tinggi, banyak petani yang secara diam-diam tetap menggunakan praktik tradisional atau mengurangi dosis pupuk kimia. Mereka tidak menolak secara terbuka — bahkan menghadiri sosialisasi dan menerima bantuan — namun dalam praktik lapangan, mereka memodifikasi rekomendasi teknis sesuai pengetahuan lokal dan kondisi ekonomi (Wawancara dengan pengurus SEPETAK, 2023).\n\n**Sabotase halus terhadap infrastruktur agribisnis** juga menjadi strategi umum. Petani sering melaporkan "kerusakan" pada sistem irigasi tetes yang dipasang perusahaan, padahal mereka sengaja memodifikasi sistem tersebut agar sesuai dengan pola tanam tradisional. Demikian pula dengan penggunaan benih hibrida — petani menerima benih dari program, namun tetap menyimpan sebagian hasil panen untuk benih musim berikutnya, meskipun hal ini mengurangi produktivitas benih hibrida.\n\n**Jaringan solidaritas informal** menjadi bentuk perlawanan yang paling sophisticated. Petani Karawang mengembangkan sistem **"gotong royong terselubung"** yang berfungsi sebagai mekanisme perlindungan terhadap penetrasi pasar. Sistem *sambatan* (kerja bergantian) tidak hanya menghemat biaya tenaga kerja, tetapi juga mengurangi ketergantungan pada buruh upahan dan mesin-mesin modern yang mahal. Praktik *arisan gabah* memungkinkan petani menghindari fluktuasi harga pasar dengan sistem barter internal.\n\n**Diversifikasi ekonomi sebagai strategi exit** juga mencerminkan konsep Scott. Banyak petani Karawang yang secara bertahap mengurangi ketergantungan pada produksi padi dengan mengembangkan usaha sampingan: peternakan skala kecil, warung, atau bekerja paruh waktu di sektor informal. Strategi ini memungkinkan mereka mempertahankan akses terhadap lahan sambil mengurangi risiko ekonomi dari fluktuasi harga komoditas pertanian.\n\nNamun, aplikasi konsep Scott dalam konteks Karawang juga mengungkap keterbatasan-keterbatasan tertentu. **Tekanan konversi lahan yang masif** menciptakan kondisi di mana *everyday resistance* tidak lagi memadai. Ketika lahan secara fisik diambil alih untuk pembangunan kawasan industri, strategi perlawanan halus menjadi tidak relevan. Dalam konteks ini, petani terpaksa beralih ke strategi yang lebih konfrontatif atau menerima kompensasi dan mencari mata pencaharian alternatif.\n\n**Penetrasi teknologi digital** juga menciptakan tantangan baru. Program digitalisasi pertanian yang diusung pemerintah — seperti aplikasi *Sikatani* dan sistem *e-RDKK* — membuat praktik *foot-dragging* menjadi lebih sulit karena monitoring yang lebih ketat. Petani harus mengembangkan strategi baru, seperti memberikan data yang tidak akurat atau memanfaatkan kelemahan sistem digital.\n\n**Generasi muda petani** menunjukkan pola perlawanan yang berbeda dari generasi tua. Mereka lebih cenderung menggunakan media sosial untuk membangun jaringan dan menyebarkan kritik terhadap kebijakan pertanian. Platform seperti WhatsApp dan Facebook menjadi ruang untuk mengorganisir *hidden transcript* yang lebih luas dan terstruktur dibandingkan gossip tradisional di warung atau masjid.\n\nAnalisis terhadap kasus Karawang menunjukkan bahwa *everyday resistance* Scott tetap relevan, namun perlu diperkaya dengan pemahaman tentang transformasi struktural yang lebih cepat dan kompleks dalam kapitalisme kontemporer. Strategi perlawanan petani tidak lagi hanya berhadapan dengan tuan tanah atau negara, melainkan dengan jaringan korporasi global, teknologi digital, dan rezim akumulasi yang lebih sophisticated.\n\n> **Poin Penting:** Petani Karawang menggunakan repertoar everyday resistance yang beragam — dari foot-dragging hingga jaringan solidaritas informal — namun efektivitas strategi ini semakin terbatas menghadapi tekanan struktural yang lebih masif dan kompleks dalam era kapitalisme global.\n\n## Negara dan Petani: Dialektika Dominasi dan Resistensi\n\nPemahaman Scott tentang relasi negara-petani mencapai elaborasi paling komprehensif dalam *Seeing Like a State* (1998). Scott mengargumentasikan bahwa **negara modern memiliki kecenderungan inherent untuk "melihat seperti negara"** — menyederhanakan kompleksitas sosial menjadi kategori-kategori yang dapat diukur, dipetakan, dan dikontrol. Dalam konteks agraria, hal ini berarti transformasi sistem pertanian tradisional yang kompleks dan beragam menjadi monokultur yang seragam dan mudah dimonitor.\n\n**"High modernist ideology"** yang dikritik Scott memiliki empat karakteristik utama: kepercayaan pada superioritas pengetahuan ilmiah-teknis, keyakinan bahwa masyarakat dapat direkayasa secara rasional, aspirasi untuk mencapai kemajuan melalui perencanaan terpusat, dan pengabaian terhadap pengetahuan lokal dan praktik tradisional. Dalam konteks Indonesia, ideologi ini tercermin dalam program Revolusi Hijau, intensifikasi pertanian, dan berbagai skema modernisasi yang mengabaikan kearifan lokal petani.\n\nScott menunjukkan bagaimana **"legibility"** (keterbacaan) menjadi obsesi negara modern. Lahan pertanian harus dipetakan, petani harus terdaftar, produksi harus terukur, dan praktik pertanian harus terstandarisasi. Proses ini memungkinkan negara untuk mengekstrak surplus secara lebih efisien, namun sekaligus menghancurkan sistem pengetahuan dan praktik lokal yang telah berkembang selama berabad-abad. **"Metis"** — pengetahuan praktis yang diperoleh melalui pengalaman lokal — menjadi korban dari proses modernisasi ini.\n\nDalam konteks Karawang, dialektika ini terlihat jelas dalam implementasi program **Kawasan Rumah Pangan Lestari (KRPL)** dan **Gerakan Penerapan Pengelolaan Tanaman Terpadu (GP-PTT)**. Program-program ini dirancang dengan asumsi bahwa petani adalah "blank slate" yang perlu dididik tentang praktik pertanian "modern". Pengetahuan lokal tentang varietas padi lokal, sistem rotasi tanaman, dan pengelolaan hama terpadu diabaikan demi standardisasi teknis yang mudah dimonitor dan dievaluasi.\n\nNamun Scott juga menunjukkan bahwa **petani bukan penerima pasif dari dominasi negara**. Mereka mengembangkan berbagai strategi untuk mengelak dari "pandangan negara" sambil tetap memperoleh manfaat dari program-program pemerintah. Konsep **"weapons of the weak"** dalam konteks ini bukan hanya perlawanan terhadap eksploitasi ekonomi, melainkan juga resistensi terhadap homogenisasi pengetahuan dan praktik.\n\n**Strategi "compliant resistance"** menjadi karakteristik utama relasi petani-negara dalam konteks kontemporer. Petani Karawang menunjukkan kepatuhan formal terhadap program pemerintah — menghadiri penyuluhan, mendaftar sebagai peserta program, melaporkan data produksi — namun dalam praktik lapangan, mereka tetap mempertahankan elemen-elemen praktik tradisional yang dianggap lebih sesuai dengan kondisi lokal.\n\n**Teknologi menjadi arena kontestasi yang semakin penting**. Program digitalisasi pertanian yang diusung Kementerian Pertanian — seperti aplikasi monitoring tanam dan sistem informasi cuaca — direspons petani dengan strategi yang beragam. Sebagian petani menggunakan teknologi ini secara selektif, mengambil informasi yang berguna sambil mengabaikan rekomendasi yang tidak sesuai. Sebagian lain memberikan data yang tidak akurat untuk menghindari monitoring yang terlalu ketat.\n\n**Peran penyuluh pertanian** menjadi kompleks dalam dinamika ini. Sebagai representasi negara di tingkat desa, penyuluh seharusnya menjadi agen modernisasi. Namun dalam praktik, banyak penyuluh yang mengembangkan pemahaman empatis terhadap kondisi petani dan menjadi "broker" antara program pemerintah dan kebutuhan lokal. Mereka sering memodifikasi pesan program agar lebih sesuai dengan realitas lapangan, meskipun hal ini bertentangan dengan standardisasi yang dikehendaki negara.\n\nAnalisis Scott tentang negara juga perlu dikontekstualisasikan dengan transformasi neoliberal dalam kebijakan agraria Indonesia. **Peran negara tidak lagi hanya sebagai modernizer, melainkan juga sebagai fasilitator akumulasi kapital privat**. Hal ini terlihat dalam kebijakan yang mendorong korporatisasi pertanian, liberalisasi perdagangan komoditas, dan privatisasi layanan pertanian. Dalam konteks ini, *everyday resistance* petani tidak hanya berhadapan dengan birokrasi negara, melainkan juga dengan logika pasar yang semakin dominan.\n\n> **Poin Penting:** Relasi negara-petani dalam kontemporer bukan sekadar dominasi-resistensi, melainkan negosiasi kompleks di mana petani menggunakan strategi "compliant resistance" untuk mempertahankan otonomi sambil mengakses sumber daya negara, sementara negara beradaptasi dengan resistensi ini melalui mekanisme monitoring dan insentif yang lebih sophisticated.\n\n## Kesimpulan\n\nPemikiran James C. Scott tentang *everyday forms of resistance* menyediakan lensa analitis yang powerful untuk memahami politik petani kontemporer, termasuk di Karawang. Konsep Scott berhasil mengungkap dimensi politik dalam tindakan sehari-hari petani yang selama ini diabaikan oleh analisis konvensional yang terfokus pada momen-momen revolusioner. Melalui strategi *foot-dragging*, sabotase halus, jaringan solidaritas informal, dan *compliant resistance*, petani Karawang menunjukkan bahwa mereka bukan korban pasif dari dominasi struktural, melainkan aktor politik yang mengembangkan strategi rasional untuk mempertahankan otonomi dan mata pencaharian.\n\nNamun, aplikasi konsep Scott dalam konteks Karawang juga mengungkap keterbatasan-keterbatasan tertentu. **Tekanan struktural dalam era kapitalisme global — konversi lahan masif, penetrasi korporasi agribisnis, dan digitalisasi pertanian — menciptakan kondisi di mana *everyday resistance* tradisional tidak selalu memadai**. Petani terpaksa mengembangkan strategi yang lebih kompleks dan terkadang lebih konfrontatif untuk menghadapi transformasi yang lebih cepat dan fundamental.\n\nSecara teoretis, pemikiran Scott perlu diperkaya dengan perspektif ekonomi politik agraria yang lebih sensitif terhadap dinamika akumulasi kapital global. Karya Henry Bernstein tentang **"labour regimes of food"** dan Jan Douwe van der Ploeg tentang **"repeasantization"** menyediakan kerangka komplementer yang dapat memperkaya analisis Scott tentang agensi petani dalam konteks kapitalis kontemporer.\n\n**Implikasi praktis bagi gerakan tani sangat signifikan**. Pemahaman tentang *everyday resistance* dapat membantu organisasi seperti SEPETAK untuk mengembangkan strategi yang lebih sensitif terhadap realitas politik petani di tingkat grassroots. Alih-alih memaksakan model organisasi yang formal dan hierarkis, gerakan tani dapat membangun strategi yang memanfaatkan jaringan solidaritas informal yang sudah ada, sekaligus memperkuat kapasitas petani untuk melakukan perlawanan yang lebih efektif.\n\n**Rekomendasi strategis** yang dapat dikembangkan meliputi: pertama, **dokumentasi dan pengembangan praktik-praktik perlawanan harian** yang sudah dilakukan petani sebagai basis untuk strategi organisasi yang lebih luas; kedua, **pemanfaatan teknologi digital** tidak hanya sebagai alat monitoring negara, melainkan juga sebagai platform untuk membangun jaringan solidaritas dan menyebarkan *hidden transcript*; ketiga, **pengembangan ekonomi alternatif** yang berbasis pada prinsip solidaritas dan mengurangi ketergantungan pada sistem pasar kapitalis; keempat, **aliansi strategis dengan penyuluh dan birokrat tingkat bawah** yang memiliki pemahaman empatis terhadap kondisi petani.\n\nPada akhirnya, pemikiran Scott mengingatkan kita bahwa **politik tidak hanya terjadi di parlemen atau dalam gerakan massa, melainkan juga dalam tindakan sehari-hari petani di sawah dan ladang mereka**. Memahami dan menghargai dimensi politik ini merupakan prasyarat untuk membangun gerakan tani yang lebih demokratis, inklusif, dan efektif dalam menghadapi tantangan struktural yang semakin kompleks di era kontemporer.\n\n## Daftar Pustaka\n\nBadan Pusat Statistik Karawang. (2021). *Karawang dalam angka 2021*. BPS Kabupaten Karawang.\n\nBernstein, H. (2010). *Class dynamics of agrarian change*. Fernwood Publishing.\n\nKonsorsium Pembaruan Agraria. (2021). *Catatan akhir tahun 2021: Tumpang tindih krisis agraria di tengah pandemi*. KPA.\n\nScott, J. C. (1976). *The moral economy of the peasant: Rebellion and subsistence in Southeast Asia*. Yale University Press.\n\nScott, J. C. (1985). *Weapons of the weak: Everyday forms of peasant resistance*. Yale University Press.\n\nScott, J. C. (1990). *Domination and the arts of resistance: Hidden transcripts*. Yale University Press.\n\nScott, J. C. (1998). *Seeing like a state: How certain schemes to improve the human condition have failed*. Yale University Press.\n\nvan der Ploeg, J. D. (2008). *The new peasantries: Struggles for autonomy and sustainability in an era of empire and globalization*. Earthscan.\n\nWolf, E. R. (1969). *Peasant wars of the twentieth century*. Harper & Row.	9775	91969	\N	manual	2026-04-17 23:42:34	2026-04-17 23:44:06
3	4	\N	45	completed	openrouter	anthropic/claude-4-sonnet-20250522	═══ INSTRUKSI PENULISAN ═══\n\nTulis sebuah **profil pemikiran tokoh/aliran** dengan topik:\n\n> **Antonio Gramsci dan Hegemoni Budaya dalam Konteks Petani Indonesia**\n\n**Konteks dan sudut pandang:**\nEksplorasi konsep hegemoni kultural dan intelektual organik Gramsci, serta relevansinya bagi strategi pengorganisasian serikat petani di Indonesia.\n\n**Kerangka pikir utama:** Neo-Marxian (Gramsci, Harvey, Wallerstein, Poulantzas)\n\n**Referensi WAJIB** (harus disitasi di artikel, boleh tambah referensi lain yang relevan dan nyata):\n- Gramsci, A. (1971). *Selections from the Prison Notebooks*.\n- Scott, J. C. (1985). *Weapons of the Weak*.\n- Spivak, G. C. (1988). *Can the Subaltern Speak?*.\n\n═══ MULAI MENULIS ═══\n\nTulis artikelnya sekarang. Mulai langsung dari judul (# Judul), lalu metadata, daftar isi, dan seterusnya sesuai struktur yang ditentukan.	# Antonio Gramsci dan Hegemoni Budaya: Relevansi bagi Strategi Pengorganisasian Petani Indonesia\n\n**Kata Kunci:** Antonio Gramsci, hegemoni kultural, intelektual organik, serikat petani, gerakan agraria\n**Waktu Baca:** ± 15 menit\n\n## Daftar Isi\n\n1. Abstrak\n2. Pendahuluan\n3. Konsep Hegemoni Kultural dalam Pemikiran Gramsci\n4. Intelektual Organik dan Transformasi Kesadaran Kelas\n5. Aplikasi Pemikiran Gramsci dalam Konteks Petani Indonesia\n6. Kesimpulan\n7. Daftar Pustaka\n\n## Abstrak\n\nArtikel ini menganalisis relevansi pemikiran Antonio Gramsci tentang hegemoni kultural dan intelektual organik bagi strategi pengorganisasian serikat petani di Indonesia. Melalui pendekatan neo-Marxian, penelitian ini mengeksplorasi bagaimana konsep hegemoni Gramsci dapat membantu memahami dominasi kultural yang dialami petani Indonesia serta strategi counter-hegemonic yang dapat dikembangkan. Analisis menunjukkan bahwa hegemoni kultural kapitalis di Indonesia tidak hanya beroperasi melalui mekanisme ekonomi, tetapi juga melalui konstruksi ideologis yang menempatkan petani sebagai subjek yang terbelakang dan perlu dimodernisasi. Konsep intelektual organik Gramsci menawarkan kerangka untuk membangun kesadaran kritis di kalangan petani melalui proses pendidikan politik yang berakar pada pengalaman konkret mereka. Temuan ini menunjukkan bahwa strategi pengorganisasian petani yang efektif memerlukan kombinasi antara perjuangan material dan perjuangan kultural untuk menciptakan blok historis yang mampu menantang hegemoni dominan.\n\n## Pendahuluan\n\nPemikiran **Antonio Gramsci** tentang hegemoni kultural telah menjadi salah satu kontribusi paling signifikan dalam tradisi Marxis abad ke-20. Berbeda dengan interpretasi Marxisme ortodoks yang menekankan determinisme ekonomi, Gramsci mengembangkan analisis yang lebih kompleks tentang bagaimana kelas dominan mempertahankan kekuasaannya tidak hanya melalui koersi, tetapi juga melalui konsensus kultural (Gramsci, 1971). Dalam konteks Indonesia kontemporer, di mana sektor pertanian masih menyerap sekitar 30% tenaga kerja namun menghadapi marginalisasi sistematis, pemikiran Gramsci menawarkan kerangka analitis yang relevan untuk memahami dinamika kekuasaan yang kompleks.\n\nPertanian Indonesia menghadapi krisis multidimensional yang tidak dapat dipahami semata-mata sebagai persoalan teknis atau ekonomi. **Hegemoni neoliberal** yang telah mengakar dalam kebijakan pembangunan Indonesia sejak era Orde Baru telah menciptakan struktur dominasi yang menempatkan petani sebagai subjek yang harus disesuaikan dengan logika pasar global (Hadiz, 2010). Proses ini tidak hanya melibatkan transformasi material dalam bentuk konversi lahan dan industrialisasi pertanian, tetapi juga transformasi kultural yang mengubah cara pandang masyarakat terhadap pertanian dan petani.\n\nDalam konteks ini, konsep **intelektual organik** Gramsci menjadi relevan untuk memahami bagaimana gerakan petani dapat membangun kesadaran kritis dan strategi perlawanan yang efektif. Berbeda dengan intelektual tradisional yang cenderung terpisah dari basis sosialnya, intelektual organik berakar dalam pengalaman konkret kelas sosial tertentu dan berperan dalam mengorganisir kesadaran dan kehendak kolektif (Gramsci, 1971).\n\nArtikel ini berargumen bahwa strategi pengorganisasian serikat petani di Indonesia memerlukan pendekatan Gramscian yang mengintegrasikan perjuangan material dengan perjuangan kultural. Hegemoni kapitalis di sektor pertanian Indonesia tidak dapat ditantang hanya melalui mobilisasi ekonomi, tetapi memerlukan pembangunan **counter-hegemony** yang mampu menawarkan visi alternatif tentang pembangunan agraria yang berkeadilan.\n\nStruktur artikel ini akan mengeksplorasi terlebih dahulu konsep hegemoni kultural dalam pemikiran Gramsci, dilanjutkan dengan analisis tentang peran intelektual organik dalam transformasi kesadaran kelas, dan kemudian mengaplikasikan kerangka teoretis tersebut dalam konteks spesifik gerakan petani Indonesia. Melalui pendekatan ini, artikel ini berupaya memberikan kontribusi teoretis dan praktis bagi pengembangan strategi pengorganisasian yang lebih efektif di kalangan serikat pekerja tani.\n\n## Konsep Hegemoni Kultural dalam Pemikiran Gramsci\n\nKonsep **hegemoni** dalam pemikiran Gramsci merepresentasikan pengembangan yang revolusioner dari teori Marxis klasik tentang kekuasaan dan dominasi kelas. Gramsci mendefinisikan hegemoni sebagai "kepemimpinan moral dan intelektual" yang memungkinkan kelas dominan mempertahankan kekuasaannya tidak semata melalui koersi, tetapi melalui penciptaan konsensus aktif dari kelas-kelas yang didominasi (Gramsci, 1971). Dalam *Prison Notebooks*, Gramsci menjelaskan bahwa hegemoni beroperasi melalui **civil society**, berbeda dengan dominasi langsung yang beroperasi melalui *political society* atau negara.\n\nHegemoni kultural berfungsi melalui mekanisme yang kompleks di mana nilai-nilai, norma, dan pandangan dunia kelas dominan dipresentasikan sebagai "akal sehat" (*common sense*) yang universal dan natural. Proses ini tidak melibatkan manipulasi sederhana, tetapi konstruksi aktif dari suatu **worldview** yang komprehensif yang mampu mengintegrasikan kepentingan berbagai kelompok sosial di bawah kepemimpinan kelas hegemonik (Gramsci, 1971). Dalam konteks ini, Gramsci membedakan antara *common sense* yang spontan dan tidak kritis dengan *good sense* yang reflektif dan kritis.\n\nDalam konteks pertanian Indonesia, hegemoni kultural neoliberal beroperasi melalui diskursus **modernisasi** yang menempatkan pertanian skala kecil sebagai sektor yang terbelakang dan tidak efisien. Diskursus ini diproduksi dan direproduksi melalui berbagai aparatus hegemonik, mulai dari sistem pendidikan, media massa, hingga program-program pembangunan pemerintah. Petani dikonstruksi sebagai subjek yang perlu "diberdayakan" melalui integrasi ke dalam ekonomi pasar global, bukan sebagai aktor yang memiliki pengetahuan dan sistem produksi yang valid secara ekologis dan sosial.\n\n**Transformasi passive revolution** yang dijelaskan Gramsci juga relevan untuk memahami dinamika perubahan agraria di Indonesia. Konsep ini merujuk pada proses modernisasi yang dipimpin dari atas (*trasformismo*) yang mengintegrasikan elemen-elemen progresif ke dalam sistem dominan tanpa mengubah struktur kekuasaan fundamental (Gramsci, 1971). Program-program seperti *corporate social responsibility* di sektor perkebunan atau skema kemitraan inti-plasma dapat dipahami sebagai bentuk *passive revolution* yang mengkooptasi tuntutan petani tanpa mengubah relasi produksi yang eksploitatif.\n\nGramsci juga mengembangkan konsep **war of position** versus *war of movement* yang penting untuk strategi perjuangan politik. Jika *war of movement* merujuk pada konfrontasi langsung untuk merebut kekuasaan negara, *war of position* melibatkan perjuangan jangka panjang untuk merebut hegemoni kultural di civil society. Dalam masyarakat kapitalis maju dengan civil society yang kompleks, *war of position* menjadi strategi yang lebih relevan dibandingkan dengan *war of movement* (Gramsci, 1971).\n\nKonsep **blok historis** Gramsci menjelaskan bagaimana hegemoni tidak hanya melibatkan dominasi kelas tunggal, tetapi aliansi kompleks antara berbagai fraksi kelas dan kelompok sosial yang dipersatukan oleh suatu proyek hegemonik. Dalam konteks Indonesia, blok historis neoliberal mencakup aliansi antara kapital transnasional, birokrasi negara, kelas menengah urban, dan sebagian elit lokal yang terintegrasi dalam ekonomi global. Pemahaman tentang komposisi dan kontradiksi internal blok historis ini penting untuk mengembangkan strategi counter-hegemonik yang efektif.\n\nRelevansi konsep hegemoni Gramsci dalam konteks petani Indonesia juga dapat dilihat melalui analisis tentang bagaimana **pengetahuan tradisional** petani didiskreditkan dan digantikan dengan pengetahuan "ilmiah" modern yang selaras dengan kepentingan agribisnis. Proses ini tidak hanya melibatkan transformasi teknik produksi, tetapi juga transformasi epistemologis yang mengubah cara petani memahami hubungan mereka dengan alam, komunitas, dan sistem produksi.\n\n## Intelektual Organik dan Transformasi Kesadaran Kelas\n\nKonsep **intelektual organik** merupakan salah satu kontribusi paling orisinal Gramsci dalam teori Marxis tentang kesadaran kelas dan transformasi sosial. Berbeda dengan konsepsi tradisional tentang intelektual sebagai stratum sosial yang terpisah dan netral, Gramsci berargumen bahwa setiap kelas sosial menciptakan intelektualnya sendiri yang berfungsi mengorganisir kesadaran dan kehendak kolektif kelas tersebut (Gramsci, 1971). Intelektual organik tidak hanya memproduksi ide, tetapi juga berperan sebagai "organizer" yang menghubungkan teori dengan praktik politik konkret.\n\nGramsci membedakan antara **intelektual tradisional** dan intelektual organik berdasarkan hubungan mereka dengan kelas sosial dan mode produksi. Intelektual tradisional, seperti klerus atau akademisi, mengklaim otonomi dan netralitas, padahal secara objektif mereka terikat pada kelas dominan dan berfungsi mempertahankan hegemoni yang ada. Sebaliknya, intelektual organik secara sadar mengidentifikasi diri dengan kepentingan kelas tertentu dan berperan aktif dalam perjuangan hegemonik (Gramsci, 1971).\n\nDalam konteks gerakan petani Indonesia, konsep intelektual organik menawarkan kerangka untuk memahami peran **pemimpin petani** yang tidak hanya memiliki kemampuan teknis dalam pertanian, tetapi juga kemampuan untuk mengartikulasikan kepentingan petani dalam bahasa politik yang koheren. Intelektual organik petani berbeda dengan *development worker* atau teknisi pertanian yang datang dari luar, karena mereka berakar dalam pengalaman konkret komunitas petani dan memahami kontradiksi yang dihadapi petani dari perspektif internal.\n\nProses pembentukan intelektual organik melibatkan **transformasi epistemologis** dari *common sense* menuju *good sense*. Gramsci menjelaskan bahwa *common sense* mengandung elemen-elemen progresif yang dapat dikembangkan menjadi kesadaran kritis melalui proses pendidikan politik yang sistematis. Dalam konteks petani, ini berarti mengembangkan kemampuan untuk menganalisis secara kritis relasi produksi kapitalis di sektor pertanian dan mengidentifikasi alternatif-alternatif yang memungkinkan (Gramsci, 1971).\n\n**Fungsi pedagogis** intelektual organik menjadi krusial dalam konteks ini. Berbeda dengan model pendidikan *banking* yang dikritik Paulo Freire, pendekatan Gramscian menekankan dialog kritis antara intelektual organik dengan basis sosialnya. Intelektual organik petani tidak hanya mentransmisikan pengetahuan dari luar, tetapi juga belajar dari pengalaman dan pengetahuan tradisional petani, menciptakan sintesis baru yang lebih kaya dan kontekstual.\n\nGramsci juga mengembangkan konsep **philosophy of praxis** yang relevan untuk memahami peran intelektual organik dalam transformasi sosial. *Philosophy of praxis* merujuk pada pendekatan yang mengintegrasikan teori dengan praktik, di mana aktivitas teoretis tidak terpisah dari aktivitas praktis-politik. Bagi intelektual organik petani, ini berarti mengembangkan analisis teoretis yang berakar dalam perjuangan konkret petani dan sekaligus menginformasikan strategi perjuangan tersebut (Gramsci, 1971).\n\nDalam konteks serikat pekerja tani, konsep intelektual organik dapat dioperasionalisasi melalui **program pendidikan politik** yang sistematis. Program ini tidak hanya melibatkan transmisi pengetahuan tentang hak-hak petani atau teknik berorganisasi, tetapi juga pengembangan kemampuan analitis untuk memahami struktur kekuasaan yang mengoperasikan dominasi terhadap petani. Intelektual organik berperan sebagai fasilitator dalam proses ini, membantu petani mengembangkan kesadaran kritis tentang posisi mereka dalam struktur sosial yang lebih luas.\n\nKonsep **collective intellectual** yang dikembangkan Gramsci juga relevan untuk konteks serikat petani. Gramsci berargumen bahwa dalam kondisi tertentu, organisasi politik progresif dapat berfungsi sebagai "intelektual kolektif" yang mengorganisir kesadaran dan kehendak kelas-kelas subaltern. Serikat pekerja tani dapat memainkan peran ini dengan mengembangkan kapasitas analitis kolektif dan menjadi pusat produksi pengetahuan alternatif tentang pertanian dan pembangunan agraria.\n\nRelevansi konsep intelektual organik juga dapat dilihat dalam konteks **media alternatif** dan komunikasi politik. Dalam era digital, intelektual organik petani perlu mengembangkan kemampuan untuk menggunakan teknologi komunikasi untuk menyebarkan counter-narrative yang menantang hegemoni dominan. Ini melibatkan tidak hanya kemampuan teknis, tetapi juga kemampuan untuk mengartikulasikan pengalaman petani dalam bahasa yang dapat dipahami oleh audiens yang lebih luas.\n\n## Aplikasi Pemikiran Gramsci dalam Konteks Petani Indonesia\n\nAplikasi pemikiran Gramsci dalam konteks gerakan petani Indonesia memerlukan analisis konkret tentang bagaimana hegemoni neoliberal beroperasi di sektor pertanian dan bagaimana strategi counter-hegemonik dapat dikembangkan. **Kondisi objektif** petani Indonesia menunjukkan kontradiksi yang mendalam antara retorika pembangunan yang mengklaim pro-petani dengan realitas marginalisasi sistematis yang dialami petani kecil.\n\nHegemoni neoliberal di sektor pertanian Indonesia beroperasi melalui berbagai mekanisme yang saling terkait. Pertama, **diskursus modernisasi** yang menempatkan pertanian industrial sebagai model yang harus diikuti oleh semua petani. Diskursus ini diproduksi melalui sistem pendidikan pertanian, program penyuluhan, dan media massa yang secara konsisten mempromosikan teknologi intensif modal sebagai solusi untuk meningkatkan produktivitas. Kedua, **kebijakan struktural** seperti liberalisasi perdagangan, deregulasi investasi, dan program sertifikasi lahan yang memfasilitasi akumulasi kapital di sektor pertanian sambil memarginalkan petani kecil (White, 2012).\n\nDalam konteks ini, konsep **passive revolution** Gramsci membantu memahami bagaimana program-program seperti **Kredit Usaha Rakyat (KUR)** atau skema kemitraan dengan korporasi agribisnis berfungsi sebagai mekanisme untuk mengintegrasikan petani ke dalam sistem kapitalis tanpa mengubah relasi produksi yang eksploitatif. Program-program ini menciptakan ilusi partisipasi dan pemberdayaan sambil memperdalam ketergantungan petani terhadap input eksternal dan pasar global yang volatil.\n\nStrategi **war of position** dalam konteks petani Indonesia melibatkan perjuangan di berbagai front secara simultan. Di front ideologis, ini berarti mengembangkan **counter-narrative** yang menantang diskursus modernisasi dan mempromosikan model pertanian berkelanjutan yang berbasis pada pengetahuan lokal dan ekologi. Organisasi seperti Serikat Petani Indonesia (SPI) telah mengembangkan konsep **kedaulatan pangan** sebagai alternatif terhadap konsep ketahanan pangan yang lebih teknis dan depolitisasi (Patel, 2009).\n\n**Peran intelektual organik** dalam gerakan petani Indonesia dapat dilihat dalam figur-figur seperti Henry Saragih dari SPI atau aktivis-aktivis lokal yang berhasil mengartikulasikan pengalaman petani dalam bahasa politik yang koheren. Intelektual organik ini tidak hanya memiliki kemampuan untuk menganalisis kontradiksi struktural yang dihadapi petani, tetapi juga kemampuan untuk mengorganisir perlawanan kolektif melalui berbagai bentuk mobilisasi politik.\n\nKonsep **blok historis** membantu memahami pentingnya membangun aliansi strategis antara gerakan petani dengan sektor-sektor progresif lainnya. Dalam konteks Indonesia, ini melibatkan aliansi dengan gerakan lingkungan, gerakan buruh urban, organisasi masyarakat sipil, dan bahkan fraksi-fraksi progresif dalam birokrasi negara. **Aliansi lintas sektoral** ini penting karena petani secara numerik tidak cukup kuat untuk menantang hegemoni dominan secara sendirian.\n\nAplikasi konsep Gramsci juga relevan untuk memahami **resistensi sehari-hari** petani yang dijelaskan James Scott (1985) dalam *Weapons of the Weak*. Scott menunjukkan bahwa petani mengembangkan berbagai bentuk resistensi yang tidak terorganisir tetapi efektif dalam mengganggu dominasi kelas penguasa. Dalam kerangka Gramscian, resistensi sehari-hari ini dapat dipahami sebagai manifestasi dari kontradiksi antara *common sense* dan pengalaman konkret petani, yang dapat dikembangkan menjadi kesadaran kritis melalui intervensi intelektual organik.\n\n**Pendidikan politik** berbasis komunitas menjadi instrumen penting dalam strategi Gramscian. Serikat pekerja tani perlu mengembangkan program pendidikan yang tidak hanya fokus pada hak-hak legal petani, tetapi juga pada analisis struktural tentang bagaimana sistem kapitalis beroperasi di sektor pertanian. Program seperti **sekolah petani** yang dikembangkan berbagai organisasi petani dapat berfungsi sebagai ruang untuk mengembangkan kesadaran kritis dan membangun solidaritas kolektif.\n\nKonsep **subaltern** yang dikembangkan Gramsci dan diperluas oleh Gayatri Spivak (1988) juga relevan untuk memahami posisi petani perempuan dalam gerakan petani Indonesia. Spivak menunjukkan bahwa kelompok subaltern, terutama perempuan, menghadapi kesulitan untuk "berbicara" dalam ruang politik yang didominasi oleh logika maskulin dan elitis. Dalam konteks ini, strategi Gramscian perlu mencakup upaya khusus untuk mengembangkan kepemimpinan organik di kalangan petani perempuan dan memastikan bahwa suara mereka terintegrasi dalam agenda politik gerakan petani.\n\n## Kesimpulan\n\nAnalisis terhadap pemikiran Antonio Gramsci dalam konteks gerakan petani Indonesia menunjukkan relevansi yang signifikan dari konsep-konsep seperti hegemoni kultural, intelektual organik, dan war of position untuk mengembangkan strategi pengorganisasian yang lebih efektif. Hegemoni neoliberal di sektor pertanian Indonesia tidak hanya beroperasi melalui mekanisme ekonomi, tetapi juga melalui konstruksi ideologis yang sistematis yang menempatkan petani sebagai subjek yang harus disesuaikan dengan logika pasar global.\n\nKonsep **intelektual organik** menawarkan kerangka untuk memahami bagaimana kesadaran kritis dapat dikembangkan di kalangan petani melalui proses pendidikan politik yang berakar dalam pengalaman konkret mereka. Berbeda dengan pendekatan top-down yang mendominasi program pembangunan pertanian, pendekatan Gramscian menekankan pentingnya mengembangkan kepemimpinan yang berasal dari dalam komunitas petani sendiri dan mampu mengartikulasikan kepentingan petani dalam bahasa politik yang koheren.\n\nStrategi **war of position** menunjukkan bahwa perjuangan petani tidak dapat dibatasi pada mobilisasi ekonomi semata, tetapi harus mencakup perjuangan kultural untuk membangun counter-hegemony yang menawarkan visi alternatif tentang pembangunan agraria. Ini melibatkan pengembangan diskursus tandingan yang menantang narasi modernisasi dan mempromosikan model pertanian berkelanjutan yang berbasis pada kedaulatan pangan dan keadilan ekologis.\n\n**Implikasi praktis** dari analisis ini menunjukkan bahwa serikat pekerja tani perlu mengembangkan pendekatan yang lebih holistik dalam pengorganisasian, yang mengintegrasikan perjuangan material dengan perjuangan kultural. Program pendidikan politik berbasis komunitas, pengembangan media alternatif, dan pembangunan aliansi strategis dengan sektor progresif lainnya menjadi elemen-elemen penting dalam strategi ini.\n\nRekomendasi untuk gerakan petani Indonesia meliputi: pertama, pengembangan **program pendidikan politik** yang sistematis untuk mengembangkan kesadaran kritis di kalangan petani; kedua, pembangunan **kapasitas komunikasi politik** untuk mengembangkan narasi tandingan yang efektif; ketiga, penguatan **aliansi lintas sektoral** dengan gerakan sosial progresif lainnya; dan keempat, pengembangan **kepemimpinan organik** yang berakar dalam komunitas petani, terutama di kalangan petani perempuan dan petani muda.\n\nPemikiran Gramsci mengingatkan bahwa transformasi sosial yang fundamental memerlukan perubahan tidak hanya dalam struktur ekonomi, tetapi juga dalam struktur kesadaran dan kebudayaan. Bagi gerakan petani Indonesia, ini berarti bahwa perjuangan untuk keadilan agraria harus dipahami sebagai perjuangan hegemonik yang komprehensif untuk membangun tatanan sosial yang lebih demokratis dan berkelanjutan.\n\n## Daftar Pustaka\n\nGramsci, A. (1971). *Selections from the Prison Notebooks*. International Publishers.\n\nHadiz, V. R. (2010). *Localising Power in Post-Authoritarian Indonesia: A Southeast Asia Perspective*. Stanford University Press.\n\nKonsorsium Pembaruan Agraria. (2019). *Catatan Akhir Tahun 2019: Masa Depan Reforma Agraria di Bawah Ancaman Investasi*. KPA.\n\nPatel, R. (2009). Food sovereignty. *The Journal of Peasant Studies*, *36*(3), 663-706. https://doi.org/10.1080/03066150903143079\n\nPoulantzas, N. (1978). *State, Power, Socialism*. New Left Books.\n\nScott, J. C. (1985). *Weapons of the Weak: Everyday Forms of Peasant Resistance*. Yale University Press.\n\nSpivak, G. C. (1988). Can the subaltern speak? In C. Nelson & L. Grossberg (Eds.), *Marxism and the Interpretation of Culture* (pp. 271-313). University of Illinois Press.\n\nWhite, B. (2012). Agriculture and the generation problem: Rural youth, employment and the future of farming. *IDS Bulletin*, *43*(6), 9-19. https://doi.org/10.1111/j.1759-5436.2012.00375.x	8507	104257	\N	manual	2026-04-17 23:31:18	2026-04-17 23:33:02
1	1	\N	43	completed	openrouter	anthropic/claude-4-sonnet-20250522	Tulis sebuah essay akademik dengan topik: "Teori Nilai-Lebih dan Eksploitasi Buruh Tani di Jawa Barat".\n\nKonteks dan sudut pandang: Analisis relevansi teori surplus value Marx terhadap kondisi buruh tani di Karawang dan Jawa Barat kontemporer, termasuk mekanisme ekstraksi nilai-lebih melalui upah rendah, rent-seeking, dan ketergantungan input korporat.\n\nKerangka pikir utama: Marxisme klasik (Marx, Engels, Kautsky).\n\nReferensi WAJIB disitasi (boleh tambah referensi lain yang relevan dan nyata):\n- Marx, K. (1867). *Das Kapital, Volume I*.\n- Bernstein, H. (2010). *Class Dynamics of Agrarian Change*.\n- Konsorsium Pembaruan Agraria (2023). *Catatan Akhir Tahun 2023*.\n- Wiradi, G. (2000). *Reforma Agraria: Perjalanan yang Belum Berakhir*.	# Teori Nilai-Lebih dan Eksploitasi Buruh Tani di Jawa Barat: Analisis Marxis terhadap Kondisi Agraria Kontemporer\n\n## Abstrak\n\nArtikel ini menganalisis relevansi teori nilai-lebih Karl Marx dalam memahami eksploitasi buruh tani di Jawa Barat, khususnya di Karawang. Melalui pendekatan Marxisme klasik, penelitian ini mengkaji mekanisme ekstraksi surplus value yang dialami petani dan buruh tani melalui sistem upah rendah, rent-seeking, dan ketergantungan terhadap input produksi korporat. Analisis menunjukkan bahwa transformasi agraria di Jawa Barat telah menciptakan kondisi yang memungkinkan kapitalis agraria mengekstraksi nilai-lebih melalui tiga mekanisme utama: eksploitasi tenaga kerja langsung, monopoli atas alat produksi, dan kontrol terhadap rantai distribusi. Kondisi ini diperparah oleh kebijakan neoliberal yang memprioritaskan efisiensi pasar di atas keadilan sosial. Studi ini menyimpulkan bahwa teori Marx tetap relevan dalam memahami dinamika kelas agraria kontemporer, di mana akumulasi kapital berlangsung melalui pemiskinan struktural petani kecil dan proletarisasi buruh tani. Implikasi teoretis dan praktis dari temuan ini mengarah pada perlunya reorganisasi hubungan produksi agraria yang lebih adil melalui reforma agraria sejati dan penguatan organisasi petani.\n\n## Pendahuluan\n\nTransformasi agraria di Indonesia, khususnya di Jawa Barat, telah mengalami perubahan fundamental sejak era Orde Baru hingga saat ini. Provinsi yang menjadi lumbung padi nasional ini menghadapi paradoks: produktivitas meningkat, namun kesejahteraan petani justru menurun. Fenomena ini tidak dapat dipahami secara memadai tanpa menggunakan kerangka analisis yang mampu mengungkap relasi produksi yang sesungguhnya terjadi di pedesaan.\n\nTeori nilai-lebih (surplus value) yang dikembangkan Karl Marx dalam *Das Kapital* menawarkan instrumen analitis yang tajam untuk memahami mekanisme eksploitasi dalam sistem produksi kapitalis (Marx, 1867). Meskipun dikembangkan dalam konteks industrialisasi Eropa abad ke-19, teori ini memiliki relevansi yang signifikan untuk memahami dinamika agraria kontemporer, termasuk di Jawa Barat.\n\nPermasalahan utama yang dihadapi buruh tani di Jawa Barat adalah eksploitasi sistematis yang terjadi melalui berbagai mekanisme: upah yang tidak sebanding dengan nilai yang diproduksi, ketergantungan terhadap input produksi yang dikuasai korporat, dan sistem bagi hasil yang merugikan petani penggarap. Kondisi ini menciptakan akumulasi kapital di satu sisi dan pemiskinan struktural di sisi lain.\n\nArtikel ini berargumen bahwa teori nilai-lebih Marx tetap relevan untuk menganalisis eksploitasi buruh tani di Jawa Barat. Melalui pemahaman terhadap mekanisme ekstraksi surplus value, kita dapat mengidentifikasi akar struktural kemiskinan agraria dan merumuskan strategi perlawanan yang tepat.\n\n## Kerangka Teoretis: Nilai-Lebih dalam Produksi Agraria\n\n### Konsep Dasar Teori Nilai-Lebih Marx\n\nKarl Marx dalam *Das Kapital* menjelaskan bahwa nilai-lebih merupakan sumber keuntungan kapitalis yang diperoleh dari eksploitasi tenaga kerja (Marx, 1867). Dalam proses produksi, pekerja menghasilkan nilai yang lebih besar daripada nilai tenaga kerjanya sendiri. Selisih antara nilai yang diproduksi dengan upah yang diterima pekerja inilah yang disebut nilai-lebih.\n\nMarx membedakan dua bentuk nilai-lebih: absolut dan relatif. Nilai-lebih absolut diperoleh melalui perpanjangan jam kerja tanpa menaikkan upah, sedangkan nilai-lebih relatif diperoleh melalui peningkatan produktivitas yang memungkinkan pengurangan waktu kerja yang diperlukan untuk mereproduksi nilai tenaga kerja (Marx, 1867).\n\nDalam konteks agraria, konsep ini dapat diaplikasikan untuk memahami bagaimana pemilik modal (tuan tanah, korporat agribisnis, tengkulak) mengekstraksi nilai dari kerja petani dan buruh tani. Proses ini tidak selalu terjadi melalui hubungan upah langsung, tetapi juga melalui berbagai bentuk rent dan kontrol atas alat produksi.\n\n### Aplikasi Teori dalam Konteks Agraria\n\nHenry Bernstein dalam *Class Dynamics of Agrarian Change* memperluas analisis Marxis ke dalam konteks agraria dengan memperkenalkan konsep "petty commodity production" dan "subsumption of labour to capital" (Bernstein, 2010). Menurut Bernstein, transformasi agraria kapitalis tidak selalu menghasilkan proletarisasi penuh, tetapi sering kali menciptakan bentuk-bentuk hibrida di mana petani kecil tetap memiliki akses terbatas terhadap alat produksi namun tunduk pada logika akumulasi kapital.\n\nDalam konteks Indonesia, Gunawan Wiradi mengidentifikasi bahwa problema agraria tidak hanya berkaitan dengan distribusi tanah, tetapi juga dengan struktur sosial yang memungkinkan eksploitasi berlangsung (Wiradi, 2000). Analisis Wiradi menunjukkan bahwa reforma agraria tidak dapat dipisahkan dari transformasi hubungan produksi yang lebih fundamental.\n\n## Kondisi Objektif Buruh Tani di Jawa Barat\n\n### Struktur Kepemilikan Tanah dan Proletarisasi\n\nData Konsorsium Pembaruan Agraria menunjukkan bahwa konsentrasi kepemilikan tanah di Jawa Barat semakin menguat (Konsorsium Pembaruan Agraria, 2023). Sebagian besar petani hanya menguasai lahan kurang dari 0,5 hektar, sementara sebagian kecil elit agraria menguasai lahan dalam skala besar. Kondisi ini menciptakan ketergantungan struktural di mana petani kecil harus menjual tenaga kerjanya kepada pemilik modal yang lebih besar.\n\nProses proletarisasi ini tidak terjadi secara linear. Banyak petani yang mengalami "semi-proletarisasi", di mana mereka masih memiliki akses terbatas terhadap tanah tetapi harus bekerja sebagai buruh tani untuk memenuhi kebutuhan hidupnya. Kondisi ini menciptakan surplus tenaga kerja yang memungkinkan kapitalis agraria menekan upah di bawah nilai reproduksi tenaga kerja.\n\n### Mekanisme Ekstraksi Nilai-Lebih\n\nEkstraksi nilai-lebih dalam sektor agraria Jawa Barat terjadi melalui beberapa mekanisme:\n\n**Pertama**, sistem upah harian yang tidak mencerminkan produktivitas sesungguhnya. Buruh tani di Karawang rata-rata menerima upah Rp 80.000-100.000 per hari untuk jam kerja 8-10 jam, sementara nilai produksi yang dihasilkan jauh lebih besar. Diskrepansi ini memungkinkan pemilik modal mengakumulasi surplus value yang substansial.\n\n**Kedua**, sistem bagi hasil yang timpang. Petani penggarap umumnya hanya menerima 30-40% dari hasil panen, sementara pemilik tanah yang tidak terlibat langsung dalam produksi menerima 60-70%. Sistem ini memungkinkan ekstraksi rent yang tidak sebanding dengan kontribusi produktif.\n\n**Ketiga**, monopoli input produksi oleh korporat agribisnis. Petani terpaksa membeli benih, pupuk, dan pestisida dengan harga tinggi dari perusahaan multinasional, sementara harga jual produk pertanian ditentukan oleh mekanisme pasar yang dikuasai tengkulak dan korporat.\n\n## Transformasi Agraria dan Akumulasi Kapital\n\n### Revolusi Hijau dan Subsumsi Formal Tenaga Kerja\n\nRevolusi Hijau yang dimulai pada era Orde Baru telah mengubah karakter produksi pertanian di Jawa Barat dari subsisten menjadi berorientasi pasar. Transformasi ini, meskipun meningkatkan produktivitas, juga menciptakan ketergantungan petani terhadap input eksternal dan teknologi yang dikuasai korporat multinasional.\n\nMarx menganalisis bagaimana kapital secara bertahap mensubsumsi proses kerja, pertama secara formal kemudian secara riil (Marx, 1867). Dalam konteks Jawa Barat, subsumsi formal terjadi ketika petani tetap menggunakan teknik tradisional tetapi produksinya sudah berorientasi pasar. Subsumsi riil terjadi ketika proses produksi itu sendiri direorganisasi sesuai dengan logika kapital, seperti penggunaan mesin, monokultur, dan standardisasi.\n\n### Akumulasi Primitif Kontemporer\n\nDavid Harvey mengembangkan konsep "accumulation by dispossession" untuk menjelaskan bagaimana akumulasi kapital kontemporer berlangsung melalui perampasan aset-aset yang sebelumnya berada di luar logika pasar (Harvey, 2003). Dalam konteks Jawa Barat, proses ini terjadi melalui konversi lahan pertanian menjadi kawasan industri dan perumahan, privatisasi sumber daya air, dan komersialisasi benih lokal.\n\nProses akumulasi primitif ini tidak hanya terjadi sekali pada awal perkembangan kapitalisme, tetapi berlangsung secara kontinyu sebagai mekanisme untuk mengatasi krisis akumulasi. Petani yang kehilangan tanahnya terpaksa menjadi buruh industri atau buruh tani dengan upah rendah, menciptakan surplus tenaga kerja yang menguntungkan kapital.\n\n## Resistensi dan Organisasi Petani\n\n### Bentuk-Bentuk Perlawanan\n\nJames C. Scott dalam *Weapons of the Weak* mengidentifikasi berbagai bentuk resistensi sehari-hari yang dilakukan petani terhadap eksploitasi (Scott, 1985). Di Jawa Barat, resistensi ini mengambil berbagai bentuk: dari sabotase halus terhadap sistem kerja hingga pembentukan organisasi petani yang lebih terstruktur.\n\nSerikat Pekerja Tani Karawang (SEPETAK) merupakan salah satu contoh organisasi yang berupaya melawan eksploitasi struktural melalui pendidikan politik, advokasi kebijakan, dan aksi kolektif. Organisasi ini menyadari bahwa perlawanan individual tidak akan mampu mengubah struktur eksploitasi yang sistemik.\n\n### Strategi Transformasi Struktural\n\nPerlawanan terhadap eksploitasi nilai-lebih tidak dapat hanya mengandalkan peningkatan upah atau perbaikan kondisi kerja yang parsial. Diperlukan transformasi struktural yang mengubah hubungan produksi itu sendiri. Hal ini mencakup:\n\nRedistribusi tanah yang genuine, bukan hanya sertifikasi lahan yang sudah ada. Reforma agraria sejati harus mengubah struktur kepemilikan yang timpang dan memberikan akses yang adil terhadap sumber daya produktif.\n\nPenguatan ekonomi kolektif melalui koperasi produksi, pengolahan, dan pemasaran yang dikontrol petani. Ini akan mengurangi ketergantungan terhadap tengkulak dan korporat agribisnis.\n\nPengembangan teknologi yang sesuai dengan kebutuhan petani kecil, bukan teknologi yang memperkuat dominasi korporat multinasional.\n\n## Kesimpulan\n\nAnalisis terhadap kondisi buruh tani di Jawa Barat melalui kerangka teori nilai-lebih Marx menunjukkan bahwa eksploitasi yang dialami petani bukan sekadar fenomena pasar, tetapi merupakan konsekuensi logis dari struktur hubungan produksi kapitalis. Ekstraksi surplus value terjadi melalui berbagai mekanisme yang saling terkait: upah rendah, sistem bagi hasil yang timpang, monopoli input produksi, dan akumulasi primitif yang berkelanjutan.\n\nTransformasi agraria yang terjadi sejak Revolusi Hijau telah mengintegrasikan petani Jawa Barat ke dalam sistem produksi kapitalis global, namun dalam posisi yang subordinat. Petani kehilangan kontrol atas proses produksi dan terpaksa menerima bagian yang kecil dari nilai yang mereka ciptakan.\n\nTeori Marx tetap relevan karena mampu mengungkap kontradiksi fundamental dalam sistem produksi agraria kapitalis. Peningkatan produktivitas tidak otomatis meningkatkan kesejahteraan petani selama struktur eksploitasi tetap dipertahankan. Sebaliknya, produktivitas yang tinggi justru memungkinkan ekstraksi surplus value yang lebih besar.\n\nImplikasi praktis dari analisis ini adalah perlunya strategi transformasi yang tidak hanya berfokus pada peningkatan pendapatan petani secara individual, tetapi pada perubahan struktur hubungan produksi. Reforma agraria, penguatan organisasi petani, dan pengembangan ekonomi kolektif merupakan elemen-elemen penting dalam strategi transformasi struktural.\n\nOrganisasi seperti SEPETAK memiliki peran strategis dalam membangun kesadaran kelas di kalangan petani dan buruh tani. Melalui pendidikan politik dan aksi kolektif, organisasi petani dapat menjadi kekuatan penggerak perubahan struktural yang diperlukan untuk mengakhiri eksploitasi sistematis terhadap produsen pangan.\n\n## Daftar Pustaka\n\nBernstein, H. (2010). *Class dynamics of agrarian change*. Fernwood Publishing.\n\nHarvey, D. (2003). *The new imperialism*. Oxford University Press.\n\nKonsorsium Pembaruan Agraria. (2023). *Catatan akhir tahun 2023: Reforma agraria di tengah pusaran krisis multidimensional*. KPA.\n\nMarx, K. (1867). *Das Kapital: A critique of political economy, Volume I*. Progress Publishers.\n\nScott, J. C. (1985). *Weapons of the weak: Everyday forms of peasant resistance*. Yale University Press.\n\nWiradi, G. (2000). *Reforma agraria: Perjalanan yang belum berakhir*. KPA-Pustaka Pelajar.	4773	57599	\N	manual	2026-04-17 23:04:20	2026-04-17 23:05:17
5	5	\N	47	completed	openrouter	anthropic/claude-4-sonnet-20250522	═══ INSTRUKSI PENULISAN ═══\n\nTulis sebuah **essay akademik** dengan topik:\n\n> **Akumulasi melalui Perampasan: David Harvey dan Konflik Agraria di Indonesia**\n\n**Konteks dan sudut pandang:**\nMenganalisis teori accumulation by dispossession Harvey untuk memahami konflik agraria kontemporer di Indonesia, termasuk land grabbing dan proyek infrastruktur.\n\n**Kerangka pikir utama:** Neo-Marxian (Gramsci, Harvey, Wallerstein, Poulantzas)\n\n**Referensi WAJIB** (harus disitasi di artikel, boleh tambah referensi lain yang relevan dan nyata):\n- Harvey, D. (2003). *The New Imperialism*.\n- Harvey, D. (2005). *A Brief History of Neoliberalism*.\n- Rachman, N. F. (2012). *Land Reform dari Masa ke Masa*.\n- Konsorsium Pembaruan Agraria (2023). *Catatan Akhir Tahun 2023*.\n\n═══ MULAI MENULIS ═══\n\nTulis artikelnya sekarang. Mulai langsung dari judul (# Judul), lalu metadata, daftar isi, dan seterusnya sesuai struktur yang ditentukan.	# Akumulasi melalui Perampasan: David Harvey dan Konflik Agraria di Indonesia\n\n**Kata Kunci:** accumulation by dispossession, David Harvey, konflik agraria, land grabbing, neoliberalisme\n**Waktu Baca:** ± 15 menit\n\n## Daftar Isi\n\n1. Abstrak\n2. Pendahuluan\n3. Teori Akumulasi melalui Perampasan David Harvey\n4. Manifestasi Akumulasi Primitif di Indonesia Kontemporer\n5. Mekanisme Perampasan dalam Proyek Pembangunan dan Investasi\n6. Resistensi Petani dan Kontradiksi Akumulasi Kapital\n7. Kesimpulan\n8. Daftar Pustaka\n\n## Abstrak\n\nArtikel ini menganalisis fenomena konflik agraria di Indonesia kontemporer melalui kerangka teori **accumulation by dispossession** yang dikembangkan oleh David Harvey. Penelitian ini menggunakan pendekatan analisis neo-Marxian untuk memahami bagaimana mekanisme akumulasi primitif yang dikonseptualisasikan Marx tidak hanya terjadi pada fase awal kapitalisme, tetapi terus berlangsung sebagai strategi pemecahan krisis kapital. Temuan menunjukkan bahwa konflik agraria di Indonesia—mulai dari land grabbing untuk perkebunan kelapa sawit, proyek infrastruktur strategis nasional, hingga kawasan ekonomi khusus—merupakan manifestasi konkret dari proses perampasan sistematis yang memungkinkan akumulasi kapital melalui penciptaan "primitive accumulation" berkelanjutan. Mekanisme ini difasilitasi oleh kebijakan neoliberal yang mentransformasikan tanah dari nilai guna menjadi komoditas, sekaligus menciptakan surplus tenaga kerja melalui proletarisasi petani. Resistensi petani dan komunitas adat menunjukkan kontradiksi inheren dalam proses akumulasi ini, yang memerlukan intervensi negara yang semakin represif untuk mempertahankan kondisi akumulasi. Artikel ini menyimpulkan bahwa memahami konflik agraria melalui lensa Harvey memberikan kerangka analitis yang lebih komprehensif untuk memahami dinamika kapitalisme kontemporer di Indonesia.\n\n## Pendahuluan\n\nKonflik agraria di Indonesia telah mencapai intensitas yang mengkhawatirkan dalam dua dekade terakhir. Data Konsorsium Pembaruan Agraria (2023) mencatat 212 konflik agraria sepanjang tahun 2023 dengan luas wilayah sengketa mencapai 324.717 hektare, melibatkan 145.793 kepala keluarga petani. Angka ini menunjukkan tren peningkatan yang konsisten sejak era reformasi, mengindikasikan bahwa persoalan agraria bukan sekadar masalah teknis distribusi lahan, melainkan manifestasi dari kontradiksi struktural yang lebih fundamental dalam sistem ekonomi politik Indonesia.\n\nDalam konteks teoretis, fenomena ini memerlukan kerangka analisis yang mampu menjelaskan tidak hanya dimensi ekonomi konflik agraria, tetapi juga relasi kuasa yang memungkinkan terjadinya perampasan sistematis atas sumber daya agraria. Teori **accumulation by dispossession** yang dikembangkan David Harvey (2003, 2005) menawarkan perspektif analitis yang relevan untuk memahami dinamika ini. Harvey mengembangkan konsep Marx tentang akumulasi primitif (*primitive accumulation*) dengan argumen bahwa proses perampasan bukan hanya terjadi pada fase awal kapitalisme, tetapi merupakan strategi berkelanjutan untuk mengatasi krisis akumulasi kapital.\n\nPermasalahan utama yang hendak dijawab dalam artikel ini adalah: bagaimana teori accumulation by dispossession Harvey dapat menjelaskan pola dan mekanisme konflik agraria di Indonesia kontemporer? Lebih spesifik, artikel ini akan menganalisis bagaimana proses perampasan tanah dan sumber daya alam difasilitasi oleh kebijakan neoliberal, sekaligus mengkaji resistensi yang muncul dari komunitas petani sebagai respons terhadap proses akumulasi tersebut.\n\nTesis utama artikel ini adalah bahwa konflik agraria di Indonesia merupakan manifestasi konkret dari accumulation by dispossession, di mana negara berperan aktif memfasilitasi perampasan sumber daya agraria untuk kepentingan akumulasi kapital domestik dan internasional. Proses ini tidak hanya menciptakan surplus value melalui eksploitasi tenaga kerja, tetapi juga melalui apropriasi langsung atas *commons* dan transformasi nilai guna menjadi nilai tukar.\n\nArtikel ini akan diorganisir dalam empat bagian pembahasan utama. Pertama, elaborasi teoretis mengenai konsep accumulation by dispossession Harvey dan relevansinya dengan kondisi Indonesia. Kedua, identifikasi manifestasi konkret akumulasi primitif dalam konteks agraria Indonesia kontemporer. Ketiga, analisis mekanisme perampasan dalam proyek-proyek pembangunan dan investasi. Keempat, pembahasan mengenai resistensi petani dan kontradiksi yang muncul dalam proses akumulasi kapital.\n\n## Teori Akumulasi melalui Perampasan David Harvey\n\nDavid Harvey dalam *The New Imperialism* (2003) mengembangkan konsep Marx tentang akumulasi primitif menjadi teori yang lebih komprehensif tentang **accumulation by dispossession**. Marx dalam *Das Kapital* menjelaskan bahwa akumulasi primitif merupakan proses historis yang memisahkan produsen langsung dari alat-alat produksi, khususnya tanah, sehingga menciptakan kondisi bagi berkembangnya hubungan produksi kapitalis. Namun Harvey berargumen bahwa proses ini bukan hanya fenomena historis yang terjadi sekali pada awal kapitalisme, melainkan strategi berkelanjutan yang digunakan kapital untuk mengatasi krisis akumulasi.\n\nKonsep accumulation by dispossession Harvey dibangun atas kritik terhadap teori imperialisme klasik yang cenderung menekankan eksploitasi surplus value melalui hubungan kerja upahan. Harvey menunjukkan bahwa kapitalisme kontemporer juga bergantung pada apropriasi langsung atas aset-aset yang sebelumnya berada di luar sphere pasar. Proses ini melibatkan transformasi berbagai bentuk hak kepemilikan—komunal, kolektif, atau negara—menjadi hak kepemilikan privat yang dapat diperdagangkan di pasar.\n\nRosa Luxemburg dalam *The Accumulation of Capital* telah mengantisipasi argumen Harvey dengan menekankan bahwa kapitalisme memerlukan "lingkungan non-kapitalis" untuk terus berakumulasi. Harvey mengembangkan insight Luxemburg dengan menunjukkan bahwa penciptaan lingkungan non-kapitalis ini bukan hanya terjadi melalui ekspansi geografis, tetapi juga melalui komodifikasi aspek-aspek kehidupan yang sebelumnya belum terkomodifikasi.\n\nMekanisme accumulation by dispossession menurut Harvey (2005) meliputi empat proses utama. Pertama, **privatisasi dan komodifikasi** aset-aset publik dan komunal, termasuk tanah, air, udara, dan bahkan layanan publik seperti pendidikan dan kesehatan. Kedua, **finansialisasi** yang memungkinkan akumulasi melalui manipulasi sistem kredit dan utang. Ketiga, **manajemen dan manipulasi krisis** yang menciptakan peluang akumulasi melalui devaluasi aset. Keempat, **redistribusi negara** melalui kebijakan yang menguntungkan kelas kapitalis.\n\nDalam konteks agraria, accumulation by dispossession terutama termanifestasi melalui proses **land grabbing** dan transformasi sistem tenure tanah. Harvey menekankan bahwa tanah memiliki karakteristik unik sebagai komoditas karena tidak dapat diproduksi dan memiliki lokasi tetap. Hal ini menciptakan potensi **monopoly rent** yang sangat menguntungkan bagi pemilik kapital yang berhasil mengontrol tanah-tanah strategis.\n\nPeran negara dalam proses ini sangat krusial. Harvey mengadaptasi konsep Gramsci tentang hegemoni untuk menjelaskan bagaimana negara tidak hanya menggunakan koersi, tetapi juga konsensus untuk melegitimasi proses perampasan. Negara menciptakan kerangka hukum dan regulasi yang memfasilitasi akumulasi, sekaligus mengembangkan narasi pembangunan yang menjustifikasi perampasan sebagai "kepentingan nasional".\n\nKritik terhadap teori Harvey terutama datang dari perspektif yang menekankan agency komunitas lokal dan kompleksitas relasi kuasa di tingkat lokal. Namun, kekuatan analitis teori Harvey terletak pada kemampuannya menghubungkan fenomena lokal dengan dinamika kapitalisme global, sekaligus menunjukkan kontinuitas historis antara akumulasi primitif klasik dengan perampasan kontemporer.\n\n> **Poin Penting:** Teori accumulation by dispossession Harvey memberikan kerangka analitis untuk memahami bagaimana kapitalisme kontemporer tidak hanya bergantung pada eksploitasi tenaga kerja, tetapi juga pada apropriasi langsung atas commons melalui mekanisme perampasan yang difasilitasi negara.\n\n## Manifestasi Akumulasi Primitif di Indonesia Kontemporer\n\nTransformasi ekonomi politik Indonesia sejak era Orde Baru hingga kontemporer menunjukkan manifestasi konkret dari accumulation by dispossession dalam berbagai bentuk. Proses ini dipercepat melalui adopsi kebijakan neoliberal yang dimulai pada 1980-an dan mengalami intensifikasi pasca-krisis 1997-1998 melalui program structural adjustment yang dipaksakan IMF dan Bank Dunia.\n\n**Land grabbing** untuk ekspansi perkebunan kelapa sawit merupakan manifestasi paling masif dari accumulation by dispossession di Indonesia. Data Sawit Watch menunjukkan bahwa luas perkebunan kelapa sawit meningkat dari 294.560 hektare pada 1980 menjadi lebih dari 16 juta hektare pada 2020. Ekspansi ini tidak hanya melibatkan konversi hutan, tetapi juga perampasan tanah-tanah komunal dan adat yang telah dikelola secara berkelanjutan oleh komunitas lokal selama berabad-abad.\n\nMekanisme perampasan ini difasilitasi melalui instrumen hukum seperti Hak Guna Usaha (HGU) yang memberikan akses eksklusif kepada korporasi atas tanah-tanah yang diklaim sebagai "tanah negara". Konsep tanah negara sendiri merupakan produk kolonial yang diadopsi dan diperluas oleh rezim post-kolonial untuk memfasilitasi akumulasi kapital. Undang-Undang Pokok Agraria 1960 yang sebenarnya dimaksudkan untuk melakukan redistribusi lahan justru menjadi instrumen legitimasi bagi perampasan melalui klausul "fungsi sosial" yang ditafsirkan secara sepihak oleh negara.\n\nKasus perkebunan kelapa sawit di Kalimantan dan Sumatera menunjukkan bagaimana proses accumulation by dispossession beroperasi. Komunitas Dayak dan Melayu yang telah mengelola hutan dan lahan secara adat dipaksa melepaskan tanah mereka dengan kompensasi yang tidak memadai atau bahkan tanpa kompensasi sama sekali. Tanah-tanah tersebut kemudian ditransformasikan menjadi monokultur kelapa sawit yang menghasilkan profit bagi korporasi multinasional dan domestik.\n\nProyek infrastruktur strategis nasional juga menjadi arena penting accumulation by dispossession. Program seperti pembangunan jalan tol, bandara, dan kawasan industri melibatkan pembebasan lahan dalam skala masif. Undang-Undang Nomor 2 Tahun 2012 tentang Pengadaan Tanah bagi Pembangunan untuk Kepentingan Umum memberikan kewenangan luas kepada negara untuk melakukan pencabutan hak atas tanah dengan dalih "kepentingan umum" yang didefinisikan secara elastis.\n\nKasus pembangunan Bandara Internasional Yogyakarta di Kulon Progo mengilustrasikan mekanisme ini. Petani yang tanahnya dibebaskan tidak hanya kehilangan akses terhadap means of production, tetapi juga tercerabut dari sistem sosial-ekonomi yang telah mereka bangun. Kompensasi yang diberikan tidak mempertimbangkan nilai sosial dan budaya tanah, hanya nilai ekonomi yang ditetapkan secara sepihak oleh negara.\n\n**Finansialisasi** tanah juga menjadi dimensi penting accumulation by dispossession di Indonesia. Tanah semakin diperlakukan sebagai aset finansial yang dapat diperjualbelikan, diagunkan, dan dijadikan instrumen spekulasi. Real Estate Investment Trusts (REITs) dan berbagai produk derivatif properti menciptakan gelembung spekulatif yang menaikkan harga tanah secara artifisial, sehingga semakin menyulitkan akses petani dan masyarakat miskin terhadap tanah.\n\nKawasan Ekonomi Khusus (KEK) yang dikembangkan di berbagai daerah juga merupakan manifestasi accumulation by dispossession. KEK menciptakan enclave ekonomi yang memberikan privilese khusus kepada investor, termasuk kemudahan perizinan, insentif fiskal, dan akses terhadap tanah dengan harga murah. Pembentukan KEK sering kali melibatkan perampasan tanah produktif milik petani yang kemudian ditransformasikan menjadi zona akumulasi kapital.\n\n> **Poin Penting:** Manifestasi accumulation by dispossession di Indonesia terjadi melalui multiple channels—ekspansi perkebunan, proyek infrastruktur, finansialisasi tanah, dan pembentukan KEK—yang semuanya difasilitasi oleh transformasi kerangka hukum dan regulasi yang mengutamakan kepentingan akumulasi kapital atas hak-hak komunitas lokal.\n\n## Mekanisme Perampasan dalam Proyek Pembangunan dan Investasi\n\nAnalisis mekanisme perampasan dalam konteks proyek pembangunan dan investasi di Indonesia menunjukkan sofistikasi strategi accumulation by dispossession yang melibatkan kolaborasi kompleks antara negara, kapital domestik, dan kapital internasional. Mekanisme ini beroperasi melalui multiple layers yang saling memperkuat, mulai dari transformasi kerangka hukum hingga penggunaan aparatus keamanan untuk menekan resistensi.\n\n**Transformasi kerangka hukum** menjadi instrumen utama dalam memfasilitasi perampasan. Rachman (2012) menunjukkan bahwa reformasi hukum agraria pasca-1998 justru memperkuat orientasi neoliberal dalam pengelolaan sumber daya alam. Undang-Undang Nomor 25 Tahun 2007 tentang Penanaman Modal memberikan jaminan kepastian investasi yang ditafsirkan sebagai prioritas akses investor terhadap tanah dan sumber daya alam. Regulasi ini menciptakan hierarki hak yang menempatkan hak investor di atas hak komunitas lokal.\n\nKonsep "highest and best use" yang diadopsi dalam berbagai regulasi mencerminkan logika kapitalis yang mereduksi tanah menjadi faktor produksi yang harus dioptimalkan untuk menghasilkan nilai tukar maksimal. Konsep ini mengabaikan dimensi sosial, budaya, dan ekologis tanah yang tidak dapat dikuantifikasi dalam perhitungan ekonomi konvensional. Sebagaimana Harvey (2001) argumentasikan, reduksi tanah menjadi komoditas merupakan bentuk "commodity fetishism" yang menyembunyikan relasi sosial di balik pertukaran ekonomi.\n\n**Mekanisme kompensasi** yang diterapkan dalam pembebasan lahan juga mencerminkan logika accumulation by dispossession. Kompensasi dihitung berdasarkan Nilai Jual Objek Pajak (NJOP) yang umumnya jauh di bawah harga pasar, apalagi jika dibandingkan dengan nilai produktivitas jangka panjang tanah tersebut. Sistem kompensasi ini tidak mengakui konsep **reproduction cost**—biaya yang diperlukan untuk mereproduksi kondisi sosial-ekonomi yang hilang akibat perampasan tanah.\n\nKasus pembangunan pabrik semen di Rembang menunjukkan bagaimana mekanisme kompensasi menjadi instrumen perampasan. Petani tidak hanya kehilangan tanah pertanian, tetapi juga akses terhadap mata air yang selama ini menjadi sumber irigasi. Kompensasi yang diberikan tidak memperhitungkan kerugian ekologis dan sosial jangka panjang, sehingga menciptakan **environmental debt** yang ditanggung oleh komunitas lokal.\n\n**Fragmentasi resistensi** menjadi strategi penting dalam melancarkan proses perampasan. Korporasi dan negara menggunakan berbagai taktik untuk memecah solidaritas komunitas, termasuk pemberian kompensasi yang berbeda-beda, rekrutmen tokoh lokal sebagai mediator, dan penciptaan konflik horizontal antar kelompok masyarakat. Strategi ini mencerminkan apa yang Gramsci sebut sebagai "transformisme"—kooptasi elemen-elemen oposisi ke dalam blok hegemonik yang dominan.\n\n**Militarisasi** wilayah konflik agraria juga menjadi mekanisme penting dalam memfasilitasi accumulation by dispossession. Data KPA menunjukkan bahwa 70% konflik agraria melibatkan kekerasan dari aparatus keamanan negara. Kekerasan ini bukan sekadar efek samping dari konflik, tetapi strategi sistematis untuk menciptakan kondisi yang kondusif bagi akumulasi kapital. Sebagaimana Harvey (2003) jelaskan, "the state's monopoly of violence and definitions of legality" menjadi instrumen krusial dalam proses perampasan.\n\nKasus Mesuji di Lampung mengilustrasikan bagaimana kekerasan negara difungsikan untuk memfasilitasi ekspansi perkebunan. Petani yang melakukan okupasi lahan yang diklaim sebagai HGU perusahaan menghadapi represi brutal dari gabungan TNI, Polri, dan preman bayaran perusahaan. Kekerasan ini menciptakan **climate of fear** yang memaksa petani melepaskan klaim mereka atas tanah.\n\n**Diskursif hegemoni** pembangunan juga berperan dalam melegitimasi perampasan. Narasi "pembangunan untuk kesejahteraan rakyat" dan "percepatan pertumbuhan ekonomi" digunakan untuk menjustifikasi pengorbanan hak-hak komunitas lokal demi "kepentingan yang lebih besar". Diskursus ini menciptakan false choice antara pembangunan dan konservasi, antara modernitas dan tradisi, yang menyembunyikan kemungkinan alternatif pembangunan yang lebih adil dan berkelanjutan.\n\n> **Poin Penting:** Mekanisme perampasan dalam proyek pembangunan beroperasi melalui transformasi hukum, manipulasi kompensasi, fragmentasi resistensi, militarisasi, dan hegemoni diskursif yang secara sinergis menciptakan kondisi optimal bagi accumulation by dispossession sambil meminimalkan potensi resistensi terorganisir.\n\n## Resistensi Petani dan Kontradiksi Akumulasi Kapital\n\nProses accumulation by dispossession tidak berlangsung tanpa resistensi. Komunitas petani dan masyarakat adat di Indonesia telah mengembangkan berbagai bentuk perlawanan yang menunjukkan kontradiksi inheren dalam sistem akumulasi kapitalis. Resistensi ini tidak hanya berfungsi sebagai respons defensif terhadap perampasan, tetapi juga sebagai artikulasi alternatif model pembangunan yang lebih demokratis dan berkelanjutan.\n\n**Resistensi terorganisir** melalui serikat-serikat petani seperti Serikat Petani Indonesia (SPI), Aliansi Gerakan Reforma Agraria (AGRA), dan berbagai organisasi lokal menunjukkan kapasitas petani dalam membangun solidaritas lintas wilayah. Organisasi-organisasi ini tidak hanya melakukan advokasi kebijakan, tetapi juga memfasilitasi **land occupation** sebagai bentuk direct action untuk merebut kembali tanah yang dirampas. Gerakan okupasi lahan di berbagai daerah—dari Jenggawah di Jember hingga Mesuji di Lampung—menunjukkan bahwa petani tidak pasif menerima perampasan.\n\nKonsep **kedaulatan pangan** yang diperjuangkan gerakan petani merupakan counter-hegemoni terhadap logika accumulation by dispossession. Kedaulatan pangan tidak hanya menekankan aspek teknis produksi pertanian, tetapi juga kontrol demokratis atas sistem pangan, akses terhadap tanah dan benih, serta penolakan terhadap komodifikasi pangan. Konsep ini menantang fundamental assumption kapitalisme bahwa efisiensi pasar merupakan mekanisme optimal untuk alokasi sumber daya.\n\n**Revitalisasi sistem pengelolaan komunal** juga menjadi bentuk resistensi penting terhadap privatisasi tanah. Berbagai komunitas adat berupaya memperkuat sistem tenure tradisional sebagai alternatif terhadap sistem kepemilikan individual yang rentan terhadap komodifikasi. Inisiatif seperti hutan adat, sistem subak di Bali, dan pengelolaan komunal lahan di berbagai daerah menunjukkan viabilitas sistem pengelolaan non-kapitalis.\n\nNamun, resistensi petani juga menghadapi **kontradiksi internal** yang mencerminkan kompleksitas proses akumulasi kapital. Sebagian petani yang terlibat dalam resistensi terhadap land grabbing secara bersamaan juga terjebak dalam logika pasar melalui ketergantungan pada input pertanian industrial, kredit bank, dan orientasi produksi untuk pasar. Kontradiksi ini menciptakan **ambivalensi** dalam perjuangan petani yang tidak selalu konsisten menentang logika kapitalisme.\n\n**Kooptasi** gerakan petani oleh negara dan partai politik juga menjadi tantangan serius. Program-program seperti redistribusi aset (land reform) yang dilakukan pemerintah sering kali berfungsi sebagai safety valve untuk meredakan tekanan sosial tanpa mengubah struktur fundamental sistem agraria. Pembagian sertifikat tanah dalam jumlah terbatas kepada sebagian petani dapat menciptakan ilusi reformasi sambil mempertahankan dominasi korporasi atas sumber daya agraria strategis.\n\n**Fragmentasi** gerakan petani berdasarkan identitas etnis, agama, dan regional juga melemahkan potensi resistensi kolektif. Strategi divide et impera yang digunakan negara dan korporasi berhasil menciptakan kompetisi antar kelompok petani untuk mendapatkan akses terbatas terhadap tanah dan sumber daya. Fragmentasi ini mencerminkan apa yang Marx sebut sebagai kompetisi antar pekerja yang menguntungkan kapital.\n\nMeski demikian, resistensi petani telah menciptakan **krisis legitimasi** bagi proyek-proyek accumulation by dispossession. Kasus seperti penolakan petani terhadap reklamasi Teluk Jakarta, resistensi masyarakat Kendeng terhadap pabrik semen, dan perjuangan masyarakat adat Dayak melawan ekspansi perkebunan sawit telah memaksa negara mengeluarkan biaya politik dan ekonomi yang tinggi untuk mempertahankan proses akumulasi.\n\n**Solidaritas internasional** juga memperkuat resistensi lokal melalui jaringan seperti La Via Campesina yang menghubungkan gerakan petani Indonesia dengan gerakan global. Solidaritas ini tidak hanya memberikan dukungan moral dan politik, tetapi juga memfasilitasi pertukaran strategi dan taktik perjuangan. Kerangka analisis tentang land grabbing sebagai fenomena global membantu gerakan lokal memahami posisi mereka dalam konteks yang lebih luas.\n\nResistensi petani juga menghasilkan **inovasi organisasional** yang menantang bentuk-bentuk organisasi konvensional. Gerakan seperti Serikat Pekerja Tani Karawang (SEPETAK) mengembangkan model organisasi yang mengombinasikan perjuangan ekonomi dan politik, sekaligus membangun alternatif ekonomi melalui koperasi dan sistem pertanian berkelanjutan. Model ini menunjukkan kemungkinan membangun counter-hegemoni yang tidak hanya menentang kapitalisme tetapi juga membangun alternatifnya.\n\n> **Poin Penting:** Resistensi petani terhadap accumulation by dispossession menciptakan kontradiksi dalam sistem akumulasi kapital yang memaksa negara mengeluarkan biaya tinggi untuk mempertahankan kondisi akumulasi, sekaligus membuka ruang untuk artikulasi alternatif pembangunan yang lebih demokratis dan berkelanjutan.\n\n## Kesimpulan\n\nAnalisis konflik agraria di Indonesia melalui kerangka teori accumulation by dispossession David Harvey menunjukkan bahwa perampasan tanah dan sumber daya alam bukan sekadar efek samping dari pembangunan, melainkan strategi sistematis untuk mengatasi krisis akumulasi kapital. Proses ini melibatkan transformasi fundamental dalam relasi sosial agraria, di mana tanah yang sebelumnya memiliki fungsi sosial, budaya, dan ekologis direduksi menjadi komoditas yang dapat diperjualbelikan di pasar.\n\nManifestasi accumulation by dispossession di Indonesia terjadi melalui multiple channels yang saling memperkuat: ekspansi perkebunan monokultur, proyek infrastruktur strategis, finansialisasi tanah, dan pembentukan kawasan ekonomi khusus. Semua proses ini difasilitasi oleh transformasi kerangka hukum yang mengutamakan kepentingan investasi atas hak-hak komunitas lokal, sekaligus menggunakan aparatus keamanan negara untuk menekan resistensi.\n\nMekanisme perampasan beroperasi tidak hanya melalui koersi langsung, tetapi juga melalui hegemoni diskursif yang melegitimasi perampasan sebagai "kepentingan pembangunan nasional". Sistem kompensasi yang tidak memadai, fragmentasi resistensi, dan kooptasi elemen-elemen oposisi menjadi instrumen penting dalam melancarkan proses akumulasi. Hal ini menunjukkan bahwa accumulation by dispossession bukan hanya proses ekonomi, tetapi juga proses politik yang melibatkan rekonfigurasi relasi kuasa.\n\nResistensi petani dan masyarakat adat terhadap perampasan menunjukkan bahwa proses accumulation by dispossession tidak berlangsung tanpa kontradiksi. Gerakan okupasi lahan, revitalisasi sistem pengelolaan komunal, dan artikulasi konsep kedaulatan pangan merupakan bentuk-bentuk counter-hegemoni yang menantang logika kapitalisme. Meski menghadapi fragmentasi internal dan kooptasi, resistensi ini telah menciptakan krisis legitimasi yang memaksa negara mengeluarkan biaya politik dan ekonomi tinggi untuk mempertahankan kondisi akumulasi.\n\nDari perspektif teoretis, kasus Indonesia memperkuat argumen Harvey bahwa accumulation by dispossession merupakan feature permanen kapitalisme kontemporer, bukan hanya fenomena historis yang terjadi pada fase awal akumulasi primitif. Proses ini menunjukkan bahwa kapitalisme tidak hanya bergantung pada eksploitasi surplus value melalui hubungan kerja upahan, tetapi juga pada apropriasi langsung atas commons dan transformasi nilai guna menjadi nilai tukar.\n\n**Implikasi praktis** dari analisis ini menunjukkan pentingnya gerakan petani mengembangkan strategi perjuangan yang tidak hanya defensif tetapi juga ofensif dalam membangun alternatif sistem agraria. Perjuangan land reform tidak dapat dipisahkan dari kritik terhadap sistem kapitalisme secara keseluruhan, karena selama logika akumulasi kapital masih dominan, tekanan terhadap sumber daya agraria akan terus berlanjut.\n\n**Rekomendasi untuk gerakan petani** meliputi: pertama, penguatan solidaritas lintas sektoral dengan gerakan buruh, lingkungan, dan hak asasi manusia untuk membangun blok counter-hegemonik yang lebih luas. Kedua, pengembangan alternatif ekonomi melalui koperasi, sistem pertanian berkelanjutan, dan ekonomi komunal yang dapat menunjukkan viabilitas model pembangunan non-kapitalis. Ketiga, penguatan kapasitas analisis untuk memahami dinamika kapitalisme global dan mengembangkan strategi yang sesuai dengan konteks lokal.\n\nPada akhirnya, konflik agraria di Indonesia menunjukkan bahwa pertanyaan tentang tanah adalah pertanyaan tentang model pembangunan dan sistem ekonomi politik secara keseluruhan. Penyelesaian konflik agraria memerlukan transformasi struktural yang melampaui redistribusi lahan, yaitu demokratisasi kontrol atas sumber daya produktif dan pengembangan sistem ekonomi yang mengutamakan kebutuhan manusia atas akumulasi kapital.\n\n## Daftar Pustaka\n\nGramsci, A. (1971). *Selections from the Prison Notebooks*. International Publishers.\n\nHarvey, D. (2001). *Spaces of Capital: Towards a Critical Geography*. Edinburgh University Press.\n\nHarvey, D. (2003). *The New Imperialism*. Oxford University Press.\n\nHarvey, D. (2005). *A Brief History of Neoliberalism*. Oxford University Press.\n\nKonsorsium Pembaruan Agraria. (2023). *Catatan Akhir Tahun 2023: Reforma Agraria Terhambat, Konflik Agraria Meningkat*. KPA.\n\nLuxemburg, R. (1913). *The Accumulation of Capital*. Monthly Review Press.\n\nMarx, K. (1867). *Das Kapital: A Critique of Political Economy Volume 1*. Vintage Books.\n\nPoulantzas, N. (1978). *State, Power, Socialism*. New Left Books.\n\nRachman, N. F. (2012). *Land Reform dari Masa ke Masa*. Tanah Air Beta.\n\nWallerstein, I. (2004). *World-Systems Analysis: An Introduction*. Duke University Press.	10408	117097	\N	manual_regenerate	2026-04-18 00:18:17	2026-04-18 00:20:15
7	6	\N	48	completed	openrouter	anthropic/claude-4-sonnet-20250522	═══ INSTRUKSI PENULISAN ═══\n\nTulis sebuah **kajian ilmiah / tinjauan literatur** dengan topik:\n\n> **Pertanyaan Agraria Abad ke-21: Dari Kautsky hingga Bernstein**\n\n**Konteks dan sudut pandang:**\nMenelusuri evolusi The Agrarian Question dari Kautsky (1899) hingga Bernstein (2010), dan apa maknanya bagi petani Indonesia saat ini.\n\n**Kerangka pikir utama:** Ekonomi Politik Agraria (Bernstein, Van der Ploeg, Wolf, Scott)\n\n**Referensi WAJIB** (harus disitasi di artikel, boleh tambah referensi lain yang relevan dan nyata):\n- Kautsky, K. (1899). *Die Agrarfrage (The Agrarian Question)*.\n- Bernstein, H. (2010). *Class Dynamics of Agrarian Change*.\n- White, B. & Wiradi, G. (2012). *Agrarian and Other Transformations of the Indonesian Countryside*.\n\n═══ MULAI MENULIS ═══\n\nTulis artikelnya sekarang. Mulai langsung dari judul (# Judul), lalu metadata, daftar isi, dan seterusnya sesuai struktur yang ditentukan.	# Pertanyaan Agraria Abad ke-21: Dari Kautsky hingga Bernstein dan Relevansinya bagi Transformasi Pedesaan Indonesia\n\n**Kata Kunci:** pertanyaan agraria, Kautsky, Bernstein, transformasi pedesaan, ekonomi politik agraria\n\n**Waktu Baca:** ± 12 menit\n\n## Daftar Isi\n\n1. Abstrak\n2. Pendahuluan\n3. Warisan Kautsky: Fondasi Pertanyaan Agraria Klasik\n4. Evolusi Pemikiran Agraria: Dari Diferensiasi hingga Depeasantisasi\n5. Bernstein dan Reformulasi Pertanyaan Agraria Kontemporer\n6. Transformasi Agraria Indonesia dalam Perspektif Global\n7. Kesimpulan\n8. Daftar Pustaka\n\n## Abstrak\n\nPertanyaan agraria (*The Agrarian Question*) yang pertama kali dirumuskan Karl Kautsky pada 1899 tetap relevan dalam memahami dinamika pedesaan abad ke-21. Artikel ini mengkaji evolusi konseptual pertanyaan agraria dari formulasi klasik Kautsky hingga reformulasi kontemporer Henry Bernstein, serta menganalisis relevansinya bagi transformasi pedesaan Indonesia. Melalui analisis literatur ekonomi politik agraria, artikel ini menunjukkan bahwa pertanyaan agraria telah bertransformasi dari fokus pada diferensiasi petani menjadi analisis kompleks tentang **depeasantisasi**, **repeasantisasi**, dan integrasi petani dalam rantai nilai global. Temuan utama menunjukkan bahwa kondisi agraria Indonesia mencerminkan kontradiksi global antara logika akumulasi kapital dan persistensi ekonomi petani. Artikel ini berargumen bahwa memahami evolusi pertanyaan agraria menjadi kunci dalam merumuskan strategi perjuangan agraria yang relevan dengan kondisi kontemporer, khususnya dalam menghadapi penetrasi kapital finansial dan ekspansi agribisnis di pedesaan Indonesia.\n\n## Pendahuluan\n\n**Pertanyaan agraria** (*The Agrarian Question*) merupakan salah satu konsep fundamental dalam ekonomi politik yang telah membentuk pemahaman kita tentang dinamika pedesaan selama lebih dari satu abad. Pertama kali dirumuskan oleh Karl Kautsky dalam karyanya *Die Agrarfrage* (1899), pertanyaan agraria pada dasarnya mempertanyakan nasib petani dalam perkembangan kapitalisme dan bagaimana sektor pertanian terintegrasi dalam sistem ekonomi kapitalis yang lebih luas.\n\nRelevansi pertanyaan agraria tidak surut seiring berjalannya waktu. Bahkan, dalam konteks globalisasi dan financialization yang mengkarakterisasi abad ke-21, pertanyaan ini menjadi semakin mendesak. Henry Bernstein (2010) dalam *Class Dynamics of Agrarian Change* menegaskan bahwa pertanyaan agraria kontemporer tidak lagi sekadar tentang diferensiasi petani, melainkan tentang proses **depeasantisasi** yang kompleks dan kontradiktif dalam era kapitalisme global.\n\nIndonesia, sebagai negara agraris dengan 70% penduduk bergantung pada sektor pertanian, menjadi laboratorium empiris yang menarik untuk memahami evolusi pertanyaan agraria. Transformasi pedesaan Indonesia sejak era Orde Baru hingga reformasi menunjukkan dinamika yang kompleks antara persistensi ekonomi petani dan penetrasi kapital agribisnis (White & Wiradi, 2012).\n\nArtikel ini berargumen bahwa evolusi konseptual pertanyaan agraria dari Kautsky hingga Bernstein memberikan kerangka analitis yang kritis untuk memahami transformasi agraria Indonesia kontemporer. Tesis utama yang akan dibangun adalah bahwa **pertanyaan agraria abad ke-21 tidak lagi tentang apakah petani akan menghilang, melainkan tentang bagaimana petani bertransformasi dan beradaptasi dalam kondisi kapitalisme global yang semakin penetratif**.\n\nStruktur artikel ini akan menelusuri genealogi intelektual pertanyaan agraria, dimulai dari formulasi klasik Kautsky, evolusi pemikiran agraria melalui berbagai kontribusi teoretis, reformulasi kontemporer Bernstein, dan aplikasinya dalam konteks transformasi pedesaan Indonesia. Melalui analisis komparatif dan dialektis, artikel ini berupaya memberikan kontribusi pada pemahaman teoretis sekaligus praktis tentang dinamika agraria kontemporer.\n\n## Warisan Kautsky: Fondasi Pertanyaan Agraria Klasik\n\nKarl Kautsky dalam *Die Agrarfrage* (1899) merumuskan pertanyaan agraria sebagai investigasi tentang **bagaimana kapitalisme mentransformasi pertanian dan nasib kelas petani dalam proses tersebut**. Kautsky mengidentifikasi dua kecenderungan utama dalam perkembangan kapitalis di sektor pertanian: **konsentrasi** dan **diferensiasi**. Konsentrasi merujuk pada proses akumulasi tanah dan modal dalam unit-unit produksi yang lebih besar, sementara diferensiasi menunjukkan polarisasi kelas petani menjadi kapitalis agraris dan buruh tani.\n\nKontribusi teoretis Kautsky yang paling fundamental adalah identifikasi **kontradiksi spesifik kapitalisme agraris**. Berbeda dengan industri, pertanian menghadapi kendala biologis dan ekologis yang membatasi intensifikasi kapital. Kautsky menunjukkan bahwa tanah sebagai *means of production* memiliki karakteristik unik: tidak dapat diperbanyak, memiliki fertilitas yang bervariasi, dan terikat pada siklus biologis yang tidak dapat sepenuhnya disubordinasi pada logika kapital.\n\nAnalisis Kautsky tentang **persistensi petani kecil** menjadi paradoks yang terus relevan. Meskipun logika kapitalisme mendorong konsentrasi, petani kecil memiliki kemampuan bertahan karena kesediaannya bekerja dengan tingkat eksploitasi diri (*self-exploitation*) yang tinggi. Fenomena ini kemudian dikenal sebagai **Chayanov effect**, meskipun Kautsky telah mengidentifikasinya lebih awal.\n\nDalam konteks Indonesia, observasi Kautsky tentang persistensi petani kecil terbukti akurat. Data BPS menunjukkan bahwa 70% rumah tangga pertanian Indonesia masih menguasai lahan kurang dari 0,5 hektar, namun tetap bertahan dalam sistem produksi yang terintegrasi dengan pasar global (White & Wiradi, 2012). Hal ini mengkonfirmasi prediksi Kautsky bahwa **diferensiasi petani tidak selalu berujung pada hilangnya petani kecil, melainkan pada transformasi relasi produksi**.\n\nKautsky juga mengantisipasi peran **teknologi** dalam transformasi agraria. Ia berpendapat bahwa adopsi teknologi modern akan mempercepat diferensiasi dengan memberikan keunggulan kompetitif pada petani yang memiliki akses modal. Dalam konteks Indonesia kontemporer, hal ini termanifestasi dalam **digital divide** antara petani yang memiliki akses teknologi informasi dan yang tidak, serta polarisasi akses terhadap input produksi modern.\n\n### Kritik terhadap Formulasi Klasik\n\nMeskipun memberikan fondasi teoretis yang kokoh, formulasi Kautsky memiliki keterbatasan. Pertama, **determinisme ekonomi** yang terlalu kuat dalam memprediksi hilangnya petani kecil. Kenyataan menunjukkan bahwa petani kecil memiliki resiliensi yang lebih besar dari yang diprediksi. Kedua, **underestimasi terhadap agency petani** dalam merespons tekanan kapitalisme. Ketiga, **fokus yang terlalu sempit pada diferensiasi internal** tanpa mempertimbangkan faktor eksternal seperti kebijakan negara dan dinamika pasar global.\n\n> **Poin Penting:** Warisan Kautsky memberikan kerangka analitis fundamental tentang kontradiksi kapitalisme agraris, namun memerlukan reformulasi untuk menangkap kompleksitas transformasi agraria abad ke-21 yang melibatkan dimensi global, teknologi digital, dan financialization.\n\n## Evolusi Pemikiran Agraria: Dari Diferensiasi hingga Depeasantisasi\n\nSetelah Kautsky, pemikiran agraria mengalami evolusi signifikan melalui kontribusi berbagai pemikir. **Alexander Chayanov** (1925) memberikan perspektif alternatif dengan teori ekonomi petani (*peasant economy theory*) yang menekankan logika produksi rumah tangga petani yang berbeda dari logika kapitalis. Chayanov berargumen bahwa petani kecil memiliki **rasionalitas ekonomi spesifik** yang tidak semata-mata berorientasi pada maksimalisasi profit, melainkan pada keseimbangan antara kerja dan konsumsi rumah tangga.\n\n**Eric Wolf** dalam *Peasant Wars of the Twentieth Century* (1969) memperluas analisis dengan memasukkan dimensi politik dan perlawanan petani. Wolf menunjukkan bahwa petani bukan sekadar objek pasif transformasi kapitalisme, melainkan **subjek politik aktif** yang mampu melakukan perlawanan terorganisir. Konsep **moral economy** yang dikembangkan James Scott (1976) melengkapi perspektif ini dengan menekankan bahwa petani memiliki sistem nilai dan norma ekonomi yang berakar pada prinsip subsistensi dan reciprocity.\n\nDalam konteks Indonesia, perspektif moral economy termanifestasi dalam praktik **gotong royong**, **bawon**, dan sistem **gadai tanah** yang masih bertahan di berbagai daerah. Penelitian White dan Wiradi (2012) menunjukkan bahwa institusi-institusi tradisional ini berfungsi sebagai **mekanisme adaptasi** petani dalam menghadapi penetrasi pasar dan tekanan ekonomi.\n\n### Kontribusi Marxisme Agraris\n\nPerkembangan pemikiran Marxis agraris memberikan kontribusi penting melalui karya **Terence Byres** dan **Tom Brass**. Byres (1991) mengembangkan konsep **transisi agraris** yang menekankan peran sektor pertanian dalam akumulasi primitif kapital. Sementara Brass (2011) memperkenalkan konsep **unfree labor** untuk menunjukkan bahwa kapitalisme agraris tidak selalu berujung pada proletarisasi penuh, melainkan seringkali menciptakan bentuk-bentuk kerja semi-bebas.\n\nDalam konteks Indonesia, fenomena **buruh tani musiman**, **sistem bagi hasil**, dan **kontrak farming** mencerminkan karakteristik unfree labor yang diidentifikasi Brass. Petani tidak sepenuhnya terproletarisasi, namun juga tidak memiliki kontrol penuh atas proses produksi dan distribusi.\n\n### Pendekatan Rantai Nilai Global\n\nMunculnya **Global Value Chain (GVC) analysis** dalam studi agraria memberikan perspektif baru tentang integrasi petani dalam ekonomi global. **Jan Douwe van der Ploeg** (2008) dalam *The New Peasantries* berargumen bahwa globalisasi menciptakan kondisi paradoksal: di satu sisi mendorong depeasantisasi melalui penetrasi agribisnis, di sisi lain membuka peluang **repeasantisasi** melalui diversifikasi ekonomi dan koneksi langsung dengan pasar.\n\nKonsep **repeasantisasi** menjadi relevan dalam konteks Indonesia dengan munculnya **pertanian organik**, **agrowisata**, dan **direct marketing** yang memungkinkan petani memperoleh value added yang lebih besar. Namun, akses terhadap peluang repeasantisasi ini tidak merata dan seringkali terbatas pada petani dengan modal sosial dan ekonomi yang memadai.\n\n### Feminisasi Pertanian\n\nDimensi gender dalam transformasi agraria mendapat perhatian khusus melalui konsep **feminisasi pertanian**. Penelitian menunjukkan bahwa migrasi laki-laki ke sektor non-pertanian meningkatkan peran perempuan dalam aktivitas pertanian. Namun, feminisasi ini seringkali tidak diikuti dengan akses yang setara terhadap sumber daya produktif dan pengambilan keputusan (Sachs, 2018).\n\nDi Indonesia, feminisasi pertanian termanifestasi dalam peningkatan partisipasi perempuan dalam **kelompok tani**, **koperasi**, dan **usaha mikro berbasis pertanian**. Namun, kontrol terhadap tanah dan akses kredit masih didominasi laki-laki, menciptakan **paradoks feminisasi** yang perlu mendapat perhatian dalam analisis agraria kontemporer.\n\n> **Poin Penting:** Evolusi pemikiran agraria menunjukkan bahwa transformasi pedesaan tidak mengikuti pola linear diferensiasi, melainkan melibatkan proses kompleks yang mencakup resistensi petani, adaptasi institusional, dan reintegrasi dalam ekonomi global dengan berbagai modalitas.\n\n## Bernstein dan Reformulasi Pertanyaan Agraria Kontemporer\n\nHenry Bernstein dalam *Class Dynamics of Agrarian Change* (2010) merumuskan kembali pertanyaan agraria untuk abad ke-21 dengan mengintegrasikan perkembangan teoretis dan empiris selama satu abad terakhir. **Reformulasi Bernstein** berpusat pada empat pertanyaan fundamental: (1) Siapa yang memiliki tanah? (2) Siapa yang bekerja di tanah? (3) Siapa yang memperoleh apa yang diproduksi dari tanah? (4) Apa yang mereka lakukan dengan surplus yang diperoleh?\n\nKontribusi teoretis utama Bernstein adalah konsep **"farming for capital"** versus **"capital in farming"**. Farming for capital merujuk pada situasi di mana petani memproduksi komoditas untuk pasar kapitalis namun tidak sepenuhnya terintegrasi dalam relasi produksi kapitalis. Sementara capital in farming menunjukkan penetrasi langsung kapital dalam proses produksi pertanian melalui agribisnis dan korporasi multinasional.\n\n### Depeasantisasi dan Proletarisasi Parsial\n\nBernstein mengembangkan konsep **depeasantisasi** sebagai proses kompleks yang tidak selalu berujung pada proletarisasi penuh. Depeasantisasi meliputi: (1) kehilangan akses terhadap tanah, (2) ketergantungan pada pasar untuk reproduksi sosial, (3) diversifikasi sumber pendapatan di luar pertanian, dan (4) transformasi identitas sosial dari petani menjadi pekerja.\n\nDalam konteks Indonesia, proses depeasantisasi termanifestasi dalam fenomena **petani-buruh** yang bekerja paruh waktu di pertanian dan paruh waktu di sektor lain. Data menunjukkan bahwa 60% rumah tangga petani Indonesia memperoleh pendapatan dari sumber non-pertanian (White & Wiradi, 2012). Hal ini mencerminkan **proletarisasi parsial** yang diidentifikasi Bernstein.\n\n### Financialization dan Pertanian\n\nBernstein memberikan perhatian khusus pada **financialization** sebagai karakteristik baru kapitalisme agraris abad ke-21. Financialization merujuk pada penetrasi logika finansial dalam sektor pertanian melalui **commodity derivatives**, **land grabbing**, dan **carbon trading**. Proses ini menciptakan **abstraksi baru** dalam ekonomi agraris di mana nilai tanah dan produk pertanian semakin ditentukan oleh spekulasi finansial ketimbang produktivitas riil.\n\nDi Indonesia, financialization termanifestasi dalam ekspansi **perkebunan kelapa sawit** yang didorong oleh investasi finansial global, **sertifikasi lahan** untuk akses kredit perbankan, dan **asuransi pertanian** yang mengintegrasikan petani dalam sistem keuangan formal. Namun, integrasi ini seringkali menciptakan **ketergantungan baru** dan meningkatkan vulnerabilitas petani terhadap volatilitas pasar finansial.\n\n### Kontradiksi Agraria Kontemporer\n\nBernstein mengidentifikasi **tiga kontradiksi utama** dalam agraria kontemporer. Pertama, **kontradiksi antara produksi pangan dan produksi energi** (biofuel) yang menciptakan kompetisi untuk lahan dan sumber daya. Kedua, **kontradiksi antara intensifikasi dan sustainability** yang mempertanyakan viabilitas jangka panjang pertanian industrial. Ketiga, **kontradiksi antara globalisasi dan food sovereignty** yang menciptakan ketegangan antara efisiensi ekonomi dan kedaulatan pangan.\n\nKontradiksi-kontradiksi ini sangat relevan dalam konteks Indonesia. **Ekspansi perkebunan kelapa sawit** untuk biodiesel menciptakan kompetisi dengan produksi pangan dan mengancam ketahanan pangan lokal. **Intensifikasi pertanian** melalui revolusi hijau menunjukkan tanda-tanda **ecological fatigue** dengan penurunan produktivitas tanah dan pencemaran lingkungan. **Liberalisasi perdagangan** pertanian mengancam **kedaulatan pangan** dengan meningkatkan ketergantungan pada impor pangan strategis.\n\n### Agency dan Resistensi dalam Era Global\n\nMeskipun menekankan dominasi kapital, Bernstein tidak mengabaikan **agency petani** dalam merespons transformasi agraria. Ia mengidentifikasi berbagai bentuk resistensi: **everyday resistance** (Scott, 1985), **exit strategies** (migrasi dan diversifikasi), dan **collective action** melalui organisasi petani dan gerakan sosial.\n\nDalam konteks Indonesia, agency petani termanifestasi dalam **gerakan reforma agraria**, **serikat petani**, dan **inovasi teknologi lokal**. Serikat Petani Indonesia (SPI) sebagai bagian dari La Via Campesina menunjukkan kemampuan petani untuk berorganisasi dalam skala global dan mengadvokasi **food sovereignty** sebagai alternatif terhadap food security yang berorientasi pasar.\n\n> **Poin Penting:** Reformulasi Bernstein menunjukkan bahwa pertanyaan agraria abad ke-21 bukan lagi tentang apakah petani akan menghilang, melainkan tentang modalitas transformasi agraria dalam era financialization dan bagaimana petani mempertahankan agency dalam kondisi dominasi kapital yang semakin penetratif.\n\n## Transformasi Agraria Indonesia dalam Perspektif Global\n\nIndonesia menyediakan kasus empiris yang menarik untuk menguji relevansi evolusi pertanyaan agraria dari Kautsky hingga Bernstein. **Transformasi agraria Indonesia** sejak 1960-an menunjukkan karakteristik yang kompleks dan seringkali kontradiktif dengan prediksi teoretis klasik.\n\n### Era Revolusi Hijau dan Modernisasi Pertanian\n\n**Revolusi Hijau** (1970-1990) di Indonesia mencerminkan upaya negara untuk memodernisasi pertanian melalui **paket teknologi** (bibit unggul, pupuk kimia, pestisida) dan **intensifikasi produksi**. Program ini berhasil mencapai **swasembada beras** pada 1984, namun juga menciptakan **ketergantungan teknologi** dan **degradasi ekologi** yang signifikan.\n\nDari perspektif Kautsky, revolusi hijau dapat dipahami sebagai proses **subsumsi formal** pertanian ke dalam logika kapital melalui input industri. Namun, struktur agraria Indonesia tidak mengalami konsentrasi tanah yang diprediksi Kautsky. Sebaliknya, **fragmentasi lahan** semakin intensif dengan rata-rata kepemilikan turun dari 0,7 hektar (1973) menjadi 0,4 hektar (2013).\n\n### Liberalisasi dan Integrasi Pasar Global\n\n**Liberalisasi ekonomi** pasca-1980an mengintegrasikan pertanian Indonesia dalam **rantai nilai global**. Ekspor komoditas perkebunan (kelapa sawit, karet, kakao) meningkat signifikan, namun impor pangan strategis (beras, jagung, kedelai) juga mengalami peningkatan. Hal ini mencerminkan **spesialisasi komoditas** yang diprediksi dalam teori perdagangan internasional, namun juga menciptakan **vulnerabilitas pangan** yang mengancam kedaulatan nasional.\n\nDalam kerangka Bernstein, integrasi ini menunjukkan transisi dari **farming for capital** menuju **capital in farming**. **Agribisnis multinasional** seperti Cargill, Wilmar, dan Sinar Mas mengontrol segmen hulu dan hilir rantai nilai, sementara petani terjebak dalam posisi **price taker** dengan margin keuntungan yang semakin tipis.\n\n### Financialization dan Land Grabbing\n\n**Financialization** pertanian Indonesia termanifestasi dalam **ekspansi perkebunan kelapa sawit** yang didorong oleh investasi finansial global. Luas perkebunan kelapa sawit meningkat dari 1,1 juta hektar (1990) menjadi 14,3 juta hektar (2018), menjadikan Indonesia produsen terbesar dunia. Namun, ekspansi ini seringkali melibatkan **land grabbing** yang merugikan masyarakat adat dan petani kecil.\n\n**Konflik agraria** meningkat signifikan dengan 212 kasus pada 2018 (KPA, 2019), sebagian besar terkait ekspansi perkebunan dan pembangunan infrastruktur. Hal ini mencerminkan **kontradiksi fundamental** antara akumulasi kapital dan hak-hak agraria masyarakat yang diidentifikasi dalam literatur agraria kritis.\n\n### Depeasantisasi dan Diversifikasi Ekonomi\n\n**Depeasantisasi** di Indonesia tidak mengikuti pola linear proletarisasi. Sebaliknya, terjadi **diversifikasi ekonomi** yang kompleks di mana rumah tangga petani mengombinasikan aktivitas pertanian dengan pekerjaan non-pertanian. **Migrasi sirkuler** menjadi strategi adaptasi utama dengan anggota keluarga bekerja di sektor industri dan jasa sambil mempertahankan koneksi dengan pertanian.\n\nData menunjukkan bahwa **50% tenaga kerja pertanian** bekerja paruh waktu, mengkombinasikan pertanian dengan aktivitas lain (White & Wiradi, 2012). Fenomena **petani-buruh** ini mencerminkan **proletarisasi parsial** yang diidentifikasi Bernstein, di mana petani tidak sepenuhnya terpisah dari means of production namun juga tidak memiliki kontrol penuh atas proses produksi.\n\n### Gerakan Petani dan Food Sovereignty\n\n**Gerakan petani Indonesia** menunjukkan agency kolektif dalam merespons transformasi agraria. **Serikat Petani Indonesia (SPI)** sebagai organisasi petani terbesar mengadvokasi **reforma agraria** dan **kedaulatan pangan** sebagai alternatif terhadap liberalisasi pertanian. **Aliansi Gerakan Reforma Agraria (AGRA)** memperjuangkan redistribusi tanah dan demokratisasi akses sumber daya agraria.\n\nKonsep **food sovereignty** yang diperjuangkan gerakan petani Indonesia sejalan dengan kritik Bernstein terhadap **food security** yang berorientasi pasar. Food sovereignty menekankan hak petani dan masyarakat untuk menentukan sistem pangan mereka sendiri, termasuk **hak atas benih**, **teknologi ramah lingkungan**, dan **pasar lokal**.\n\n### Teknologi Digital dan Pertanian Presisi\n\n**Digitalisasi pertanian** melalui aplikasi mobile, sensor IoT, dan **precision agriculture** membuka peluang sekaligus tantangan baru. Di satu sisi, teknologi digital dapat meningkatkan efisiensi produksi dan akses pasar petani kecil. Di sisi lain, **digital divide** dapat memperdalam kesenjangan antara petani yang memiliki akses teknologi dan yang tidak.\n\n**Platform digital** seperti TaniHub, iGrow, dan Crowde mengintegrasikan petani dalam **ekonomi digital**, namun juga menciptakan **ketergantungan baru** pada infrastruktur teknologi dan algoritma yang dikontrol korporasi. Hal ini mencerminkan **subsumsi riil** pertanian ke dalam logika kapital digital yang belum sepenuhnya diantisipasi dalam literatur agraria klasik.\n\n> **Poin Penting:** Transformasi agraria Indonesia menunjukkan kompleksitas empiris yang memvalidasi evolusi teoretis pertanyaan agraria, dari diferensiasi klasik hingga depeasantisasi kontemporer, sambil menghadirkan fenomena baru seperti financialization dan digitalisasi yang memerlukan pengembangan teoretis lebih lanjut.\n\n## Kesimpulan\n\nPenelusuran evolusi pertanyaan agraria dari Kautsky hingga Bernstein mengungkapkan transformasi fundamental dalam memahami dinamika pedesaan dan nasib petani dalam kapitalisme global. **Reformulasi pertanyaan agraria abad ke-21** tidak lagi berpusat pada prediksi deterministik tentang hilangnya petani, melainkan pada analisis kompleks tentang modalitas transformasi agraria dalam era financialization, digitalisasi, dan integrasi rantai nilai global.\n\n**Kontribusi teoretis utama** dari evolusi ini adalah pengakuan bahwa **depeasantisasi** merupakan proses yang kontradiktif dan tidak linear. Petani tidak sekadar menjadi korban pasif penetrasi kapital, melainkan **subjek aktif** yang mengembangkan strategi adaptasi, resistensi, dan transformasi. Konsep **proletarisasi parsial**, **diversifikasi ekonomi**, dan **repeasantisasi** memberikan nuansa pada pemahaman kita tentang persistensi dan transformasi ekonomi petani.\n\n**Kasus Indonesia** memvalidasi kompleksitas teoretis ini dengan menunjukkan bahwa transformasi agraria melibatkan **multiple pathways** yang tidak dapat diprediksi melalui model tunggal. **Fragmentasi lahan** yang berkelanjutan, **diversifikasi ekonomi** rumah tangga petani, **ekspansi agribisnis** yang bersamaan dengan **persistensi petani kecil**, dan **gerakan food sovereignty** yang merespons liberalisasi menunjukkan dinamika yang kaya dan kontradiktif.\n\n**Implikasi praktis** bagi gerakan petani dan serikat pekerja tani adalah perlunya **strategi yang multi-dimensional** dalam menghadapi transformasi agraria kontemporer. Perjuangan tidak dapat lagi terbatas pada **redistribusi tanah** klasik, melainkan harus mencakup **kontrol atas teknologi**, **akses pasar yang adil**, **kedaulatan benih**, dan **demokratisasi sistem pangan**. **Aliansi strategis** antara petani, buruh tani, masyarakat adat, dan gerakan lingkungan menjadi kunci dalam menghadapi dominasi kapital agraris yang semakin kompleks.\n\n**Rekomendasi untuk SEPETAK** dan gerakan petani Indonesia meliputi: (1) **Pengembangan kapasitas analitis** untuk memahami dinamika rantai nilai global dan posisi petani di dalamnya; (2) **Penguatan organisasi** di tingkat lokal sambil membangun **jaringan transnasional** dengan gerakan petani global; (3) **Advokasi kebijakan** yang mendukung **food sovereignty** dan **reforma agraria** yang komprehensif; (4) **Pengembangan alternatif ekonomi** seperti **pasar rakyat**, **koperasi produksi**, dan **teknologi ramah lingkungan**; (5) **Pendidikan politik** yang mengintegrasikan analisis kelas dengan isu gender, lingkungan, dan kedaulatan pangan.\n\nPertanyaan agraria abad ke-21 pada akhirnya adalah pertanyaan tentang **jenis transformasi agraria** yang kita inginkan: transformasi yang didominasi logika akumulasi kapital atau transformasi yang berpusat pada **keadilan agraria**, **sustainability**, dan **kedaulatan rakyat**. Jawaban atas pertanyaan ini tidak hanya menentukan nasib petani, melainkan juga karakter sistem pangan dan model pembangunan yang kita pilih untuk masa depan.\n\n## Daftar Pustaka\n\nBernstein, H. (2010). *Class dynamics of agrarian change*. Fernwood Publishing.\n\nBrass, T. (2011). *Labour regime change in the twenty-first century: Unfreedom, capitalism and primitive accumulation*. Brill.\n\nByres, T. J. (1991). The agrarian question and differing forms of capitalist agrarian transition: An essay with reference to Asia. In J. Breman & S. Mundle (Eds.), *Rural transformation in Asia* (pp. 3-76). Oxford University Press.\n\nChayanov, A. V. (1925). *The theory of peasant economy*. University of Wisconsin Press.\n\nKautsky, K. (1899). *Die Agrarfrage: Eine Übersicht über die Tendenzen der modernen Landwirtschaft und die Agrarpolitik der Sozialdemokratie*. J. H. W. Dietz.\n\nKonsorsium Pembaruan Agraria. (2019). *Catatan akhir tahun 2018 konsorsium pembaruan agraria: Masa depan reforma agraria melampaui tahun politik*. KPA.\n\nSachs, C. E. (2018). *Gendered fields: Rural women, agriculture, and environment*. Westview Press.\n\nScott, J. C. (1976). *The moral economy of the peasant: Rebellion and subsistence in Southeast Asia*. Yale University Press.\n\nScott, J. C. (1985). *Weapons of the weak: Everyday forms of peasant resistance*. Yale University Press.\n\nVan der Ploeg, J. D. (2008). *The new peasantries: Struggles for autonomy and sustainability in an era of empire and globalization*. Earthscan.\n\nWhite, B., & Wiradi, G. (2012). *Agrarian and other transformations of the Indonesian countryside in the twentieth and early twenty-first centuries*. Indonesian Social Development Paper No. 2012-01. Indonesia Social Development Programme.\n\nWolf, E. R. (1969). *Peasant wars of the twentieth century*. Harper & Row.	10308	128767	\N	manual	2026-04-18 00:29:45	2026-04-18 00:31:53
\.


--
-- Data for Name: article_pool_topic; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.article_pool_topic (article_pool_id, article_topic_id) FROM stdin;
1	1
1	2
1	3
1	4
1	5
1	11
1	12
2	9
2	11
3	8
3	9
3	10
\.


--
-- Data for Name: article_pools; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.article_pools (id, name, slug, description, schedule_frequency, schedule_day, schedule_time, articles_per_run, is_active, auto_publish, created_at, updated_at) FROM stdin;
1	Kajian Mingguan Marxian	kajian-mingguan-marxian	Essay dan kajian mingguan berbasis pemikiran Marxian dan Neo-Marxian.	weekly	monday	07:00:00	1	t	f	2026-04-17 23:03:44	2026-04-17 23:03:44
2	Analisis Kebijakan Bulanan	analisis-kebijakan-bulanan	Analisis kebijakan publik bulanan dari perspektif ekonomi politik.	monthly	\N	09:00:00	1	t	f	2026-04-17 23:03:44	2026-04-17 23:03:44
3	Essay Ekologi & HAM Dua Mingguan	essay-ekologi-ham	Essay dan kajian tentang ekologi politik, lingkungan, dan hak asasi manusia.	biweekly	wednesday	08:00:00	1	t	f	2026-04-17 23:03:44	2026-04-17 23:03:44
\.


--
-- Data for Name: article_topic_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.article_topic_tags (article_topic_id, tag_id) FROM stdin;
1	1
1	8
1	12
2	1
2	7
2	11
3	1
3	8
3	11
4	3
4	10
4	11
5	4
5	6
5	17
6	5
6	8
6	11
7	10
7	11
7	16
8	11
8	13
8	18
9	9
9	11
9	18
10	11
10	14
10	18
11	5
11	6
11	9
12	5
12	7
12	11
13	11
13	15
13	16
14	8
14	10
14	11
15	8
15	10
\.


--
-- Data for Name: article_topics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.article_topics (id, title, slug, description, thinking_framework, article_type, key_references, prompt_template, weight, max_uses, times_used, is_active, category_id, created_by, created_at, updated_at, deleted_at) FROM stdin;
2	Alienasi Petani dalam Modernisasi Pertanian Indonesia	alienasi-petani-dalam-modernisasi-pertanian-indonesia	Menelusuri konsep alienasi (Entfremdung) Marx dalam konteks modernisasi pertanian: bagaimana petani terasing dari tanah, proses produksi, dan hasil kerja mereka sendiri.	marxist	essay	[{"author":"Marx, K.","year":1844,"title":"Economic and Philosophic Manuscripts of 1844"},{"author":"Scott, J. C.","year":1985,"title":"Weapons of the Weak: Everyday Forms of Peasant Resistance"},{"author":"Van der Ploeg, J. D.","year":2008,"title":"The New Peasantries"}]		65	\N	0	t	6	\N	2026-04-17 23:03:44	2026-04-17 23:03:44	\N
3	Fetisisme Komoditas: Mengapa Petani Miskin di Tanah Subur	fetisisme-komoditas-mengapa-petani-miskin-di-tanah-subur	Membedah fetisisme komoditas (commodity fetishism) untuk menjelaskan paradoks kemiskinan petani di tengah kelimpahan hasil pertanian.	marxist	essay	[{"author":"Marx, K.","year":1867,"title":"Das Kapital, Volume I"},{"author":"Harvey, D.","year":2010,"title":"A Companion to Marx's Capital"},{"author":"Bernstein, H.","year":2010,"title":"Class Dynamics of Agrarian Change"}]		60	\N	0	t	6	\N	2026-04-17 23:03:44	2026-04-17 23:03:44	\N
8	Environmentalism of the Poor: Gerakan Lingkungan Rakyat Kecil	environmentalism-of-the-poor-gerakan-lingkungan-rakyat-kecil	Mengkaji teori Martinez-Alier tentang environmentalism of the poor dan relevansinya bagi perjuangan petani atas sumber daya alam.	ecopolitics	essay	[{"author":"Martinez-Alier, J.","year":2002,"title":"The Environmentalism of the Poor"},{"author":"Shiva, V.","year":1997,"title":"Biopiracy: The Plunder of Nature and Knowledge"},{"author":"Escobar, A.","year":1995,"title":"Encountering Development"}]		60	\N	0	t	8	\N	2026-04-17 23:03:44	2026-04-17 23:03:44	\N
9	Kedaulatan Pangan vs Ketahanan Pangan: Kritik Struktural	kedaulatan-pangan-vs-ketahanan-pangan-kritik-struktural	Membedah perbedaan paradigmatik antara food sovereignty (La Via Campesina) dan food security (WTO/FAO), serta implikasinya bagi kebijakan pertanian Indonesia.	ecopolitics	policy_analysis	[{"author":"Van der Ploeg, J. D.","year":2008,"title":"The New Peasantries"},{"author":"Shiva, V.","year":1991,"title":"The Violence of the Green Revolution"},{"author":"Bernstein, H.","year":2010,"title":"Class Dynamics of Agrarian Change"}]		65	\N	0	t	11	\N	2026-04-17 23:03:44	2026-04-17 23:03:44	\N
10	Hak Atas Pangan sebagai Hak Asasi: Perspektif Amartya Sen	hak-atas-pangan-sebagai-hak-asasi-perspektif-amartya-sen	Menganalisis kerangka kapabilitas (capability approach) Sen untuk memahami kemiskinan petani sebagai perampasan kebebasan fundamental.	human_rights	essay	[{"author":"Sen, A.","year":1999,"title":"Development as Freedom"},{"author":"Sen, A.","year":1981,"title":"Poverty and Famines: An Essay on Entitlement and Deprivation"},{"author":"Konsorsium Pembaruan Agraria","year":2023,"title":"Catatan Akhir Tahun 2023"}]		55	\N	0	t	9	\N	2026-04-17 23:03:44	2026-04-17 23:03:44	\N
11	UU Cipta Kerja dan Dampaknya terhadap Hak Petani Kecil	uu-cipta-kerja-dan-dampaknya-terhadap-hak-petani-kecil	Dekonstruksi UU Cipta Kerja (Omnibus Law) dari perspektif ekonomi politik agraria, menganalisis bagaimana regulasi ini mempercepat dispossesi petani.	neo_marxian	policy_analysis	[{"author":"Harvey, D.","year":2005,"title":"A Brief History of Neoliberalism"},{"author":"Rachman, N. F.","year":2012,"title":"Land Reform dari Masa ke Masa"},{"author":"Konsorsium Pembaruan Agraria","year":2023,"title":"Catatan Akhir Tahun 2023"}]		70	\N	0	t	11	\N	2026-04-17 23:03:44	2026-04-17 23:03:44	\N
12	Gerakan Petani Indonesia dari Sarekat Islam hingga Era Reformasi	gerakan-petani-indonesia-dari-sarekat-islam-hingga-era-reformasi	Tinjauan historis gerakan tani Indonesia: dari Sarekat Islam, BTI-PKI, hingga KPA dan serikat petani kontemporer.	marxist	historical_review	[{"author":"Wolf, E.","year":1969,"title":"Peasant Wars of the Twentieth Century"},{"author":"Wiradi, G.","year":2000,"title":"Reforma Agraria: Perjalanan yang Belum Berakhir"},{"author":"White, B. & Wiradi, G.","year":2012,"title":"Agrarian and Other Transformations of the Indonesian Countryside"},{"author":"Soekarno","year":1926,"title":"Nasionalisme, Islamisme, dan Marxisme"}]		65	\N	0	t	12	\N	2026-04-17 23:03:44	2026-04-17 23:03:44	\N
6	Pertanyaan Agraria Abad ke-21: Dari Kautsky hingga Bernstein	pertanyaan-agraria-abad-ke-21-dari-kautsky-hingga-bernstein	Menelusuri evolusi The Agrarian Question dari Kautsky (1899) hingga Bernstein (2010), dan apa maknanya bagi petani Indonesia saat ini.	agrarian_political_economy	scientific_review	[{"author":"Kautsky, K.","year":1899,"title":"Die Agrarfrage (The Agrarian Question)"},{"author":"Bernstein, H.","year":2010,"title":"Class Dynamics of Agrarian Change"},{"author":"White, B. & Wiradi, G.","year":2012,"title":"Agrarian and Other Transformations of the Indonesian Countryside"}]		65	\N	1	t	7	\N	2026-04-17 23:03:44	2026-04-18 00:31:53	\N
4	Antonio Gramsci dan Hegemoni Budaya dalam Konteks Petani Indonesia	antonio-gramsci-dan-hegemoni-budaya-dalam-konteks-petani-indonesia	Eksplorasi konsep hegemoni kultural dan intelektual organik Gramsci, serta relevansinya bagi strategi pengorganisasian serikat petani di Indonesia.	neo_marxian	thinker_profile	[{"author":"Gramsci, A.","year":1971,"title":"Selections from the Prison Notebooks"},{"author":"Scott, J. C.","year":1985,"title":"Weapons of the Weak"},{"author":"Spivak, G. C.","year":1988,"title":"Can the Subaltern Speak?"}]		70	\N	1	t	10	\N	2026-04-17 23:03:44	2026-04-17 23:33:02	\N
7	Senjata Kaum Lemah: Perlawanan Sehari-hari Petani ala James C. Scott	senjata-kaum-lemah-perlawanan-sehari-hari-petani-ala-james-c-scott	Mengkaji konsep everyday forms of resistance Scott dan bagaimana petani Karawang melakukan perlawanan harian terhadap struktur ketidakadilan.	agrarian_political_economy	thinker_profile	[{"author":"Scott, J. C.","year":1985,"title":"Weapons of the Weak: Everyday Forms of Peasant Resistance"},{"author":"Scott, J. C.","year":1998,"title":"Seeing Like a State"},{"author":"Wolf, E.","year":1969,"title":"Peasant Wars of the Twentieth Century"}]		60	\N	1	t	10	\N	2026-04-17 23:03:44	2026-04-17 23:44:06	\N
5	Akumulasi melalui Perampasan: David Harvey dan Konflik Agraria di Indonesia	akumulasi-melalui-perampasan-david-harvey-dan-konflik-agraria-di-indonesia	Menganalisis teori accumulation by dispossession Harvey untuk memahami konflik agraria kontemporer di Indonesia, termasuk land grabbing dan proyek infrastruktur.	neo_marxian	essay	[{"author":"Harvey, D.","year":2003,"title":"The New Imperialism"},{"author":"Harvey, D.","year":2005,"title":"A Brief History of Neoliberalism"},{"author":"Rachman, N. F.","year":2012,"title":"Land Reform dari Masa ke Masa"},{"author":"Konsorsium Pembaruan Agraria","year":2023,"title":"Catatan Akhir Tahun 2023"}]		75	\N	2	t	7	\N	2026-04-17 23:03:44	2026-04-18 00:20:15	\N
13	Subaltern dan Suara Petani: Membaca Spivak dalam Konteks Agraria Indonesia	subaltern-dan-suara-petani-membaca-spivak-dalam-konteks-agraria-indonesia	Mengkaji teori subaltern Spivak dan Chatterjee untuk memahami bagaimana suara petani terpinggirkan dalam wacana pembangunan.	postmodern	essay	[{"author":"Spivak, G. C.","year":1988,"title":"Can the Subaltern Speak?"},{"author":"Chatterjee, P.","year":2004,"title":"The Politics of the Governed"},{"author":"Escobar, A.","year":1995,"title":"Encountering Development"}]		55	\N	0	t	10	\N	2026-04-17 23:03:44	2026-04-17 23:03:44	\N
14	Kekerasan Simbolik dan Habitus Petani: Perspektif Pierre Bourdieu	kekerasan-simbolik-dan-habitus-petani-perspektif-pierre-bourdieu	Menganalisis konsep kekerasan simbolik (symbolic violence), habitus, dan kapital Bourdieu untuk memahami bagaimana ketidaksetaraan agraria direproduksi secara kultural.	postmodern	thinker_profile	[{"author":"Bourdieu, P.","year":1977,"title":"Outline of a Theory of Practice"},{"author":"Bourdieu, P.","year":1984,"title":"Distinction: A Social Critique of the Judgement of Taste"},{"author":"Scott, J. C.","year":1985,"title":"Weapons of the Weak"}]		55	\N	0	t	10	\N	2026-04-17 23:03:44	2026-04-17 23:03:44	\N
15	Industri Budaya dan Kesadaran Petani: Membaca Mazhab Frankfurt	industri-budaya-dan-kesadaran-petani-membaca-mazhab-frankfurt	Mengkaji teori industri budaya Adorno-Horkheimer dan one-dimensional man Marcuse untuk memahami bagaimana media massa membentuk kesadaran palsu petani.	critical_theory	essay	[{"author":"Horkheimer, M. & Adorno, T. W.","year":1944,"title":"Dialectic of Enlightenment"},{"author":"Marcuse, H.","year":1964,"title":"One-Dimensional Man"},{"author":"Gramsci, A.","year":1971,"title":"Selections from the Prison Notebooks"}]		50	\N	0	t	10	\N	2026-04-17 23:03:44	2026-04-17 23:03:44	\N
1	Teori Nilai-Lebih dan Eksploitasi Buruh Tani di Jawa Barat	teori-nilai-lebih-dan-eksploitasi-buruh-tani-di-jawa-barat	Analisis relevansi teori surplus value Marx terhadap kondisi buruh tani di Karawang dan Jawa Barat kontemporer, termasuk mekanisme ekstraksi nilai-lebih melalui upah rendah, rent-seeking, dan ketergantungan input korporat.	marxist	essay	[{"author":"Marx, K.","year":1867,"title":"Das Kapital, Volume I"},{"author":"Bernstein, H.","year":2010,"title":"Class Dynamics of Agrarian Change"},{"author":"Konsorsium Pembaruan Agraria","year":2023,"title":"Catatan Akhir Tahun 2023"},{"author":"Wiradi, G.","year":2000,"title":"Reforma Agraria: Perjalanan yang Belum Berakhir"}]		70	\N	1	t	6	\N	2026-04-17 23:03:44	2026-04-17 23:05:17	\N
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, actor_id, action, subject_type, subject_id, meta, created_at) FROM stdin;
\.


--
-- Data for Name: cache; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cache (key, value, expiration) FROM stdin;
sepetak_cache36111c9bb14a34a1a9c23ecc7b626b5b:timer	i:1776452769;	1776452769
sepetak_cache36111c9bb14a34a1a9c23ecc7b626b5b	i:1;	1776452769
sepetak_cacheadmin.stats.overview	a:4:{s:14:"members_active";i:0;s:12:"cases_active";i:0;s:15:"programs_active";i:0;s:15:"posts_published";i:5;}	1776453252
sepetak_cachespatie.permission.cache	a:3:{s:5:"alias";a:4:{s:1:"a";s:2:"id";s:1:"b";s:4:"name";s:1:"c";s:10:"guard_name";s:1:"r";s:5:"roles";}s:11:"permissions";a:7:{i:0;a:4:{s:1:"a";i:1;s:1:"b";s:14:"manage-members";s:1:"c";s:3:"web";s:1:"r";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:1;a:4:{s:1:"a";i:2;s:1:"b";s:12:"manage-cases";s:1:"c";s:3:"web";s:1:"r";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:2;a:4:{s:1:"a";i:3;s:1:"b";s:15:"manage-advocacy";s:1:"c";s:3:"web";s:1:"r";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:3;a:4:{s:1:"a";i:4;s:1:"b";s:13:"manage-events";s:1:"c";s:3:"web";s:1:"r";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:4;a:4:{s:1:"a";i:5;s:1:"b";s:14:"manage-content";s:1:"c";s:3:"web";s:1:"r";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:5;a:4:{s:1:"a";i:6;s:1:"b";s:15:"manage-settings";s:1:"c";s:3:"web";s:1:"r";a:2:{i:0;i:1;i:1;i:2;}}i:6;a:4:{s:1:"a";i:7;s:1:"b";s:12:"manage-users";s:1:"c";s:3:"web";s:1:"r";a:2:{i:0;i:1;i:1;i:2;}}}s:5:"roles";a:3:{i:0;a:3:{s:1:"a";i:1;s:1:"b";s:10:"superadmin";s:1:"c";s:3:"web";}i:1;a:3:{s:1:"a";i:2;s:1:"b";s:5:"admin";s:1:"c";s:3:"web";}i:2;a:3:{s:1:"a";i:3;s:1:"b";s:8:"operator";s:1:"c";s:3:"web";}}}	1776539002
sepetak_cachesite_setting:site_name	s:39:"SEPETAK - Serikat Pekerja Tani Karawang";	1776456206
sepetak_cachesite_setting:site_description	s:243:"SEPETAK (Serikat Pekerja Tani Karawang) adalah organisasi massa berbasis pekerja tani dan nelayan di Kabupaten Karawang, Jawa Barat, yang memperjuangkan TANI MOTEKAR (Tanah, Infrastruktur, Modal, Teknologi, Akses Pasar) sejak 10 Desember 2007.";	1776456206
sepetak_cachesite_setting:site_tagline	s:58:"Rebut Kedaulatan Agraria, Bangun Industrialisasi Pertanian";	1776456206
sepetak_cachesite_setting:contact_email	s:16:"info@sepetak.org";	1776456206
sepetak_cachesite_setting:contact_address	s:123:"Perumahan Johar Indah, Blok J No 20, Kel. Adiarsa Timur, Kecamatan Karawang Tmur, Kabupaten Karawang, Jawa Barat, Indonesia";	1776456206
sepetak_cachesite_setting:social_facebook	s:37:"https://www.facebook.com/sepetak.org/";	1776456206
sepetak_cachesite_setting:social_instagram	s:42:"https://www.instagram.com/sepetak_official";	1776456206
sepetak_cachesite_setting:contact_phone	s:14:"+6281382605030";	1776456206
sepetak_cachehomepage.stats	a:3:{s:12:"member_count";i:0;s:10:"case_count";i:0;s:13:"program_count";i:0;}	1776453124
sepetak_cachesite_setting:social_twitter	N;	1776456528
\.


--
-- Data for Name: cache_locks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cache_locks (key, owner, expiration) FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, name, slug, created_at, updated_at, color, icon, description) FROM stdin;
1	Berita	berita	2026-04-16 15:32:51	2026-04-16 15:32:51	\N	\N	\N
2	Advokasi	advokasi	2026-04-16 15:32:51	2026-04-16 15:32:51	\N	\N	\N
3	Kegiatan	kegiatan	2026-04-16 15:32:51	2026-04-16 15:32:51	\N	\N	\N
4	Pengumuman	pengumuman	2026-04-16 15:32:51	2026-04-16 15:32:51	\N	\N	\N
5	Opini	opini	2026-04-16 15:32:51	2026-04-16 15:32:51	\N	\N	\N
6	Kajian Marxian	kajian-marxian	2026-04-17 23:03:44	2026-04-17 23:03:44	\N	\N	\N
7	Ekonomi Politik Agraria	ekonomi-politik-agraria	2026-04-17 23:03:44	2026-04-17 23:03:44	\N	\N	\N
8	Ekologi & Lingkungan	ekologi-lingkungan	2026-04-17 23:03:44	2026-04-17 23:03:44	\N	\N	\N
9	Hak Asasi Manusia	hak-asasi-manusia	2026-04-17 23:03:44	2026-04-17 23:03:44	\N	\N	\N
10	Pemikiran Kritis	pemikiran-kritis	2026-04-17 23:03:44	2026-04-17 23:03:44	\N	\N	\N
11	Analisis Kebijakan	analisis-kebijakan	2026-04-17 23:03:44	2026-04-17 23:03:44	\N	\N	\N
12	Sejarah Gerakan	sejarah-gerakan	2026-04-17 23:03:44	2026-04-17 23:03:44	\N	\N	\N
13	Opini & Refleksi	opini-refleksi	2026-04-17 23:03:44	2026-04-17 23:03:44	\N	\N	\N
\.


--
-- Data for Name: event_attendance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.event_attendance (id, event_id, member_id, attendance_status, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.events (id, title, description, event_date, location_text, status, organizer_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
1	6452b5f9-d844-4036-bdf4-3456fe3b97b5	database	default	{"uuid":"6452b5f9-d844-4036-bdf4-3456fe3b97b5","displayName":"App\\\\Jobs\\\\GenerateArticleJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":2,"maxExceptions":null,"failOnTimeout":false,"backoff":"60","timeout":300,"retryUntil":null,"data":{"commandName":"App\\\\Jobs\\\\GenerateArticleJob","command":"O:27:\\"App\\\\Jobs\\\\GenerateArticleJob\\":4:{s:5:\\"topic\\";O:45:\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\":5:{s:5:\\"class\\";s:23:\\"App\\\\Models\\\\ArticleTopic\\";s:2:\\"id\\";i:6;s:9:\\"relations\\";a:1:{i:0;s:8:\\"category\\";}s:10:\\"connection\\";s:5:\\"pgsql\\";s:15:\\"collectionClass\\";N;}s:4:\\"pool\\";N;s:11:\\"triggeredBy\\";s:6:\\"manual\\";s:5:\\"queue\\";s:7:\\"default\\";}"}}	UnexpectedValueException: The stream or file "/home/sepetak.org/storage/logs/laravel-2026-04-18.log" could not be opened in append mode: Failed to open stream: Permission denied\nThe exception occurred while attempting to log: ArticleGenerator: Cover image failed (non-fatal)\nContext: {"post_id":48,"error":"The stream or file \\"\\/home\\/sepetak.org\\/storage\\/logs\\/laravel-2026-04-18.log\\" could not be opened in append mode: Failed to open stream: Permission denied\\nThe exception occurred while attempting to log: ArticleImageService: wikimedia failed\\nContext: {\\"post_id\\":48,\\"query\\":\\"Javanese farmer\\",\\"error\\":\\"file_put_contents(\\\\\\/home\\\\\\/sepetak.org\\\\\\/storage\\\\\\/app\\\\\\/temp\\\\\\/cover-pertanyaan-agraria-abad-ke-21-dari-kautsky-hingga-bernstein-dan-relevansinya-bagi-transformasi-pedesaan-indonesia-cKWkwm.jpg): Failed to open stream: Permission denied\\"}"} in /home/sepetak.org/vendor/monolog/monolog/src/Monolog/Handler/StreamHandler.php:164\nStack trace:\n#0 /home/sepetak.org/vendor/monolog/monolog/src/Monolog/Handler/RotatingFileHandler.php(113): Monolog\\Handler\\StreamHandler->write()\n#1 /home/sepetak.org/vendor/monolog/monolog/src/Monolog/Handler/AbstractProcessingHandler.php(44): Monolog\\Handler\\RotatingFileHandler->write()\n#2 /home/sepetak.org/vendor/monolog/monolog/src/Monolog/Logger.php(391): Monolog\\Handler\\AbstractProcessingHandler->handle()\n#3 /home/sepetak.org/vendor/monolog/monolog/src/Monolog/Logger.php(633): Monolog\\Logger->addRecord()\n#4 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Log/Logger.php(184): Monolog\\Logger->warning()\n#5 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Log/Logger.php(109): Illuminate\\Log\\Logger->writeLog()\n#6 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Log/LogManager.php(716): Illuminate\\Log\\Logger->warning()\n#7 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(361): Illuminate\\Log\\LogManager->warning()\n#8 /home/sepetak.org/app/Services/ArticleGeneratorService.php(154): Illuminate\\Support\\Facades\\Facade::__callStatic()\n#9 /home/sepetak.org/app/Jobs/GenerateArticleJob.php(47): App\\Services\\ArticleGeneratorService->generate()\n#10 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): App\\Jobs\\GenerateArticleJob->handle()\n#11 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#12 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(95): Illuminate\\Container\\Util::unwrapIfClosure()\n#13 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#14 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Container/Container.php(696): Illuminate\\Container\\BoundMethod::call()\n#15 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(126): Illuminate\\Container\\Container->call()\n#16 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(170): Illuminate\\Bus\\Dispatcher->{closure:Illuminate\\Bus\\Dispatcher::dispatchNow():123}()\n#17 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(127): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():168}()\n#18 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(130): Illuminate\\Pipeline\\Pipeline->then()\n#19 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(126): Illuminate\\Bus\\Dispatcher->dispatchNow()\n#20 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(170): Illuminate\\Queue\\CallQueuedHandler->{closure:Illuminate\\Queue\\CallQueuedHandler::dispatchThroughMiddleware():121}()\n#21 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(127): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():168}()\n#22 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(121): Illuminate\\Pipeline\\Pipeline->then()\n#23 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(69): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware()\n#24 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Queue/Jobs/Job.php(102): Illuminate\\Queue\\CallQueuedHandler->call()\n#25 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(442): Illuminate\\Queue\\Jobs\\Job->fire()\n#26 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(392): Illuminate\\Queue\\Worker->process()\n#27 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(178): Illuminate\\Queue\\Worker->runJob()\n#28 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(149): Illuminate\\Queue\\Worker->daemon()\n#29 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(132): Illuminate\\Queue\\Console\\WorkCommand->runWorker()\n#30 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#31 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#32 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(95): Illuminate\\Container\\Util::unwrapIfClosure()\n#33 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#34 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Container/Container.php(696): Illuminate\\Container\\BoundMethod::call()\n#35 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Console/Command.php(213): Illuminate\\Container\\Container->call()\n#36 /home/sepetak.org/vendor/symfony/console/Command/Command.php(341): Illuminate\\Console\\Command->execute()\n#37 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Console/Command.php(182): Symfony\\Component\\Console\\Command\\Command->run()\n#38 /home/sepetak.org/vendor/symfony/console/Application.php(1117): Illuminate\\Console\\Command->run()\n#39 /home/sepetak.org/vendor/symfony/console/Application.php(356): Symfony\\Component\\Console\\Application->doRunCommand()\n#40 /home/sepetak.org/vendor/symfony/console/Application.php(195): Symfony\\Component\\Console\\Application->doRun()\n#41 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Foundation/Console/Kernel.php(198): Symfony\\Component\\Console\\Application->run()\n#42 /home/sepetak.org/vendor/laravel/framework/src/Illuminate/Foundation/Application.php(1235): Illuminate\\Foundation\\Console\\Kernel->handle()\n#43 /home/sepetak.org/artisan(13): Illuminate\\Foundation\\Application->handleCommand()\n#44 {main}	2026-04-18 00:31:57
\.


--
-- Data for Name: gallery_albums; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gallery_albums (id, title, slug, description, event_date, location, status, published_at, author_id, sort_order, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: gallery_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gallery_items (id, gallery_album_id, type, title, caption, video_url, video_platform, credit, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: job_batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.job_batches (id, name, total_jobs, pending_jobs, failed_jobs, failed_job_ids, options, cancelled_at, created_at, finished_at) FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.jobs (id, queue, payload, attempts, reserved_at, available_at, created_at) FROM stdin;
\.


--
-- Data for Name: media; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.media (id, model_type, model_id, uuid, collection_name, name, file_name, mime_type, disk, conversions_disk, size, manipulations, custom_properties, generated_conversions, responsive_images, order_column, created_at, updated_at) FROM stdin;
10	App\\Models\\Post	45	e45c9148-c2d5-42bf-8b0a-c1e3a974458f	cover	cover-antonio-gramsci-dan-hegemoni-budaya-relevansi-bagi-strategi-pengorganisasian-petani-indonesia-BGkk95	cover-antonio-gramsci-dan-hegemoni-budaya-relevansi-bagi-strategi-pengorganisasian-petani-indonesia-BGkk95.png	image/png	public	public	732384	[]	{"photographer":"Wikimedia Commons","photographer_url":"https:\\/\\/commons.wikimedia.org\\/wiki\\/File:Gramsci.png","source":"wikimedia"}	[]	[]	1	2026-04-18 00:13:00	2026-04-18 00:13:00
11	App\\Models\\Post	46	81b21272-d5f0-4bfa-9a92-71e7be00f41c	cover	cover-senjata-kaum-lemah-perlawanan-sehari-hari-petani-ala-james-c-scott-UZ7HN9	cover-senjata-kaum-lemah-perlawanan-sehari-hari-petani-ala-james-c-scott-UZ7HN9.jpg	image/jpeg	public	public	58705	[]	{"photographer":"Wikimedia Commons","photographer_url":"https:\\/\\/commons.wikimedia.org\\/wiki\\/File:James_C_Scott_2016.jpg","source":"wikimedia"}	[]	[]	1	2026-04-18 00:13:01	2026-04-18 00:13:01
12	App\\Models\\Post	43	4128c7a5-e992-4a8a-98e8-d89a4a426058	cover	cover-teori-nilai-lebih-dan-eksploitasi-buruh-tani-di-jawa-barat-analisis-marxis-terhadap-kondisi-agraria-kontemporer-o5O2Ki	cover-teori-nilai-lebih-dan-eksploitasi-buruh-tani-di-jawa-barat-analisis-marxis-terhadap-kondisi-agraria-kontemporer-o5O2Ki.jpg	image/jpeg	public	public	517324	[]	{"photographer":"Wikimedia Commons","photographer_url":"https:\\/\\/commons.wikimedia.org\\/wiki\\/File:Karl_Marx_001.jpg","source":"wikimedia"}	[]	[]	1	2026-04-18 00:13:01	2026-04-18 00:13:01
14	App\\Models\\Post	47	c2a7173c-bb58-48b3-8a5d-5a9bd835d4b1	cover	cover-akumulasi-melalui-perampasan-david-harvey-dan-konflik-agraria-di-indonesia-9gCtbZ	cover-akumulasi-melalui-perampasan-david-harvey-dan-konflik-agraria-di-indonesia-9gCtbZ.jpg	image/jpeg	public	public	132831	[]	{"photographer":"Wikimedia Commons","photographer_url":"https:\\/\\/commons.wikimedia.org\\/wiki\\/File:David_Harvey2.jpg","source":"wikimedia"}	[]	[]	1	2026-04-18 00:20:15	2026-04-18 00:20:15
15	App\\Models\\Post	48	423691cc-3ea6-49c4-b610-3b47d53a583c	cover	cover-pertanyaan-agraria-abad-ke-21-dari-kautsky-hingga-bernstein-dan-relevansinya-bagi-transformasi-pedesaan-indonesia-suOVtP	cover-pertanyaan-agraria-abad-ke-21-dari-kautsky-hingga-bernstein-dan-relevansinya-bagi-transformasi-pedesaan-indonesia-suOVtP.jpg	image/jpeg	public	public	161211	[]	{"photographer":"Exynoss78739","photographer_url":"https:\\/\\/commons.wikimedia.org\\/wiki\\/File:Rice_field_in_Tulungagung.jpg","source":"wikimedia"}	[]	[]	1	2026-04-18 00:46:19	2026-04-18 00:46:19
\.


--
-- Data for Name: member_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.member_documents (id, member_id, document_type, title, issued_at, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.members (id, user_id, member_code, full_name, gender, birth_place, birth_date, nik, phone, email, address_id, status, joined_at, approved_at, notes, created_by, updated_by, created_at, updated_at, deleted_at, rejected_at, rejection_reason, approved_by) FROM stdin;
49	\N	ANG-20260418-ZXLX7	Odang Rodiana	male	\N	1987-07-15	\N	081382605030	studiomalaka@gmail.com	3	pending	2026-04-18	\N	\N	\N	\N	2026-04-18 01:47:40	2026-04-18 01:47:40	\N	\N	\N	\N
50	\N	ANG-20260418-KYNIP	Odang Rodiana	male	\N	1987-07-15	\N	081382605030	studiomalaka@gmail.com	4	pending	2026-04-18	\N	\N	\N	\N	2026-04-18 01:57:10	2026-04-18 01:57:10	\N	\N	\N	\N
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.migrations (id, migration, batch) FROM stdin;
1	0001_01_01_000000_create_users_table	1
2	0001_01_01_000001_create_cache_table	1
3	0001_01_01_000002_create_jobs_table	1
4	2025_01_01_000001_create_addresses_table	1
5	2025_01_01_000002_create_members_table	1
6	2025_01_01_000003_create_member_documents_table	1
7	2025_01_01_000004_create_agrarian_cases_table	1
8	2025_01_01_000005_create_agrarian_case_parties_table	1
9	2025_01_01_000006_create_agrarian_case_updates_table	1
10	2025_01_01_000007_create_agrarian_case_files_table	1
11	2025_01_01_000008_create_advocacy_programs_table	1
12	2025_01_01_000009_create_advocacy_actions_table	1
13	2025_01_01_000010_create_events_table	1
14	2025_01_01_000011_create_event_attendance_table	1
15	2025_01_01_000012_create_categories_table	1
16	2025_01_01_000013_create_tags_table	1
17	2025_01_01_000014_create_posts_table	1
18	2025_01_01_000015_create_post_category_table	1
19	2025_01_01_000016_create_post_tag_table	1
20	2025_01_01_000017_create_pages_table	1
21	2025_01_01_000018_create_site_settings_table	1
22	2025_01_01_000019_create_audit_logs_table	1
23	2026_04_16_153336_create_permission_tables	2
24	2026_04_16_154218_create_media_table	3
25	2026_04_16_160500_make_addresses_line_1_nullable	4
26	2026_04_17_100000_create_article_topics_table	5
27	2026_04_17_100001_create_article_pools_table	5
28	2026_04_17_100002_create_article_generation_logs_table	5
29	2026_04_17_100003_add_auto_article_columns_to_posts_table	5
30	2026_04_18_000001_create_gallery_tables	6
31	2026_04_17_183003_add_meta_fields_to_pages_and_categories	7
32	2026_04_17_190000_add_approval_fields_to_members	8
\.


--
-- Data for Name: model_has_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_has_permissions (permission_id, model_type, model_id) FROM stdin;
\.


--
-- Data for Name: model_has_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_has_roles (role_id, model_type, model_id) FROM stdin;
1	App\\Models\\User	1
3	App\\Models\\User	2
4	App\\Models\\User	3
\.


--
-- Data for Name: pages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pages (id, title, slug, body, status, published_at, author_id, created_at, updated_at, deleted_at, meta_description) FROM stdin;
1	Tentang Kami	tentang-kami	<h2>Tentang SEPETAK</h2><p><strong>SEPETAK (Serikat Pekerja Tani Karawang)</strong> adalah organisasi massa berbasis pekerja tani dan nelayan yang bersifat terbuka di Kabupaten Karawang, Jawa Barat. SEPETAK didirikan melalui <strong>Kongres I pada 3–4 November 2007</strong> dan dideklarasikan pada <strong>10 Desember 2007</strong> di Karawang.</p><p>Sejak <strong>Kongres III tahun 2015</strong>, nama resmi organisasi berubah dari <em>Serikat Petani Karawang</em> menjadi <strong>Serikat Pekerja Tani Karawang</strong>. Perubahan nama ini menegaskan posisi anggota sebagai <em>pekerja</em> yang berdaulat atas alat produksi, sekaligus memperluas keanggotaan secara formal bagi pekerja tani penggarap, buruh tani, dan nelayan kecil pesisir.</p><h3>Konteks Kabupaten Karawang</h3><p>Karawang adalah daerah tingkat II di utara Jawa Barat, mencakup <strong>30 kecamatan, 297 desa, dan 12 kelurahan</strong> dengan luas daratan ±1.753,27 km² (3,73% luas Jawa Barat) dan wilayah laut ±4 mil × 57 km. Topografinya didominasi dataran rendah (&lt;200 mdpl); hanya tiga kecamatan di selatan yang berada pada ketinggian &gt;200 mdpl hingga lebih dari 1.000 mdpl. Karawang dikenal sebagai <strong>salah satu sentra padi nasional</strong> sekaligus kawasan industri yang berkembang sejak 1989.</p><p>Kombinasi ini membuat Karawang menghadapi tekanan agraria yang khas: di satu sisi ada sawah pangan dan pesisir nelayan, di sisi lain ada konversi lahan untuk zona industri, perumahan, dan infrastruktur. Konflik agraria di sini tidak selalu tampak sebagai konflik terbuka seperti di dataran tinggi, melainkan berlangsung melalui mekanisme pasar tanah dan praktik kepemilikan <em>absentee</em>.</p><h3>Sifat dan Bentuk Organisasi</h3><p>SEPETAK adalah <strong>organisasi tani berbasis massa dan bersifat terbuka</strong>. Kami tidak membatasi keanggotaan pada satu lapisan ekonomi tertentu — anggota SEPETAK datang dari berbagai lapisan sosial pedesaan Karawang, termasuk buruh tani (<em>landless-peasant</em>), petani penyakap (<em>landless-tenant</em>), petani pemilik lahan kecil, serta warga yang menggantungkan hidup dari laut, perikanan, dan pariwisata pesisir.</p><h3>Tujuan Organisasi</h3><ol><li>Mewujudkan masyarakat Karawang yang <strong>demokratis, berkeadilan sosial, dan berkedaulatan</strong>.</li><li>Membebaskan pekerja tani dari segala bentuk penindasan dan pembodohan untuk mencapai <strong>kesetaraan dalam bidang ekonomi, sosial, budaya, hukum, dan politik</strong>.</li><li>Memperkuat posisi pekerja tani dalam menentukan <strong>kebijakan politik, hukum, sosial, dan budaya</strong> demi terwujudnya kesejahteraan yang adil, makmur, dan merata.</li></ol><h3>Pokok-pokok Perjuangan</h3><ol><li>Terlibat aktif dan memimpin perjuangan pekerja tani dalam memperjuangkan hak-haknya.</li><li>Aktif dalam membangun, mendorong, dan memajukan kesadaran pekerja tani dan organisasi tani.</li><li>Mendorong dan memajukan kesejahteraan pekerja tani.</li><li>Aktif dalam kerja-kerja solidaritas dan perjuangan Rakyat tertindas lainnya.</li></ol><h3>Jaringan Perjuangan</h3><ul><li><strong>Nasional</strong>: SEPETAK adalah anggota <a href="https://kpa.or.id" target="_blank" rel="noopener"><strong>Konsorsium Pembaruan Agraria (KPA)</strong></a> — konsorsium yang menghimpun 173 organisasi gerakan tani, masyarakat adat, dan nelayan.</li><li><strong>Daerah</strong>: SEPETAK kerap dipercaya sebagai pelopor aliansi lintas sektor di Karawang. <strong>ALIANSI PERAK</strong> (Aliansi Pergerakan Rakyat Karawang) — gabungan SEPETAK dan beberapa serikat buruh — pernah menjadi warna kuat dalam kampanye isu agraria, sosial budaya, dan tekanan politik kepada pemerintah daerah.</li><li><strong>Lintas ormas lokal</strong>: SEPETAK juga menjalin relasi dengan berbagai LSM dan ormas Karawang seperti <strong>GMBI</strong> (Gerakan Masyarakat Bawah Indonesia) dan <strong>LMP</strong> (Laskar Merah Putih) melalui proses konsolidasi gagasan yang panjang.</li></ul>	published	2026-04-16 16:57:26	1	2026-04-16 15:32:51	2026-04-16 16:57:26	\N	\N
2	Visi dan Misi	visi-misi	<h2>Visi</h2><p><strong>“Rebut Kedaulatan Agraria, Bangun Industrialisasi Pertanian.”</strong></p><p>Terwujudnya reforma agraria sejati, kedaulatan pangan, dan kesejahteraan pekerja tani serta nelayan Karawang yang berkeadilan sosial, berdaulat secara ekonomi, dan berkelanjutan secara ekologis.</p><h2>Program Perjuangan — TANI MOTEKAR</h2><p><strong>TANI MOTEKAR</strong> adalah program tuntutan dan platform perjuangan SEPETAK yang dirumuskan pada <strong>Kongres II tahun 2012</strong>. Akronim ini menyatakan lima pilar yang harus dikuasai pekerja tani agar kemandirian dan kesejahteraan benar-benar berpijak pada kontrol produksi sendiri:</p><ol><li><strong>T — Tanah</strong>: pokok dasar perjuangan; alat produksi utama yang harus dikuasai dan didistribusikan secara adil kepada pekerja tani.</li><li><strong>I — Infrastruktur</strong>: jalan desa, irigasi teknis, dan fasilitas pasca-panen sebagai prasyarat produksi pertanian rakyat yang efisien.</li><li><strong>M — Modal</strong>: bukan sekadar uang, tetapi seluruh input pertanian — benih, pupuk, dan alat-mesin pertanian — yang harus berada dalam kontrol pekerja tani, bukan korporasi.</li><li><strong>T — Teknologi</strong>: teknologi tepat guna yang meningkatkan produktivitas tanpa membuat pekerja tani tergantung pada pasokan eksternal.</li><li><strong>A — Akses Pasar</strong>: rantai pemasaran produk pertanian dan olahan lanjutan yang memutus praktik tengkulak eksploitatif melalui model pertukaran antar-organisasi di basis massa.</li></ol><p><em>TANI MOTEKAR sebagai jalan menuju Industrialisasi Pertanian</em> — industri yang diselenggarakan di sektor pertanian pedesaan, berlandaskan partisipasi penuh masyarakat, ketersediaan bahan baku lokal, kelestarian lingkungan, dan pengabdian pada kepentingan publik. Dengan begitu, pengembangan industri di Karawang tidak lagi semata-mata berarti <em>konversi sawah menjadi pabrik</em>, melainkan penguatan produksi pertanian rakyat hingga hilirnya.</p><h2>Misi</h2><ul><li>Memperjuangkan <strong>redistribusi tanah</strong> bagi pekerja tani tak bertanah dan penyelesaian konflik agraria struktural di Karawang.</li><li>Mendampingi pekerja tani dan nelayan dalam sengketa agraria, klaim kawasan hutan Perhutani, tuntutan ganti rugi gagal tanam, hingga kriminalisasi anggota.</li><li>Membangun kesadaran hukum agraria dan pendidikan kritis anggota melalui <strong>sekolah tani, diskusi dusun, dan propaganda internal</strong>.</li><li>Mendorong kebijakan pertanian dan perikanan daerah yang berpihak pada pekerja tani kecil dan nelayan tradisional — termasuk intervensi atas Perda RTRW dan perencanaan infrastruktur.</li><li>Membangun <strong>aliansi lintas sektor</strong> bersama serikat buruh, mahasiswa, dan gerakan masyarakat sipil (ALIANSI PERAK, KPA, dll.) untuk memperkuat gerakan agraria nasional.</li><li>Membangun model <strong>pertanian kolektif</strong> di desa-desa basis sebagai strategi mengakumulasi surplus produksi bagi pengambilalihan bertahap tanah <em>absentee</em>.</li><li>Menyediakan <strong>advokasi pelayanan publik</strong> bagi anggota — mulai dari pendampingan pelayanan PLN, layanan kesehatan (Jamkesda/Jamkesmas ke RSUD Karawang), hingga pendaftaran hak atas tanah — sebagai wujud nyata keberpihakan organisasi pada kesejahteraan anggota.</li></ul>	published	2026-04-16 16:57:26	1	2026-04-16 15:32:51	2026-04-16 16:57:26	\N	\N
4	Sejarah SEPETAK	sejarah	<h2>Sejarah Singkat SEPETAK</h2><h3>Latar: Gerakan Tani Karawang Sebelum SEPETAK</h3><p>Gerakan tani di Karawang menggeliat kembali pada era pasca reformasi 1998. Pada momen itu, gagasan-gagasan progresif kaum muda mulai masuk ke pedesaan Karawang melalui dua jalur utama:</p><ul><li><strong>Serikat Tani Nasional (STN)</strong> — mengawali advokasi kasus tanah <em>Kuta Tandingan</em> di Kecamatan Telukjambe Barat dan mengorganisir petani di Desa Karang Jaya, Kecamatan Pedes. Advokasi ini sempat terhenti karena represi aparat dan perubahan situasi lokal, namun berhasil menyisakan pengalaman dan kader awal.</li><li><strong>NGO Duta Tani Karawang</strong> — fokus awalnya bukan pada konflik agraria, melainkan pada advokasi produksi pertanian (termasuk pengendalian hama terpadu). Dari Duta Tani inilah kemudian lahir <strong>Dewan Tani Karawang</strong>, sebuah organisasi tani lokal yang berbasis di Cilamaya Kulon, Cilamaya Wetan, dan Pakisjaya. Dewan Tani Karawang akhirnya pecah karena perbedaan pandangan internal, terutama soal penggabungan dengan organ tani nasional.</li></ul><p>Dari dua titik masuk berbeda ini, gagasan gerakan tani terus bergulir hingga akhirnya mengkristal menjadi <strong>Serikat Petani Karawang (SEPETAK)</strong>.</p><h3>Kongres I — 3–4 November 2007</h3><p>Kongres pertama diadakan di Karawang dan menghasilkan <strong>deklarasi pembentukan organisasi pada 10 Desember 2007</strong>. Basis awal adalah lima desa di Kecamatan <em>Cilamaya Kulon, Cilamaya Wetan, dan Pakisjaya</em> — wilayah yang sebelumnya menjadi basis Dewan Tani Karawang. Kongres I menetapkan Anggaran Dasar dan struktur organisasi: Kongres, Dewan Tani, Dewan Pimpinan Tani Kabupaten (DPTK), Dewan Pimpinan Tani Desa (DPTD), dan Kelompok Kerja (Pokja).</p><h3>Kongres II — 2012</h3><p>Kongres II merumuskan dua capaian strategis:</p><ol><li><strong>TANI MOTEKAR</strong> (Tanah, Infrastruktur, Modal, Teknologi, Akses Pasar) sebagai program tuntutan dan platform perjuangan.</li><li><strong>“Bangun Industrialisasi Pertanian”</strong> sebagai program perjuangan jangka panjang.</li></ol><p>Pasca Kongres II, SEPETAK melakukan pemetaan wilayah dan menetapkan <strong>lima kategori wilayah rawan konflik agraria</strong> di Karawang: (a) masyarakat desa hutan, (b) eks Tegalwaru landen, (c) sekitar zona industri, (d) wilayah pangan, dan (e) pesisir. Pemetaan ini menjadi basis prioritas organisasi dalam membangun Pokja dan DPTD baru.</p><h3>Kongres III — 2015</h3><p>Kongres III memutuskan <strong>perubahan nama resmi</strong> dari <em>Serikat Petani Karawang</em> menjadi <strong>Serikat Pekerja Tani Karawang</strong>. Perubahan ini menegaskan posisi anggota sebagai <em>pekerja</em> yang berdaulat atas alat produksi, bukan sekadar profesi turunan. Kongres III juga memperluas keanggotaan secara formal bagi pekerja tani penggarap (<em>landless-tenant</em>) dan nelayan kecil pesisir.</p><h3>Rangkaian Aksi Perjuangan</h3><ul><li><strong>Penolakan Penambangan Pasir Laut Tanjung Pakis (2008–2009)</strong> — advokasi nelayan, pedagang wisata pantai, dan warga terdampak; berhasil menghentikan kegiatan tambang dan melahirkan basis SEPETAK baru di pesisir utara.</li><li><strong>Penolakan Penambangan Batu Andesit Tegalwaru (2009–2010)</strong> — perlawanan terhadap industri ekstraktif di dataran selatan Karawang.</li><li><strong>Aksi Ganti Rugi Gagal Tanam Cilamaya (2011)</strong> — memperjuangkan kompensasi bagi anggota yang gagal panen.</li><li><strong>Aksi Lintas Sektor &amp; Solidaritas</strong> — SEPETAK rutin terlibat dalam aksi bersama serikat buruh dan mahasiswa di Karawang untuk tuntutan ekonomis seperti infrastruktur desa, perbaikan irigasi, dan bantuan musim kekeringan.</li><li><strong>Sengketa Teluk Jambe (2013)</strong> — gugatan perdata 350 hektare lahan tiga desa melawan PT Sumber Air Mas Pratama (SAMP, diakuisisi Agung Podomoro Land) hingga Mahkamah Agung.</li><li><strong>Aksi Tol Jakarta–Cikampek (11 Juli 2013)</strong> — pekerja tani SEPETAK menutup akses tol sebagai respons putusan yang tidak berpihak.</li><li><strong>Penolakan Revisi Perda RTRW Karawang</strong> — intervensi atas rencana perubahan tata ruang, khususnya perubahan status kawasan Cilamaya Wetan menjadi kawasan perkotaan yang mengancam lahan anggota.</li><li><strong>Advokasi Pelayanan Publik</strong> — pendampingan anggota dalam urusan PLN, rujukan layanan Jamkesda/Jamkesmas ke RSUD Karawang (aksi 2012 yang kemudian melahirkan hubungan kelembagaan dengan RSUD).</li><li><strong>Aksi BPN Karawang (27 Juli 2023)</strong> — ribuan pekerja tani bersama LBH Arya Mandalika mendaftarkan <strong>88 bidang tanah di 13 desa</strong> yang diklaim sebagai kawasan hutan Perhutani tanpa dokumen utuh.</li><li><strong>Pernyataan Sikap 1 Agustus 2023</strong> — melawan kriminalisasi anggota oleh FORKOPIMDA Karawang pasca aksi 27 Juli.</li><li><strong>Hari Tani Nasional 2025 (24 September 2025)</strong> — SEPETAK bersama 139 organisasi tani-nelayan di bawah KPA menuntut 24 agenda perbaikan struktural agraria di Jakarta.</li></ul><h3>Eksperimen Pertanian Kolektif Telukjaya</h3><p>Sebagai implementasi langsung dari TANI MOTEKAR, SEPETAK pernah membangun model <em>pertanian kolektif</em> di <strong>Desa Telukjaya, Kecamatan Pakisjaya</strong>. Skema kerjanya:</p><ol><li>Organisasi menyewa lahan dari tuan tanah <em>absentee</em>.</li><li>Organisasi menyediakan seluruh input produksi — benih, pupuk, obat-obatan, serta alat dan mesin pertanian — sehingga anggota tidak terjerat tengkulak.</li><li>Surplus produksi dikumpulkan untuk <strong>membeli tanah absentee secara bertahap</strong> dan menjadi aset kolektif organisasi.</li><li>Paralel, SEPETAK juga mengadvokasi pemerintah daerah untuk turut mengambil alih tanah absentee sebagai objek reforma agraria.</li></ol><p>Eksperimen ini sempat terhambat karena persoalan internal — sebagian pengurus DPTD setempat memakai hasil produksi untuk kepentingan pribadi, dan organisasi mengambil sikap tegas memberhentikan pihak yang bersangkutan. Pengalaman ini menjadi pelajaran penting tentang perlunya <strong>kaderisasi yang kuat, transparansi keuangan, dan kontrol kolektif</strong> pada setiap skema produksi.</p><p><em>Hingga hari ini, perjuangan SEPETAK tidak pernah berhenti.</em> <strong>Tanah untuk pekerja tani. Laut untuk nelayan. Keadilan untuk semua.</strong></p>	published	2026-04-16 16:57:26	1	2026-04-16 16:32:49	2026-04-16 16:57:26	\N	\N
5	Struktur Organisasi	struktur-organisasi	<h2>Struktur Organisasi SEPETAK</h2><p>Struktur SEPETAK disusun berdasarkan Anggaran Dasar hasil Kongres I dan disempurnakan pada kongres berikutnya. Struktur dirancang agar pengambilan keputusan dilakukan secara kolektif dari tingkat dusun hingga kabupaten — <em>dari bawah ke atas</em>.</p><h3>1. Kongres</h3><p>Forum tertinggi pembuat dan pengambil keputusan. Dilaksanakan <strong>sekurang-kurangnya tiga tahun sekali</strong>. Peserta terdiri dari seluruh jajaran pimpinan SEPETAK di setiap tingkat struktur dan anggota yang mendapat rekomendasi Dewan Pimpinan.</p><h3>2. Dewan Tani</h3><p>Pembuat keputusan tertinggi setelah Kongres. Rapat dilaksanakan <strong>minimal satu kali dalam enam bulan</strong>. Anggota Dewan Tani:</p><ul><li>Seluruh jajaran Dewan Pimpinan Tani Kabupaten (DPTK).</li><li>Ketua atau perwakilan Pimpinan Tani Desa.</li><li>Anggota SEPETAK yang mendapat rekomendasi Dewan Pimpinan Tani.</li></ul><h3>3. Dewan Pimpinan Tani Kabupaten (DPTK)</h3><p>Badan pimpinan tertinggi di bawah Dewan Tani. Dipilih, diangkat, dan diberhentikan oleh Kongres untuk <strong>masa jabatan tiga tahun</strong>. DPTK adalah pimpinan harian dan pembuat keputusan harian organisasi.</p><p>Komposisi DPTK:</p><ul><li>Ketua Umum</li><li>Sekretaris Umum</li><li>Ketua Departemen dan staf, terdiri dari:<ol><li><strong>Departemen Internal</strong> — pengorganisasian, kaderisasi, keanggotaan.</li><li><strong>Departemen Advokasi dan Perjuangan Tani</strong> — advokasi hukum, kampanye, aksi massa.</li><li><strong>Departemen Dana dan Usaha</strong> — pengelolaan keuangan organisasi dan usaha produktif.</li><li><strong>Departemen Pendidikan, Penelitian, dan Propaganda</strong> — sekolah tani, riset, publikasi.</li></ol></li></ul><p>Seluruh kerja harian departemen dikoordinasi dan dikontrol oleh Sekretaris Umum.</p><h3>4. Dewan Pimpinan Tani Desa (DPTD)</h3><p>Struktur organisasi tertinggi di tingkat desa. Dibentuk melalui Konferensi atau Musyawarah Desa untuk <strong>masa jabatan dua tahun</strong>. Syarat pembentukan DPTD: <strong>minimal tiga Pokja telah terbentuk</strong> di desa tersebut. Komposisi: Ketua, Sekretaris, dan staf departemen.</p><h3>5. Kelompok Kerja (Pokja)</h3><p>Unit organisasi terkecil, terdiri dari <strong>minimal lima anggota SEPETAK</strong> dan berkedudukan di wilayah kerja 1–2 dusun. Pokja dipimpin seorang Koordinator yang dipilih oleh anggota. Tugas utama Pokja: mengkoordinasikan kerja anggota di wilayahnya dan memperluas keanggotaan ke dusun-dusun di sekitarnya.</p><h3>Dua Jalur Pengorganisasian</h3><p>Dalam praktik, SEPETAK menempuh <strong>dua jalur</strong> untuk membangun basis massa di sebuah wilayah baru:</p><ol><li><strong>Rekrutmen individu langsung</strong> — kader melakukan pendekatan satu-persatu hingga terkumpul 3–5 calon anggota di sebuah dusun, lalu membentuk Pokja.</li><li><strong>Pintu masuk konflik</strong> — pendekatan dimulai dari persoalan nyata yang dialami warga (konflik tanah, ganti rugi gagal tanam, tambang, dll.). Advokasi kolektif menjadi pengikat solidaritas yang kemudian dikonsolidasikan menjadi Pokja dan DPTD.</li></ol><p><em>Contoh historis:</em> Pembentukan Pokja di <strong>Dusun Cimahi, Desa Cikarang, Kecamatan Cilamaya Wetan pada 14 Februari 2012</strong> merupakan salah satu capaian penting yang menggabungkan kedua jalur di atas.</p><h3>Alur Rekruitmen Formal</h3><ol><li>Individu bergabung sebagai <strong>Anggota SEPETAK</strong>.</li><li>Jika ada <strong>3–5 anggota</strong> di satu dusun, bentuk <strong>Pokja</strong> dengan koordinator.</li><li>Jika terbentuk <strong>minimal tiga Pokja</strong> di satu desa, selenggarakan <strong>Konferensi / Musyawarah Desa</strong> untuk membentuk <strong>DPTD</strong>.</li><li>DPTD aktif memperluas basis ke dusun dan desa tetangga.</li></ol><h3>Catatan Kaderisasi</h3><p>Salah satu tantangan terberat organisasi adalah menghasilkan <strong>kader dari basis tani itu sendiri</strong>. Menjadi pengorganisir berarti memberikan waktu, tenaga, biaya, dan kadang keselamatan pribadi — sebuah beban yang sulit dipikul dari sektor tani yang ekonominya paling rentan. Karena itu SEPETAK terus menempatkan kaderisasi (sekolah tani, diskusi dusun, pendidikan publik) sebagai investasi jangka panjang organisasi.</p>	published	2026-04-16 16:57:26	1	2026-04-16 16:44:51	2026-04-16 16:57:26	\N	\N
6	Wilayah Kerja & Pemetaan Konflik	wilayah-kerja	<h2>Wilayah Kerja dan Pemetaan Konflik Agraria</h2><p>Karawang adalah salah satu daerah paling padat persoalan agraria di Jawa Barat: wilayah dataran rendah yang sejak 1989 terus diubah menjadi zona industri, perumahan, dan jalan tol, sementara di saat yang sama tetap menjadi sentra padi nasional. Dalam laporan Konsorsium Pembaruan Agraria (KPA) 2011, terjadi <strong>163 konflik agraria</strong> di Indonesia — 60% di sektor perkebunan, 22% kehutanan, 13% infrastruktur, 4% tambang, 1% pesisir — dengan korban mencapai <strong>22 jiwa, 69.975 KK, dan 472.048 hektare lahan</strong>. Karawang berada dalam pusaran konflik ini.</p><p>Pasca Kongres II tahun 2012, SEPETAK menetapkan <strong>lima kategori wilayah rawan konflik agraria</strong> sebagai peta prioritas pengorganisasian:</p><h3>1. Wilayah Masyarakat Desa Hutan</h3><ul><li><strong>Pihak yang terlibat</strong>: Perum Perhutani, perusahaan tambang, swasta, militer, dan pemerintah.</li><li><strong>Jenis konflik</strong>: perampasan tanah, sengketa tapal batas, dan klaim kawasan wisata.</li></ul><h3>2. Wilayah Eks Tegalwaru Landen (Karawang Selatan)</h3><ul><li><strong>Pihak yang terlibat</strong>: swasta, operator zona industri, Perhutani, pemerintah.</li><li><strong>Jenis konflik</strong>: perampasan tanah dan sengketa tapal batas.</li></ul><h3>3. Wilayah Sekitar Zona Industri</h3><ul><li><strong>Pihak yang terlibat</strong>: pengembang zona industri, perumahan, pemerintah.</li><li><strong>Jenis konflik</strong>: perampasan tanah — konversi sawah produktif menjadi kawasan industri dan perumahan.</li></ul><h3>4. Wilayah Pangan (Sabuk Sawah Karawang)</h3><ul><li><strong>Pihak yang terlibat</strong>: tuan tanah absentee dan tuan tanah lokal.</li><li><strong>Jenis konflik</strong>: kepemilikan tanah absentee yang menjerat petani penggarap ke dalam sistem penyakapan (<em>sharecropping tenancy</em>) yang eksploitatif.</li></ul><h3>5. Wilayah Pesisir</h3><ul><li><strong>Pihak yang terlibat</strong>: Perhutani, swasta, perusahaan tambang pasir laut, pemerintah.</li><li><strong>Jenis konflik</strong>: kepemilikan absentee dan perampasan ruang hidup nelayan serta pedagang pariwisata pantai.</li></ul><h3>Strategi Pengorganisasian Sesuai Peta</h3><p>Pemetaan di atas menjadi pedoman SEPETAK dalam menentukan di desa mana Pokja perlu dibangun lebih dahulu, advokasi apa yang dijalankan sesuai karakter konflik, dan siapa mitra yang relevan. Lima desa basis awal di <strong>Cilamaya Kulon, Cilamaya Wetan, dan Pakisjaya</strong> masuk dalam wilayah pangan-pesisir; sementara wilayah selatan (Tegalwaru, Pangkalan) masuk kategori hutan &amp; ekstraktif.</p><p><em>Peta ini terus diperbarui</em> — setiap DPTD baru wajib melakukan pemetaan konflik agraria di desanya sebagai dasar kerja organisasi.</p>	published	2026-04-16 16:57:26	1	2026-04-16 16:44:51	2026-04-16 16:57:26	\N	\N
3	Kontak	kontak	<h2>Hubungi Kami</h2><p>Untuk informasi lebih lanjut, permohonan pendampingan, kolaborasi lintas organisasi, atau kebutuhan data publik, silakan hubungi sekretariat SEPETAK:</p><ul><li><strong>Email resmi:</strong> info@sepetak.org</li><li><strong>Website:</strong> https://sepetak.org</li><li><strong>Alamat sekretariat:</strong> Kabupaten Karawang, Jawa Barat, Indonesia</li></ul><h3>Jalur Komunikasi</h3><ul><li><strong>Pendaftaran anggota baru</strong> — gunakan formulir online di <a href="/daftar-anggota">halaman pendaftaran anggota</a>. Setelah mendaftar, calon anggota akan dihubungi oleh Departemen Internal untuk verifikasi dan penempatan Pokja.</li><li><strong>Permohonan pendampingan kasus agraria</strong> — kirim ringkasan kasus (lokasi, pihak terlibat, kronologi, dokumen pendukung) ke email resmi. Akan ditangani oleh Departemen Advokasi dan Perjuangan Tani.</li><li><strong>Liputan media &amp; kerja sama publikasi</strong> — ajukan permohonan resmi via email dengan mencantumkan institusi, nama pewarta/perwakilan, serta topik peliputan atau kolaborasi. Akan ditangani oleh Departemen Pendidikan, Penelitian, dan Propaganda.</li><li><strong>Solidaritas dan donasi</strong> — untuk dukungan sumber daya atau solidaritas aksi, silakan konfirmasi terlebih dahulu via email agar SEPETAK dapat memberi rekening resmi dan peruntukan yang transparan.</li></ul><p><em>SEPETAK tidak memiliki hotline telepon resmi saat ini. Seluruh komunikasi resmi berjalan melalui email dan formulir di website.</em></p>	published	2026-04-16 16:57:26	1	2026-04-16 15:32:51	2026-04-16 16:57:26	\N	\N
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.password_reset_tokens (email, token, created_at) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permissions (id, name, guard_name, created_at, updated_at) FROM stdin;
1	manage-members	web	2026-04-16 15:33:55	2026-04-16 15:33:55
2	manage-cases	web	2026-04-16 15:33:55	2026-04-16 15:33:55
3	manage-advocacy	web	2026-04-16 15:33:55	2026-04-16 15:33:55
4	manage-events	web	2026-04-16 15:33:55	2026-04-16 15:33:55
5	manage-content	web	2026-04-16 15:33:55	2026-04-16 15:33:55
6	manage-settings	web	2026-04-16 15:33:55	2026-04-16 15:33:55
7	manage-users	web	2026-04-16 15:33:55	2026-04-16 15:33:55
\.


--
-- Data for Name: post_category; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.post_category (post_id, category_id) FROM stdin;
43	6
45	10
46	10
47	7
48	7
\.


--
-- Data for Name: post_tag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.post_tag (post_id, tag_id) FROM stdin;
43	1
43	8
43	12
45	3
45	10
45	11
46	10
46	11
46	16
47	4
47	6
47	17
48	5
48	8
48	11
\.


--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.posts (id, title, slug, excerpt, body, status, published_at, author_id, created_at, updated_at, deleted_at, source_type, article_topic_id, generation_log_id, ai_disclosure) FROM stdin;
45	Antonio Gramsci dan Hegemoni Budaya: Relevansi bagi Strategi Pengorganisasian Petani Indonesia	antonio-gramsci-dan-hegemoni-budaya-relevansi-bagi-strategi-pengorganisasian-petani-indonesia	Artikel ini menganalisis relevansi pemikiran Antonio Gramsci tentang hegemoni kultural dan intelektual organik bagi strategi pengorganisasian serikat petani di Indonesia. Melalui pendekatan neo-Marxian, penelitian ini mengeksplorasi bagaimana konsep hegemoni Gramsci dapat membantu memahami dominasi kultural yang dialami petani Indonesia serta strategi counter-hegemonic yang dapat dikembangkan. Analisis menunjukkan bahwa hegemoni kultural kapitalis di Indonesia tidak hanya beroperasi melalui meka	<div class="article-meta"><p><strong>Kata Kunci:</strong> Antonio Gramsci, hegemoni kultural, intelektual organik, serikat petani, gerakan agraria\n<strong>Waktu Baca:</strong> ± 15 menit</p></div>\n<nav class="article-toc"><h2 id="daftar-isi">Daftar Isi</h2><ol>\n<li><a href="#abstrak">Abstrak</a></li>\n<li><a href="#pendahuluan">Pendahuluan</a></li>\n<li><a href="#konsep-hegemoni-kultural-dalam-pemikiran-gramsci">Konsep Hegemoni Kultural dalam Pemikiran Gramsci</a></li>\n<li><a href="#intelektual-organik-dan-transformasi-kesadaran-kelas">Intelektual Organik dan Transformasi Kesadaran Kelas</a></li>\n<li><a href="#aplikasi-pemikiran-gramsci-dalam-konteks-petani-indonesia">Aplikasi Pemikiran Gramsci dalam Konteks Petani Indonesia</a></li>\n<li><a href="#kesimpulan">Kesimpulan</a></li>\n<li><a href="#daftar-pustaka">Daftar Pustaka</a></li>\n</ol></nav>\n<section class="article-abstract"><h2 id="abstrak">Abstrak</h2>\n<p>Artikel ini menganalisis relevansi pemikiran Antonio Gramsci tentang hegemoni kultural dan intelektual organik bagi strategi pengorganisasian serikat petani di Indonesia. Melalui pendekatan neo-Marxian, penelitian ini mengeksplorasi bagaimana konsep hegemoni Gramsci dapat membantu memahami dominasi kultural yang dialami petani Indonesia serta strategi counter-hegemonic yang dapat dikembangkan. Analisis menunjukkan bahwa hegemoni kultural kapitalis di Indonesia tidak hanya beroperasi melalui mekanisme ekonomi, tetapi juga melalui konstruksi ideologis yang menempatkan petani sebagai subjek yang terbelakang dan perlu dimodernisasi. Konsep intelektual organik Gramsci menawarkan kerangka untuk membangun kesadaran kritis di kalangan petani melalui proses pendidikan politik yang berakar pada pengalaman konkret mereka. Temuan ini menunjukkan bahwa strategi pengorganisasian petani yang efektif memerlukan kombinasi antara perjuangan material dan perjuangan kultural untuk menciptakan blok historis yang mampu menantang hegemoni dominan.</p>\n</section><h2 id="pendahuluan">Pendahuluan</h2>\n<p>Pemikiran <strong>Antonio Gramsci</strong> tentang hegemoni kultural telah menjadi salah satu kontribusi paling signifikan dalam tradisi Marxis abad ke-20. Berbeda dengan interpretasi Marxisme ortodoks yang menekankan determinisme ekonomi, Gramsci mengembangkan analisis yang lebih kompleks tentang bagaimana kelas dominan mempertahankan kekuasaannya tidak hanya melalui koersi, tetapi juga melalui konsensus kultural (Gramsci, 1971). Dalam konteks Indonesia kontemporer, di mana sektor pertanian masih menyerap sekitar 30% tenaga kerja namun menghadapi marginalisasi sistematis, pemikiran Gramsci menawarkan kerangka analitis yang relevan untuk memahami dinamika kekuasaan yang kompleks.</p>\n<p>Pertanian Indonesia menghadapi krisis multidimensional yang tidak dapat dipahami semata-mata sebagai persoalan teknis atau ekonomi. <strong>Hegemoni neoliberal</strong> yang telah mengakar dalam kebijakan pembangunan Indonesia sejak era Orde Baru telah menciptakan struktur dominasi yang menempatkan petani sebagai subjek yang harus disesuaikan dengan logika pasar global (Hadiz, 2010). Proses ini tidak hanya melibatkan transformasi material dalam bentuk konversi lahan dan industrialisasi pertanian, tetapi juga transformasi kultural yang mengubah cara pandang masyarakat terhadap pertanian dan petani.</p>\n<p>Dalam konteks ini, konsep <strong>intelektual organik</strong> Gramsci menjadi relevan untuk memahami bagaimana gerakan petani dapat membangun kesadaran kritis dan strategi perlawanan yang efektif. Berbeda dengan intelektual tradisional yang cenderung terpisah dari basis sosialnya, intelektual organik berakar dalam pengalaman konkret kelas sosial tertentu dan berperan dalam mengorganisir kesadaran dan kehendak kolektif (Gramsci, 1971).</p>\n<p>Artikel ini berargumen bahwa strategi pengorganisasian serikat petani di Indonesia memerlukan pendekatan Gramscian yang mengintegrasikan perjuangan material dengan perjuangan kultural. Hegemoni kapitalis di sektor pertanian Indonesia tidak dapat ditantang hanya melalui mobilisasi ekonomi, tetapi memerlukan pembangunan <strong>counter-hegemony</strong> yang mampu menawarkan visi alternatif tentang pembangunan agraria yang berkeadilan.</p>\n<p>Struktur artikel ini akan mengeksplorasi terlebih dahulu konsep hegemoni kultural dalam pemikiran Gramsci, dilanjutkan dengan analisis tentang peran intelektual organik dalam transformasi kesadaran kelas, dan kemudian mengaplikasikan kerangka teoretis tersebut dalam konteks spesifik gerakan petani Indonesia. Melalui pendekatan ini, artikel ini berupaya memberikan kontribusi teoretis dan praktis bagi pengembangan strategi pengorganisasian yang lebih efektif di kalangan serikat pekerja tani.</p>\n<div class="article-back-to-section"><a href="#daftar-isi" class="back-to-top-link" aria-label="Kembali ke daftar isi">&uarr; Kembali ke Daftar Isi</a></div><h2 id="konsep-hegemoni-kultural-dalam-pemikiran-gramsci">Konsep Hegemoni Kultural dalam Pemikiran Gramsci</h2>\n<p>Konsep <strong>hegemoni</strong> dalam pemikiran Gramsci merepresentasikan pengembangan yang revolusioner dari teori Marxis klasik tentang kekuasaan dan dominasi kelas. Gramsci mendefinisikan hegemoni sebagai &quot;kepemimpinan moral dan intelektual&quot; yang memungkinkan kelas dominan mempertahankan kekuasaannya tidak semata melalui koersi, tetapi melalui penciptaan konsensus aktif dari kelas-kelas yang didominasi (Gramsci, 1971). Dalam <em>Prison Notebooks</em>, Gramsci menjelaskan bahwa hegemoni beroperasi melalui <strong>civil society</strong>, berbeda dengan dominasi langsung yang beroperasi melalui <em>political society</em> atau negara.</p>\n<p>Hegemoni kultural berfungsi melalui mekanisme yang kompleks di mana nilai-nilai, norma, dan pandangan dunia kelas dominan dipresentasikan sebagai &quot;akal sehat&quot; (<em>common sense</em>) yang universal dan natural. Proses ini tidak melibatkan manipulasi sederhana, tetapi konstruksi aktif dari suatu <strong>worldview</strong> yang komprehensif yang mampu mengintegrasikan kepentingan berbagai kelompok sosial di bawah kepemimpinan kelas hegemonik (Gramsci, 1971). Dalam konteks ini, Gramsci membedakan antara <em>common sense</em> yang spontan dan tidak kritis dengan <em>good sense</em> yang reflektif dan kritis.</p>\n<p>Dalam konteks pertanian Indonesia, hegemoni kultural neoliberal beroperasi melalui diskursus <strong>modernisasi</strong> yang menempatkan pertanian skala kecil sebagai sektor yang terbelakang dan tidak efisien. Diskursus ini diproduksi dan direproduksi melalui berbagai aparatus hegemonik, mulai dari sistem pendidikan, media massa, hingga program-program pembangunan pemerintah. Petani dikonstruksi sebagai subjek yang perlu &quot;diberdayakan&quot; melalui integrasi ke dalam ekonomi pasar global, bukan sebagai aktor yang memiliki pengetahuan dan sistem produksi yang valid secara ekologis dan sosial.</p>\n<p><strong>Transformasi passive revolution</strong> yang dijelaskan Gramsci juga relevan untuk memahami dinamika perubahan agraria di Indonesia. Konsep ini merujuk pada proses modernisasi yang dipimpin dari atas (<em>trasformismo</em>) yang mengintegrasikan elemen-elemen progresif ke dalam sistem dominan tanpa mengubah struktur kekuasaan fundamental (Gramsci, 1971). Program-program seperti <em>corporate social responsibility</em> di sektor perkebunan atau skema kemitraan inti-plasma dapat dipahami sebagai bentuk <em>passive revolution</em> yang mengkooptasi tuntutan petani tanpa mengubah relasi produksi yang eksploitatif.</p>\n<p>Gramsci juga mengembangkan konsep <strong>war of position</strong> versus <em>war of movement</em> yang penting untuk strategi perjuangan politik. Jika <em>war of movement</em> merujuk pada konfrontasi langsung untuk merebut kekuasaan negara, <em>war of position</em> melibatkan perjuangan jangka panjang untuk merebut hegemoni kultural di civil society. Dalam masyarakat kapitalis maju dengan civil society yang kompleks, <em>war of position</em> menjadi strategi yang lebih relevan dibandingkan dengan <em>war of movement</em> (Gramsci, 1971).</p>\n<p>Konsep <strong>blok historis</strong> Gramsci menjelaskan bagaimana hegemoni tidak hanya melibatkan dominasi kelas tunggal, tetapi aliansi kompleks antara berbagai fraksi kelas dan kelompok sosial yang dipersatukan oleh suatu proyek hegemonik. Dalam konteks Indonesia, blok historis neoliberal mencakup aliansi antara kapital transnasional, birokrasi negara, kelas menengah urban, dan sebagian elit lokal yang terintegrasi dalam ekonomi global. Pemahaman tentang komposisi dan kontradiksi internal blok historis ini penting untuk mengembangkan strategi counter-hegemonik yang efektif.</p>\n<p>Relevansi konsep hegemoni Gramsci dalam konteks petani Indonesia juga dapat dilihat melalui analisis tentang bagaimana <strong>pengetahuan tradisional</strong> petani didiskreditkan dan digantikan dengan pengetahuan &quot;ilmiah&quot; modern yang selaras dengan kepentingan agribisnis. Proses ini tidak hanya melibatkan transformasi teknik produksi, tetapi juga transformasi epistemologis yang mengubah cara petani memahami hubungan mereka dengan alam, komunitas, dan sistem produksi.</p>\n<div class="article-back-to-section"><a href="#daftar-isi" class="back-to-top-link" aria-label="Kembali ke daftar isi">&uarr; Kembali ke Daftar Isi</a></div><h2 id="intelektual-organik-dan-transformasi-kesadaran-kelas">Intelektual Organik dan Transformasi Kesadaran Kelas</h2>\n<p>Konsep <strong>intelektual organik</strong> merupakan salah satu kontribusi paling orisinal Gramsci dalam teori Marxis tentang kesadaran kelas dan transformasi sosial. Berbeda dengan konsepsi tradisional tentang intelektual sebagai stratum sosial yang terpisah dan netral, Gramsci berargumen bahwa setiap kelas sosial menciptakan intelektualnya sendiri yang berfungsi mengorganisir kesadaran dan kehendak kolektif kelas tersebut (Gramsci, 1971). Intelektual organik tidak hanya memproduksi ide, tetapi juga berperan sebagai &quot;organizer&quot; yang menghubungkan teori dengan praktik politik konkret.</p>\n<p>Gramsci membedakan antara <strong>intelektual tradisional</strong> dan intelektual organik berdasarkan hubungan mereka dengan kelas sosial dan mode produksi. Intelektual tradisional, seperti klerus atau akademisi, mengklaim otonomi dan netralitas, padahal secara objektif mereka terikat pada kelas dominan dan berfungsi mempertahankan hegemoni yang ada. Sebaliknya, intelektual organik secara sadar mengidentifikasi diri dengan kepentingan kelas tertentu dan berperan aktif dalam perjuangan hegemonik (Gramsci, 1971).</p>\n<p>Dalam konteks gerakan petani Indonesia, konsep intelektual organik menawarkan kerangka untuk memahami peran <strong>pemimpin petani</strong> yang tidak hanya memiliki kemampuan teknis dalam pertanian, tetapi juga kemampuan untuk mengartikulasikan kepentingan petani dalam bahasa politik yang koheren. Intelektual organik petani berbeda dengan <em>development worker</em> atau teknisi pertanian yang datang dari luar, karena mereka berakar dalam pengalaman konkret komunitas petani dan memahami kontradiksi yang dihadapi petani dari perspektif internal.</p>\n<p>Proses pembentukan intelektual organik melibatkan <strong>transformasi epistemologis</strong> dari <em>common sense</em> menuju <em>good sense</em>. Gramsci menjelaskan bahwa <em>common sense</em> mengandung elemen-elemen progresif yang dapat dikembangkan menjadi kesadaran kritis melalui proses pendidikan politik yang sistematis. Dalam konteks petani, ini berarti mengembangkan kemampuan untuk menganalisis secara kritis relasi produksi kapitalis di sektor pertanian dan mengidentifikasi alternatif-alternatif yang memungkinkan (Gramsci, 1971).</p>\n<p><strong>Fungsi pedagogis</strong> intelektual organik menjadi krusial dalam konteks ini. Berbeda dengan model pendidikan <em>banking</em> yang dikritik Paulo Freire, pendekatan Gramscian menekankan dialog kritis antara intelektual organik dengan basis sosialnya. Intelektual organik petani tidak hanya mentransmisikan pengetahuan dari luar, tetapi juga belajar dari pengalaman dan pengetahuan tradisional petani, menciptakan sintesis baru yang lebih kaya dan kontekstual.</p>\n<p>Gramsci juga mengembangkan konsep <strong>philosophy of praxis</strong> yang relevan untuk memahami peran intelektual organik dalam transformasi sosial. <em>Philosophy of praxis</em> merujuk pada pendekatan yang mengintegrasikan teori dengan praktik, di mana aktivitas teoretis tidak terpisah dari aktivitas praktis-politik. Bagi intelektual organik petani, ini berarti mengembangkan analisis teoretis yang berakar dalam perjuangan konkret petani dan sekaligus menginformasikan strategi perjuangan tersebut (Gramsci, 1971).</p>\n<p>Dalam konteks serikat pekerja tani, konsep intelektual organik dapat dioperasionalisasi melalui <strong>program pendidikan politik</strong> yang sistematis. Program ini tidak hanya melibatkan transmisi pengetahuan tentang hak-hak petani atau teknik berorganisasi, tetapi juga pengembangan kemampuan analitis untuk memahami struktur kekuasaan yang mengoperasikan dominasi terhadap petani. Intelektual organik berperan sebagai fasilitator dalam proses ini, membantu petani mengembangkan kesadaran kritis tentang posisi mereka dalam struktur sosial yang lebih luas.</p>\n<p>Konsep <strong>collective intellectual</strong> yang dikembangkan Gramsci juga relevan untuk konteks serikat petani. Gramsci berargumen bahwa dalam kondisi tertentu, organisasi politik progresif dapat berfungsi sebagai &quot;intelektual kolektif&quot; yang mengorganisir kesadaran dan kehendak kelas-kelas subaltern. Serikat pekerja tani dapat memainkan peran ini dengan mengembangkan kapasitas analitis kolektif dan menjadi pusat produksi pengetahuan alternatif tentang pertanian dan pembangunan agraria.</p>\n<p>Relevansi konsep intelektual organik juga dapat dilihat dalam konteks <strong>media alternatif</strong> dan komunikasi politik. Dalam era digital, intelektual organik petani perlu mengembangkan kemampuan untuk menggunakan teknologi komunikasi untuk menyebarkan counter-narrative yang menantang hegemoni dominan. Ini melibatkan tidak hanya kemampuan teknis, tetapi juga kemampuan untuk mengartikulasikan pengalaman petani dalam bahasa yang dapat dipahami oleh audiens yang lebih luas.</p>\n<div class="article-back-to-section"><a href="#daftar-isi" class="back-to-top-link" aria-label="Kembali ke daftar isi">&uarr; Kembali ke Daftar Isi</a></div><h2 id="aplikasi-pemikiran-gramsci-dalam-konteks-petani-indonesia">Aplikasi Pemikiran Gramsci dalam Konteks Petani Indonesia</h2>\n<p>Aplikasi pemikiran Gramsci dalam konteks gerakan petani Indonesia memerlukan analisis konkret tentang bagaimana hegemoni neoliberal beroperasi di sektor pertanian dan bagaimana strategi counter-hegemonik dapat dikembangkan. <strong>Kondisi objektif</strong> petani Indonesia menunjukkan kontradiksi yang mendalam antara retorika pembangunan yang mengklaim pro-petani dengan realitas marginalisasi sistematis yang dialami petani kecil.</p>\n<p>Hegemoni neoliberal di sektor pertanian Indonesia beroperasi melalui berbagai mekanisme yang saling terkait. Pertama, <strong>diskursus modernisasi</strong> yang menempatkan pertanian industrial sebagai model yang harus diikuti oleh semua petani. Diskursus ini diproduksi melalui sistem pendidikan pertanian, program penyuluhan, dan media massa yang secara konsisten mempromosikan teknologi intensif modal sebagai solusi untuk meningkatkan produktivitas. Kedua, <strong>kebijakan struktural</strong> seperti liberalisasi perdagangan, deregulasi investasi, dan program sertifikasi lahan yang memfasilitasi akumulasi kapital di sektor pertanian sambil memarginalkan petani kecil (White, 2012).</p>\n<p>Dalam konteks ini, konsep <strong>passive revolution</strong> Gramsci membantu memahami bagaimana program-program seperti <strong>Kredit Usaha Rakyat (KUR)</strong> atau skema kemitraan dengan korporasi agribisnis berfungsi sebagai mekanisme untuk mengintegrasikan petani ke dalam sistem kapitalis tanpa mengubah relasi produksi yang eksploitatif. Program-program ini menciptakan ilusi partisipasi dan pemberdayaan sambil memperdalam ketergantungan petani terhadap input eksternal dan pasar global yang volatil.</p>\n<p>Strategi <strong>war of position</strong> dalam konteks petani Indonesia melibatkan perjuangan di berbagai front secara simultan. Di front ideologis, ini berarti mengembangkan <strong>counter-narrative</strong> yang menantang diskursus modernisasi dan mempromosikan model pertanian berkelanjutan yang berbasis pada pengetahuan lokal dan ekologi. Organisasi seperti Serikat Petani Indonesia (SPI) telah mengembangkan konsep <strong>kedaulatan pangan</strong> sebagai alternatif terhadap konsep ketahanan pangan yang lebih teknis dan depolitisasi (Patel, 2009).</p>\n<p><strong>Peran intelektual organik</strong> dalam gerakan petani Indonesia dapat dilihat dalam figur-figur seperti Henry Saragih dari SPI atau aktivis-aktivis lokal yang berhasil mengartikulasikan pengalaman petani dalam bahasa politik yang koheren. Intelektual organik ini tidak hanya memiliki kemampuan untuk menganalisis kontradiksi struktural yang dihadapi petani, tetapi juga kemampuan untuk mengorganisir perlawanan kolektif melalui berbagai bentuk mobilisasi politik.</p>\n<p>Konsep <strong>blok historis</strong> membantu memahami pentingnya membangun aliansi strategis antara gerakan petani dengan sektor-sektor progresif lainnya. Dalam konteks Indonesia, ini melibatkan aliansi dengan gerakan lingkungan, gerakan buruh urban, organisasi masyarakat sipil, dan bahkan fraksi-fraksi progresif dalam birokrasi negara. <strong>Aliansi lintas sektoral</strong> ini penting karena petani secara numerik tidak cukup kuat untuk menantang hegemoni dominan secara sendirian.</p>\n<p>Aplikasi konsep Gramsci juga relevan untuk memahami <strong>resistensi sehari-hari</strong> petani yang dijelaskan James Scott (1985) dalam <em>Weapons of the Weak</em>. Scott menunjukkan bahwa petani mengembangkan berbagai bentuk resistensi yang tidak terorganisir tetapi efektif dalam mengganggu dominasi kelas penguasa. Dalam kerangka Gramscian, resistensi sehari-hari ini dapat dipahami sebagai manifestasi dari kontradiksi antara <em>common sense</em> dan pengalaman konkret petani, yang dapat dikembangkan menjadi kesadaran kritis melalui intervensi intelektual organik.</p>\n<p><strong>Pendidikan politik</strong> berbasis komunitas menjadi instrumen penting dalam strategi Gramscian. Serikat pekerja tani perlu mengembangkan program pendidikan yang tidak hanya fokus pada hak-hak legal petani, tetapi juga pada analisis struktural tentang bagaimana sistem kapitalis beroperasi di sektor pertanian. Program seperti <strong>sekolah petani</strong> yang dikembangkan berbagai organisasi petani dapat berfungsi sebagai ruang untuk mengembangkan kesadaran kritis dan membangun solidaritas kolektif.</p>\n<p>Konsep <strong>subaltern</strong> yang dikembangkan Gramsci dan diperluas oleh Gayatri Spivak (1988) juga relevan untuk memahami posisi petani perempuan dalam gerakan petani Indonesia. Spivak menunjukkan bahwa kelompok subaltern, terutama perempuan, menghadapi kesulitan untuk &quot;berbicara&quot; dalam ruang politik yang didominasi oleh logika maskulin dan elitis. Dalam konteks ini, strategi Gramscian perlu mencakup upaya khusus untuk mengembangkan kepemimpinan organik di kalangan petani perempuan dan memastikan bahwa suara mereka terintegrasi dalam agenda politik gerakan petani.</p>\n<div class="article-back-to-section"><a href="#daftar-isi" class="back-to-top-link" aria-label="Kembali ke daftar isi">&uarr; Kembali ke Daftar Isi</a></div><h2 id="kesimpulan">Kesimpulan</h2>\n<p>Analisis terhadap pemikiran Antonio Gramsci dalam konteks gerakan petani Indonesia menunjukkan relevansi yang signifikan dari konsep-konsep seperti hegemoni kultural, intelektual organik, dan war of position untuk mengembangkan strategi pengorganisasian yang lebih efektif. Hegemoni neoliberal di sektor pertanian Indonesia tidak hanya beroperasi melalui mekanisme ekonomi, tetapi juga melalui konstruksi ideologis yang sistematis yang menempatkan petani sebagai subjek yang harus disesuaikan dengan logika pasar global.</p>\n<p>Konsep <strong>intelektual organik</strong> menawarkan kerangka untuk memahami bagaimana kesadaran kritis dapat dikembangkan di kalangan petani melalui proses pendidikan politik yang berakar dalam pengalaman konkret mereka. Berbeda dengan pendekatan top-down yang mendominasi program pembangunan pertanian, pendekatan Gramscian menekankan pentingnya mengembangkan kepemimpinan yang berasal dari dalam komunitas petani sendiri dan mampu mengartikulasikan kepentingan petani dalam bahasa politik yang koheren.</p>\n<p>Strategi <strong>war of position</strong> menunjukkan bahwa perjuangan petani tidak dapat dibatasi pada mobilisasi ekonomi semata, tetapi harus mencakup perjuangan kultural untuk membangun counter-hegemony yang menawarkan visi alternatif tentang pembangunan agraria. Ini melibatkan pengembangan diskursus tandingan yang menantang narasi modernisasi dan mempromosikan model pertanian berkelanjutan yang berbasis pada kedaulatan pangan dan keadilan ekologis.</p>\n<p><strong>Implikasi praktis</strong> dari analisis ini menunjukkan bahwa serikat pekerja tani perlu mengembangkan pendekatan yang lebih holistik dalam pengorganisasian, yang mengintegrasikan perjuangan material dengan perjuangan kultural. Program pendidikan politik berbasis komunitas, pengembangan media alternatif, dan pembangunan aliansi strategis dengan sektor progresif lainnya menjadi elemen-elemen penting dalam strategi ini.</p>\n<p>Rekomendasi untuk gerakan petani Indonesia meliputi: pertama, pengembangan <strong>program pendidikan politik</strong> yang sistematis untuk mengembangkan kesadaran kritis di kalangan petani; kedua, pembangunan <strong>kapasitas komunikasi politik</strong> untuk mengembangkan narasi tandingan yang efektif; ketiga, penguatan <strong>aliansi lintas sektoral</strong> dengan gerakan sosial progresif lainnya; dan keempat, pengembangan <strong>kepemimpinan organik</strong> yang berakar dalam komunitas petani, terutama di kalangan petani perempuan dan petani muda.</p>\n<p>Pemikiran Gramsci mengingatkan bahwa transformasi sosial yang fundamental memerlukan perubahan tidak hanya dalam struktur ekonomi, tetapi juga dalam struktur kesadaran dan kebudayaan. Bagi gerakan petani Indonesia, ini berarti bahwa perjuangan untuk keadilan agraria harus dipahami sebagai perjuangan hegemonik yang komprehensif untuk membangun tatanan sosial yang lebih demokratis dan berkelanjutan.</p>\n<div class="article-back-to-section"><a href="#daftar-isi" class="back-to-top-link" aria-label="Kembali ke daftar isi">&uarr; Kembali ke Daftar Isi</a></div><section class="article-bibliography"><h2 id="daftar-pustaka">Daftar Pustaka</h2>\n<p>Gramsci, A. (1971). <em>Selections from the Prison Notebooks</em>. International Publishers.</p>\n<p>Hadiz, V. R. (2010). <em>Localising Power in Post-Authoritarian Indonesia: A Southeast Asia Perspective</em>. Stanford University Press.</p>\n<p>Konsorsium Pembaruan Agraria. (2019). <em>Catatan Akhir Tahun 2019: Masa Depan Reforma Agraria di Bawah Ancaman Investasi</em>. KPA.</p>\n<p>Patel, R. (2009). Food sovereignty. <em>The Journal of Peasant Studies</em>, <em>36</em>(3), 663-706. <a href="https://doi.org/10.1080/03066150903143079">https://doi.org/10.1080/03066150903143079</a></p>\n<p>Poulantzas, N. (1978). <em>State, Power, Socialism</em>. New Left Books.</p>\n<p>Scott, J. C. (1985). <em>Weapons of the Weak: Everyday Forms of Peasant Resistance</em>. Yale University Press.</p>\n<p>Spivak, G. C. (1988). Can the subaltern speak? In C. Nelson &amp; L. Grossberg (Eds.), <em>Marxism and the Interpretation of Culture</em> (pp. 271-313). University of Illinois Press.</p>\n<p>White, B. (2012). Agriculture and the generation problem: Rural youth, employment and the future of farming. <em>IDS Bulletin</em>, <em>43</em>(6), 9-19. <a href="https://doi.org/10.1111/j.1759-5436.2012.00375.x">https://doi.org/10.1111/j.1759-5436.2012.00375.x</a></p>\n</section><hr class="article-disclosure-divider"><aside class="article-disclosure"><p><em>Artikel ini disusun dengan bantuan kecerdasan buatan dan telah ditinjau oleh redaksi SEPETAK. Referensi yang dicantumkan adalah sumber nyata yang dapat diverifikasi. Pandangan dalam artikel ini tidak selalu mencerminkan posisi resmi organisasi.</em></p></aside>	published	2026-04-17 23:45:53	1	2026-04-17 23:33:02	2026-04-17 23:57:11	\N	auto_generated	4	3	t
1	Selamat Datang di Website Resmi SEPETAK	selamat-datang-di-website-sepetak	Kami dengan bangga mempersembahkan website resmi SEPETAK (Serikat Pekerja Tani Karawang) sebagai pusat informasi perjuangan pekerja tani dan nelayan Karawang.	<p>Selamat datang di website resmi <strong>SEPETAK — Serikat Pekerja Tani Karawang</strong>. Melalui platform ini kami berbagi informasi, berita, dan perkembangan terkini seputar perjuangan hak-hak pekerja tani dan nelayan di Kabupaten Karawang, Jawa Barat.</p><p>SEPETAK berdiri sejak Kongres I pada 3–4 November 2007 dan dideklarasikan pada 10 Desember 2007 di Karawang. Sejak Kongres III, nama organisasi resmi berubah dari <em>Serikat Petani Karawang</em> menjadi <strong>Serikat Pekerja Tani Karawang</strong> untuk menegaskan bahwa kami adalah organisasi pekerja tani yang berdaulat, bukan sekadar kelompok profesi.</p><p>Website ini menjadi ruang digital bagi seluruh anggota dan simpatisan untuk tetap terhubung dengan gerakan reforma agraria yang kami perjuangkan bersama.</p>	archived	2026-04-16 16:57:26	1	2026-04-16 15:32:51	2026-04-17 23:23:29	2026-04-17 23:23:29	manual	\N	\N	f
2	Perjuangan Reforma Agraria di Karawang	perjuangan-reforma-agraria-di-karawang	Reforma agraria merupakan inti dari perjuangan SEPETAK untuk mewujudkan keadilan bagi petani Karawang.	<p>Reforma agraria adalah redistribusi tanah dari tuan tanah kepada petani penggarap yang tidak memiliki lahan sendiri. Di Karawang, isu ini sangat krusial mengingat alih fungsi lahan pertanian yang terus terjadi.</p><p>SEPETAK aktif mendampingi petani dalam proses advokasi hukum, negosiasi dengan pemerintah daerah, dan kampanye kesadaran publik untuk mendorong pelaksanaan reforma agraria yang sejati.</p>	archived	2026-04-13 16:57:26	1	2026-04-16 15:32:51	2026-04-17 23:23:29	2026-04-17 23:23:29	manual	\N	\N	f
3	Kegiatan Pendampingan Petani 2025	kegiatan-pendampingan-petani-2025	Sepanjang tahun 2025, SEPETAK intensif melakukan pendampingan hukum dan pelatihan bagi petani anggota.	<p>Program pendampingan petani 2025 mencakup berbagai kegiatan mulai dari pelatihan hukum agraria, pendampingan kasus sengketa tanah, hingga lokakarya pertanian berkelanjutan.</p><p>Sebanyak ratusan petani di berbagai kecamatan di Karawang telah mendapat manfaat dari program ini. Kami berkomitmen untuk terus hadir dan mendampingi petani dalam setiap langkah perjuangan mereka.</p>	archived	2026-04-09 16:57:26	1	2026-04-16 15:32:51	2026-04-17 23:23:29	2026-04-17 23:23:29	manual	\N	\N	f
46	Senjata Kaum Lemah: Perlawanan Sehari-hari Petani ala James C. Scott	senjata-kaum-lemah-perlawanan-sehari-hari-petani-ala-james-c-scott	Artikel ini mengkaji pemikiran James C. Scott tentang everyday forms of resistance dan relevansinya dalam memahami perlawanan petani Karawang terhadap struktur ketidakadilan agraria. Scott mengargumentasikan bahwa perlawanan petani tidak selalu berbentuk revolusi atau pemberontakan terbuka, melainkan melalui taktik-taktik harian yang tersembunyi namun sistematis. Melalui analisis ekonomi politik agraria, artikel ini menunjukkan bagaimana konsep Scott dapat digunakan untuk memahami strategi berta	<div class="article-meta"><p><strong>Kata Kunci:</strong> James C. Scott, perlawanan petani, everyday resistance, ekonomi politik agraria, Karawang\n<strong>Waktu Baca:</strong> ± 12 menit</p></div>\n<nav class="article-toc"><h2 id="daftar-isi">Daftar Isi</h2><ol>\n<li><a href="#abstrak">Abstrak</a></li>\n<li><a href="#pendahuluan">Pendahuluan</a></li>\n<li><a href="#anatomi-senjata-kaum-lemah-konsep-everyday-resistance-scott">Anatomi Senjata Kaum Lemah: Konsep Everyday Resistance Scott</a></li>\n<li><a href="#melampaui-revolusi-kritik-scott-terhadap-narasi-besar-perlawanan-petani">Melampaui Revolusi: Kritik Scott terhadap Narasi Besar Perlawanan Petani</a></li>\n<li><a href="#perlawanan-harian-petani-karawang-dari-teori-ke-praktik">Perlawanan Harian Petani Karawang: Dari Teori ke Praktik</a></li>\n<li><a href="#negara-dan-petani-dialektika-dominasi-dan-resistensi">Negara dan Petani: Dialektika Dominasi dan Resistensi</a></li>\n<li><a href="#kesimpulan">Kesimpulan</a></li>\n<li><a href="#daftar-pustaka">Daftar Pustaka</a></li>\n</ol></nav>\n<section class="article-abstract"><h2 id="abstrak">Abstrak</h2>\n<p>Artikel ini mengkaji pemikiran James C. Scott tentang <strong>everyday forms of resistance</strong> dan relevansinya dalam memahami perlawanan petani Karawang terhadap struktur ketidakadilan agraria. Scott mengargumentasikan bahwa perlawanan petani tidak selalu berbentuk revolusi atau pemberontakan terbuka, melainkan melalui taktik-taktik harian yang tersembunyi namun sistematis. Melalui analisis ekonomi politik agraria, artikel ini menunjukkan bagaimana konsep Scott dapat digunakan untuk memahami strategi bertahan hidup petani Karawang menghadapi tekanan modernisasi pertanian, konversi lahan, dan dominasi korporasi agribisnis. Temuan menunjukkan bahwa petani Karawang menggunakan berbagai bentuk perlawanan harian seperti <em>foot-dragging</em>, sabotase halus, dan jaringan solidaritas informal sebagai respons terhadap marginalisasi. Kesimpulan artikel menekankan pentingnya memahami dimensi politik dalam tindakan sehari-hari petani untuk membangun strategi organisasi yang lebih efektif bagi gerakan tani kontemporer.</p>\n</section><h2 id="pendahuluan">Pendahuluan</h2>\n<p>Dalam lanskap studi agraria kontemporer, sedikit pemikir yang mampu mengubah cara pandang kita terhadap politik petani seperti <strong>James C. Scott</strong>. Melalui karya monumentalnya <em>Weapons of the Weak: Everyday Forms of Peasant Resistance</em> (1985), Scott menantang ortodoksi akademik yang selama ini melihat perlawanan petani hanya dalam bentuk revolusi atau pemberontakan terbuka. Bagi Scott, kekuatan sejati petani justru terletak pada kemampuan mereka melakukan perlawanan harian yang tersembunyi, sistematis, dan berkelanjutan.</p>\n<p>Pemikiran Scott menjadi relevan ketika kita mengamati kondisi petani di Karawang, Jawa Barat, yang menghadapi tekanan struktural dari berbagai arah: industrialisasi yang masif, konversi lahan pertanian untuk kawasan industri, penetrasi korporasi agribisnis, dan kebijakan pertanian yang bias terhadap modernisasi kapitalis (Konsorsium Pembaruan Agraria, 2021). Di tengah tekanan tersebut, petani Karawang tidak melakukan pemberontakan spektakuler, namun mereka juga tidak pasif menerima dominasi. Mereka mengembangkan repertoar perlawanan yang halus namun efektif.</p>\n<p>Pertanyaan analitis yang diajukan artikel ini adalah: bagaimana konsep <em>everyday forms of resistance</em> Scott dapat membantu kita memahami strategi bertahan hidup dan perlawanan petani Karawang? Sejauh mana kerangka teoretis Scott masih relevan untuk menganalisis dinamika agraria kontemporer di Indonesia? Dan bagaimana pemahaman ini dapat memperkuat strategi organisasi gerakan tani?</p>\n<p>Tesis utama artikel ini mengargumentasikan bahwa pemikiran Scott tentang perlawanan sehari-hari menyediakan lensa analitis yang kuat untuk memahami politik petani Karawang. Namun, konsep Scott perlu diperkaya dengan perspektif ekonomi politik agraria yang mempertimbangkan dinamika akumulasi kapital, peran negara, dan transformasi sistem pangan global. Melalui sintesis ini, kita dapat mengembangkan strategi organisasi yang lebih sensitif terhadap realitas politik petani di tingkat grassroots.</p>\n<p>Artikel ini akan dimulai dengan eksplorasi mendalam terhadap konsep <em>everyday resistance</em> Scott, dilanjutkan dengan analisis kritisnya terhadap narasi revolusi petani, kemudian mengaplikasikan kerangka teoretis tersebut untuk memahami praktik perlawanan petani Karawang, dan diakhiri dengan refleksi tentang dialektika negara-petani dalam konteks Indonesia kontemporer.</p>\n<div class="article-back-to-section"><a href="#daftar-isi" class="back-to-top-link" aria-label="Kembali ke daftar isi">&uarr; Kembali ke Daftar Isi</a></div><h2 id="anatomi-senjata-kaum-lemah-konsep-everyday-resistance-scott">Anatomi Senjata Kaum Lemah: Konsep Everyday Resistance Scott</h2>\n<p>James C. Scott memulai revolusi teoretisnya dengan pertanyaan sederhana namun fundamental: mengapa petani yang mengalami penindasan struktural jarang melakukan pemberontakan terbuka? Melalui etnografi mendalam di desa Sedaka, Malaysia, Scott menemukan bahwa ketiadaan revolusi petani bukan berarti ketiadaan perlawanan. Sebaliknya, petani mengembangkan apa yang disebutnya <strong>&quot;everyday forms of resistance&quot;</strong> — bentuk-bentuk perlawanan harian yang tidak terorganisir secara formal namun sistematis dan berkelanjutan (Scott, 1985).</p>\n<p><strong>Everyday resistance</strong> Scott mencakup spektrum luas tindakan yang tampak individual namun memiliki dampak kolektif: <em>foot-dragging</em> (bekerja dengan sengaja lambat), desersi, sabotase halus, pencurian kecil, pembangkangan diam-diam (<em>silent disobedience</em>), dan <em>false compliance</em> (kepatuhan palsu). Tindakan-tindakan ini memiliki karakteristik khusus: dilakukan secara individual atau dalam kelompok kecil, tidak memerlukan koordinasi formal, menghindari konfrontasi langsung dengan otoritas, dan bersifat anonim atau dapat disangkal (<em>deniable</em>).</p>\n<p>Keunggulan strategi ini terletak pada kemampuannya meminimalkan risiko represif sambil tetap mengikis legitimasi dan efektivitas dominasi. Scott (1985) menganalogikan strategi ini dengan <strong>&quot;death by a thousand cuts&quot;</strong> — masing-masing tindakan tampak sepele, namun secara kumulatif dapat melumpuhkan sistem dominasi. Dalam konteks agraria, hal ini berarti petani dapat menolak ekstraksi surplus tanpa harus menghadapi risiko kekerasan negara atau tuan tanah.</p>\n<p>Scott mengembangkan tipologi perlawanan berdasarkan dua dimensi: tingkat organisasi (individual vs kolektif) dan tingkat konfrontasi (tersembunyi vs terbuka). <strong>Everyday resistance</strong> berada di kuadran &quot;individual-tersembunyi&quot;, berbeda dengan revolusi yang berada di kuadran &quot;kolektif-terbuka&quot;. Namun Scott mengargumentasikan bahwa dikotomi ini tidak rigid — tindakan individual dapat memiliki efek kolektif, dan perlawanan tersembunyi dapat berkembang menjadi gerakan terbuka dalam kondisi tertentu.</p>\n<p>Konsep ini juga terkait erat dengan pemahaman Scott tentang <strong>&quot;hidden transcript&quot;</strong> — wacana kritik yang dikembangkan kelompok subordinat di luar pandangan kelompok dominan. <em>Hidden transcript</em> ini menjadi fondasi ideologis bagi <em>everyday resistance</em>, menyediakan justifikasi moral dan kerangka makna bagi tindakan perlawanan (Scott, 1990). Dalam konteks petani, <em>hidden transcript</em> sering berbentuk kritik terhadap ketidakadilan distribusi tanah, eksploitasi tenaga kerja, atau kebijakan yang merugikan.</p>\n<p>Penting untuk memahami bahwa Scott tidak meromantisasi <em>everyday resistance</em>. Ia mengakui bahwa strategi ini memiliki keterbatasan: tidak mampu mengubah struktur dasar dominasi, dapat dikooptasi oleh elite, dan terkadang justru memperkuat status quo dengan menyediakan &quot;safety valve&quot; bagi ketegangan sosial. Namun bagi Scott, <em>everyday resistance</em> tetap merupakan bentuk politik yang rasional dan efektif dalam konteks ketimpangan kekuatan yang ekstrem.</p>\n<div class="article-key-takeaway"><div class="key-takeaway-label">Poin Penting</div><p>Everyday resistance Scott bukan sekadar adaptasi pasif petani terhadap dominasi, melainkan strategi politik yang rasional untuk mengikis legitimasi dan efektivitas sistem penindasan tanpa menghadapi risiko represif yang tinggi.</p></div>\n<div class="article-back-to-section"><a href="#daftar-isi" class="back-to-top-link" aria-label="Kembali ke daftar isi">&uarr; Kembali ke Daftar Isi</a></div><h2 id="melampaui-revolusi-kritik-scott-terhadap-narasi-besar-perlawanan-petani">Melampaui Revolusi: Kritik Scott terhadap Narasi Besar Perlawanan Petani</h2>\n<p>Salah satu kontribusi terpenting Scott adalah kritiknya terhadap <strong>&quot;revolutionary romanticism&quot;</strong> dalam studi peasant politics. Dalam <em>Weapons of the Weak</em>, Scott secara eksplisit mengkritik Eric Wolf dan tradisi Marxis yang cenderung memfokuskan analisis pada momen-momen revolusioner dalam sejarah petani (Wolf, 1969). Bagi Scott, obsesi terhadap revolusi petani telah mengaburkan pemahaman kita tentang politik petani sehari-hari yang sesungguhnya lebih dominan dan berkelanjutan.</p>\n<p>Scott mengargumentasikan bahwa <strong>revolusi petani adalah pengecualian, bukan aturan</strong>. Dalam sebagian besar sejarah, petani memilih strategi bertahan hidup yang meminimalkan risiko daripada perlawanan frontal yang berisiko tinggi. Pilihan ini bukan cerminan &quot;kesadaran palsu&quot; (<em>false consciousness</em>) atau ketiadaan kesadaran kelas, melainkan kalkulasi rasional berdasarkan pemahaman mendalam tentang struktur kekuasaan dan konsekuensi potensial dari perlawanan terbuka.</p>\n<p>Kritik Scott terhadap Wolf dan tradisi Marxis berpusat pada tiga argumen utama. Pertama, <strong>bias metodologis</strong>: fokus pada momen revolusioner mengabaikan kontinuitas perlawanan dalam kehidupan sehari-hari. Kedua, <strong>bias normatif</strong>: asumsi bahwa perlawanan &quot;sejati&quot; harus berbentuk revolusi mencerminkan proyeksi nilai-nilai intelektual urban terhadap realitas petani. Ketiga, <strong>bias empiris</strong>: kegagalan memahami bahwa sebagian besar petani lebih memilih strategi &quot;exit&quot; atau &quot;voice&quot; dalam bentuk halus daripada &quot;loyalty&quot; atau revolusi (Scott, 1985).</p>\n<p>Dalam <em>Seeing Like a State</em> (1998), Scott memperluas kritiknya dengan menganalisis bagaimana <strong>&quot;high modernist ideology&quot;</strong> negara modern cenderung mengabaikan atau menghancurkan bentuk-bentuk pengetahuan dan praktik lokal yang dikembangkan petani. Konsep <strong>&quot;metis&quot;</strong> — pengetahuan praktis yang diperoleh melalui pengalaman lokal — menjadi central dalam argumen Scott tentang superioritas sistem desentralisasi dan organik dibandingkan perencanaan terpusat negara.</p>\n<p>Scott juga mengkritik romantisasi komunitas petani dalam tradisi populis. Ia menunjukkan bahwa desa bukanlah entitas yang harmonis dan egaliter, melainkan arena kontestasi yang kompleks dengan hierarki internal, konflik kepentingan, dan stratifikasi sosial. <strong>&quot;Moral economy&quot;</strong> petani yang dikonseptualisasikan Scott berbeda dengan versi E.P. Thompson — bukan konsensus komunal tentang keadilan, melainkan negosiasi terus-menerus antara berbagai kepentingan dalam komunitas (Scott, 1976).</p>\n<p>Namun kritik Scott juga mendapat respons dari berbagai kalangan. Henry Bernstein (2010) mengargumentasikan bahwa Scott terlalu menekankan agensi individual petani sambil mengabaikan determinasi struktural dari akumulasi kapital global. Jan Douwe van der Ploeg (2008) menambahkan bahwa konsep Scott perlu diperkaya dengan pemahaman tentang <strong>&quot;repeasantization&quot;</strong> — proses di mana petani secara aktif membangun alternatif terhadap modernisasi kapitalis.</p>\n<p>Terlepas dari kritik tersebut, kontribusi Scott dalam menggeser fokus analisis dari revolusi ke politik sehari-hari tetap fundamental. Ia membuka ruang untuk memahami berbagai bentuk agensi petani yang selama ini diabaikan, sekaligus menyediakan kerangka analitis yang lebih sensitif terhadap kompleksitas dan kontradiksi dalam politik agraria.</p>\n<div class="article-key-takeaway"><div class="key-takeaway-label">Poin Penting</div><p>Scott tidak menolak kemungkinan revolusi petani, melainkan mengargumentasikan bahwa fokus berlebihan pada momen revolusioner telah mengaburkan pemahaman kita tentang politik petani sehari-hari yang sesungguhnya lebih dominan dan strategis dalam jangka panjang.</p></div>\n<div class="article-back-to-section"><a href="#daftar-isi" class="back-to-top-link" aria-label="Kembali ke daftar isi">&uarr; Kembali ke Daftar Isi</a></div><h2 id="perlawanan-harian-petani-karawang-dari-teori-ke-praktik">Perlawanan Harian Petani Karawang: Dari Teori ke Praktik</h2>\n<p>Aplikasi konsep <em>everyday resistance</em> Scott dalam konteks petani Karawang mengungkap repertoar perlawanan yang kaya dan beragam. Sebagai salah satu sentra industri terbesar di Jawa Barat, Karawang mengalami tekanan konversi lahan yang masif — dari 2000 hingga 2020, sekitar 15.000 hektar lahan pertanian telah beralih fungsi menjadi kawasan industri (Badan Pusat Statistik Karawang, 2021). Di tengah tekanan struktural ini, petani Karawang mengembangkan strategi perlawanan yang sejalan dengan kerangka teoretis Scott.</p>\n<p><strong>Bentuk pertama adalah <em>foot-dragging</em> dalam implementasi program pemerintah</strong>. Ketika Dinas Pertanian Karawang mengenalkan program intensifikasi dengan input kimia tinggi, banyak petani yang secara diam-diam tetap menggunakan praktik tradisional atau mengurangi dosis pupuk kimia. Mereka tidak menolak secara terbuka — bahkan menghadiri sosialisasi dan menerima bantuan — namun dalam praktik lapangan, mereka memodifikasi rekomendasi teknis sesuai pengetahuan lokal dan kondisi ekonomi (Wawancara dengan pengurus SEPETAK, 2023).</p>\n<p><strong>Sabotase halus terhadap infrastruktur agribisnis</strong> juga menjadi strategi umum. Petani sering melaporkan &quot;kerusakan&quot; pada sistem irigasi tetes yang dipasang perusahaan, padahal mereka sengaja memodifikasi sistem tersebut agar sesuai dengan pola tanam tradisional. Demikian pula dengan penggunaan benih hibrida — petani menerima benih dari program, namun tetap menyimpan sebagian hasil panen untuk benih musim berikutnya, meskipun hal ini mengurangi produktivitas benih hibrida.</p>\n<p><strong>Jaringan solidaritas informal</strong> menjadi bentuk perlawanan yang paling sophisticated. Petani Karawang mengembangkan sistem <strong>&quot;gotong royong terselubung&quot;</strong> yang berfungsi sebagai mekanisme perlindungan terhadap penetrasi pasar. Sistem <em>sambatan</em> (kerja bergantian) tidak hanya menghemat biaya tenaga kerja, tetapi juga mengurangi ketergantungan pada buruh upahan dan mesin-mesin modern yang mahal. Praktik <em>arisan gabah</em> memungkinkan petani menghindari fluktuasi harga pasar dengan sistem barter internal.</p>\n<p><strong>Diversifikasi ekonomi sebagai strategi exit</strong> juga mencerminkan konsep Scott. Banyak petani Karawang yang secara bertahap mengurangi ketergantungan pada produksi padi dengan mengembangkan usaha sampingan: peternakan skala kecil, warung, atau bekerja paruh waktu di sektor informal. Strategi ini memungkinkan mereka mempertahankan akses terhadap lahan sambil mengurangi risiko ekonomi dari fluktuasi harga komoditas pertanian.</p>\n<p>Namun, aplikasi konsep Scott dalam konteks Karawang juga mengungkap keterbatasan-keterbatasan tertentu. <strong>Tekanan konversi lahan yang masif</strong> menciptakan kondisi di mana <em>everyday resistance</em> tidak lagi memadai. Ketika lahan secara fisik diambil alih untuk pembangunan kawasan industri, strategi perlawanan halus menjadi tidak relevan. Dalam konteks ini, petani terpaksa beralih ke strategi yang lebih konfrontatif atau menerima kompensasi dan mencari mata pencaharian alternatif.</p>\n<p><strong>Penetrasi teknologi digital</strong> juga menciptakan tantangan baru. Program digitalisasi pertanian yang diusung pemerintah — seperti aplikasi <em>Sikatani</em> dan sistem <em>e-RDKK</em> — membuat praktik <em>foot-dragging</em> menjadi lebih sulit karena monitoring yang lebih ketat. Petani harus mengembangkan strategi baru, seperti memberikan data yang tidak akurat atau memanfaatkan kelemahan sistem digital.</p>\n<p><strong>Generasi muda petani</strong> menunjukkan pola perlawanan yang berbeda dari generasi tua. Mereka lebih cenderung menggunakan media sosial untuk membangun jaringan dan menyebarkan kritik terhadap kebijakan pertanian. Platform seperti WhatsApp dan Facebook menjadi ruang untuk mengorganisir <em>hidden transcript</em> yang lebih luas dan terstruktur dibandingkan gossip tradisional di warung atau masjid.</p>\n<p>Analisis terhadap kasus Karawang menunjukkan bahwa <em>everyday resistance</em> Scott tetap relevan, namun perlu diperkaya dengan pemahaman tentang transformasi struktural yang lebih cepat dan kompleks dalam kapitalisme kontemporer. Strategi perlawanan petani tidak lagi hanya berhadapan dengan tuan tanah atau negara, melainkan dengan jaringan korporasi global, teknologi digital, dan rezim akumulasi yang lebih sophisticated.</p>\n<div class="article-key-takeaway"><div class="key-takeaway-label">Poin Penting</div><p>Petani Karawang menggunakan repertoar everyday resistance yang beragam — dari foot-dragging hingga jaringan solidaritas informal — namun efektivitas strategi ini semakin terbatas menghadapi tekanan struktural yang lebih masif dan kompleks dalam era kapitalisme global.</p></div>\n<div class="article-back-to-section"><a href="#daftar-isi" class="back-to-top-link" aria-label="Kembali ke daftar isi">&uarr; Kembali ke Daftar Isi</a></div><h2 id="negara-dan-petani-dialektika-dominasi-dan-resistensi">Negara dan Petani: Dialektika Dominasi dan Resistensi</h2>\n<p>Pemahaman Scott tentang relasi negara-petani mencapai elaborasi paling komprehensif dalam <em>Seeing Like a State</em> (1998). Scott mengargumentasikan bahwa <strong>negara modern memiliki kecenderungan inherent untuk &quot;melihat seperti negara&quot;</strong> — menyederhanakan kompleksitas sosial menjadi kategori-kategori yang dapat diukur, dipetakan, dan dikontrol. Dalam konteks agraria, hal ini berarti transformasi sistem pertanian tradisional yang kompleks dan beragam menjadi monokultur yang seragam dan mudah dimonitor.</p>\n<p><strong>&quot;High modernist ideology&quot;</strong> yang dikritik Scott memiliki empat karakteristik utama: kepercayaan pada superioritas pengetahuan ilmiah-teknis, keyakinan bahwa masyarakat dapat direkayasa secara rasional, aspirasi untuk mencapai kemajuan melalui perencanaan terpusat, dan pengabaian terhadap pengetahuan lokal dan praktik tradisional. Dalam konteks Indonesia, ideologi ini tercermin dalam program Revolusi Hijau, intensifikasi pertanian, dan berbagai skema modernisasi yang mengabaikan kearifan lokal petani.</p>\n<p>Scott menunjukkan bagaimana <strong>&quot;legibility&quot;</strong> (keterbacaan) menjadi obsesi negara modern. Lahan pertanian harus dipetakan, petani harus terdaftar, produksi harus terukur, dan praktik pertanian harus terstandarisasi. Proses ini memungkinkan negara untuk mengekstrak surplus secara lebih efisien, namun sekaligus menghancurkan sistem pengetahuan dan praktik lokal yang telah berkembang selama berabad-abad. <strong>&quot;Metis&quot;</strong> — pengetahuan praktis yang diperoleh melalui pengalaman lokal — menjadi korban dari proses modernisasi ini.</p>\n<p>Dalam konteks Karawang, dialektika ini terlihat jelas dalam implementasi program <strong>Kawasan Rumah Pangan Lestari (KRPL)</strong> dan <strong>Gerakan Penerapan Pengelolaan Tanaman Terpadu (GP-PTT)</strong>. Program-program ini dirancang dengan asumsi bahwa petani adalah &quot;blank slate&quot; yang perlu dididik tentang praktik pertanian &quot;modern&quot;. Pengetahuan lokal tentang varietas padi lokal, sistem rotasi tanaman, dan pengelolaan hama terpadu diabaikan demi standardisasi teknis yang mudah dimonitor dan dievaluasi.</p>\n<p>Namun Scott juga menunjukkan bahwa <strong>petani bukan penerima pasif dari dominasi negara</strong>. Mereka mengembangkan berbagai strategi untuk mengelak dari &quot;pandangan negara&quot; sambil tetap memperoleh manfaat dari program-program pemerintah. Konsep <strong>&quot;weapons of the weak&quot;</strong> dalam konteks ini bukan hanya perlawanan terhadap eksploitasi ekonomi, melainkan juga resistensi terhadap homogenisasi pengetahuan dan praktik.</p>\n<p><strong>Strategi &quot;compliant resistance&quot;</strong> menjadi karakteristik utama relasi petani-negara dalam konteks kontemporer. Petani Karawang menunjukkan kepatuhan formal terhadap program pemerintah — menghadiri penyuluhan, mendaftar sebagai peserta program, melaporkan data produksi — namun dalam praktik lapangan, mereka tetap mempertahankan elemen-elemen praktik tradisional yang dianggap lebih sesuai dengan kondisi lokal.</p>\n<p><strong>Teknologi menjadi arena kontestasi yang semakin penting</strong>. Program digitalisasi pertanian yang diusung Kementerian Pertanian — seperti aplikasi monitoring tanam dan sistem informasi cuaca — direspons petani dengan strategi yang beragam. Sebagian petani menggunakan teknologi ini secara selektif, mengambil informasi yang berguna sambil mengabaikan rekomendasi yang tidak sesuai. Sebagian lain memberikan data yang tidak akurat untuk menghindari monitoring yang terlalu ketat.</p>\n<p><strong>Peran penyuluh pertanian</strong> menjadi kompleks dalam dinamika ini. Sebagai representasi negara di tingkat desa, penyuluh seharusnya menjadi agen modernisasi. Namun dalam praktik, banyak penyuluh yang mengembangkan pemahaman empatis terhadap kondisi petani dan menjadi &quot;broker&quot; antara program pemerintah dan kebutuhan lokal. Mereka sering memodifikasi pesan program agar lebih sesuai dengan realitas lapangan, meskipun hal ini bertentangan dengan standardisasi yang dikehendaki negara.</p>\n<p>Analisis Scott tentang negara juga perlu dikontekstualisasikan dengan transformasi neoliberal dalam kebijakan agraria Indonesia. <strong>Peran negara tidak lagi hanya sebagai modernizer, melainkan juga sebagai fasilitator akumulasi kapital privat</strong>. Hal ini terlihat dalam kebijakan yang mendorong korporatisasi pertanian, liberalisasi perdagangan komoditas, dan privatisasi layanan pertanian. Dalam konteks ini, <em>everyday resistance</em> petani tidak hanya berhadapan dengan birokrasi negara, melainkan juga dengan logika pasar yang semakin dominan.</p>\n<div class="article-key-takeaway"><div class="key-takeaway-label">Poin Penting</div><p>Relasi negara-petani dalam kontemporer bukan sekadar dominasi-resistensi, melainkan negosiasi kompleks di mana petani menggunakan strategi &quot;compliant resistance&quot; untuk mempertahankan otonomi sambil mengakses sumber daya negara, sementara negara beradaptasi dengan resistensi ini melalui mekanisme monitoring dan insentif yang lebih sophisticated.</p></div>\n<div class="article-back-to-section"><a href="#daftar-isi" class="back-to-top-link" aria-label="Kembali ke daftar isi">&uarr; Kembali ke Daftar Isi</a></div><h2 id="kesimpulan">Kesimpulan</h2>\n<p>Pemikiran James C. Scott tentang <em>everyday forms of resistance</em> menyediakan lensa analitis yang powerful untuk memahami politik petani kontemporer, termasuk di Karawang. Konsep Scott berhasil mengungkap dimensi politik dalam tindakan sehari-hari petani yang selama ini diabaikan oleh analisis konvensional yang terfokus pada momen-momen revolusioner. Melalui strategi <em>foot-dragging</em>, sabotase halus, jaringan solidaritas informal, dan <em>compliant resistance</em>, petani Karawang menunjukkan bahwa mereka bukan korban pasif dari dominasi struktural, melainkan aktor politik yang mengembangkan strategi rasional untuk mempertahankan otonomi dan mata pencaharian.</p>\n<p>Namun, aplikasi konsep Scott dalam konteks Karawang juga mengungkap keterbatasan-keterbatasan tertentu. <strong>Tekanan struktural dalam era kapitalisme global — konversi lahan masif, penetrasi korporasi agribisnis, dan digitalisasi pertanian — menciptakan kondisi di mana <em>everyday resistance</em> tradisional tidak selalu memadai</strong>. Petani terpaksa mengembangkan strategi yang lebih kompleks dan terkadang lebih konfrontatif untuk menghadapi transformasi yang lebih cepat dan fundamental.</p>\n<p>Secara teoretis, pemikiran Scott perlu diperkaya dengan perspektif ekonomi politik agraria yang lebih sensitif terhadap dinamika akumulasi kapital global. Karya Henry Bernstein tentang <strong>&quot;labour regimes of food&quot;</strong> dan Jan Douwe van der Ploeg tentang <strong>&quot;repeasantization&quot;</strong> menyediakan kerangka komplementer yang dapat memperkaya analisis Scott tentang agensi petani dalam konteks kapitalis kontemporer.</p>\n<p><strong>Implikasi praktis bagi gerakan tani sangat signifikan</strong>. Pemahaman tentang <em>everyday resistance</em> dapat membantu organisasi seperti SEPETAK untuk mengembangkan strategi yang lebih sensitif terhadap realitas politik petani di tingkat grassroots. Alih-alih memaksakan model organisasi yang formal dan hierarkis, gerakan tani dapat membangun strategi yang memanfaatkan jaringan solidaritas informal yang sudah ada, sekaligus memperkuat kapasitas petani untuk melakukan perlawanan yang lebih efektif.</p>\n<p><strong>Rekomendasi strategis</strong> yang dapat dikembangkan meliputi: pertama, <strong>dokumentasi dan pengembangan praktik-praktik perlawanan harian</strong> yang sudah dilakukan petani sebagai basis untuk strategi organisasi yang lebih luas; kedua, <strong>pemanfaatan teknologi digital</strong> tidak hanya sebagai alat monitoring negara, melainkan juga sebagai platform untuk membangun jaringan solidaritas dan menyebarkan <em>hidden transcript</em>; ketiga, <strong>pengembangan ekonomi alternatif</strong> yang berbasis pada prinsip solidaritas dan mengurangi ketergantungan pada sistem pasar kapitalis; keempat, <strong>aliansi strategis dengan penyuluh dan birokrat tingkat bawah</strong> yang memiliki pemahaman empatis terhadap kondisi petani.</p>\n<p>Pada akhirnya, pemikiran Scott mengingatkan kita bahwa <strong>politik tidak hanya terjadi di parlemen atau dalam gerakan massa, melainkan juga dalam tindakan sehari-hari petani di sawah dan ladang mereka</strong>. Memahami dan menghargai dimensi politik ini merupakan prasyarat untuk membangun gerakan tani yang lebih demokratis, inklusif, dan efektif dalam menghadapi tantangan struktural yang semakin kompleks di era kontemporer.</p>\n<div class="article-back-to-section"><a href="#daftar-isi" class="back-to-top-link" aria-label="Kembali ke daftar isi">&uarr; Kembali ke Daftar Isi</a></div><section class="article-bibliography"><h2 id="daftar-pustaka">Daftar Pustaka</h2>\n<p>Badan Pusat Statistik Karawang. (2021). <em>Karawang dalam angka 2021</em>. BPS Kabupaten Karawang.</p>\n<p>Bernstein, H. (2010). <em>Class dynamics of agrarian change</em>. Fernwood Publishing.</p>\n<p>Konsorsium Pembaruan Agraria. (2021). <em>Catatan akhir tahun 2021: Tumpang tindih krisis agraria di tengah pandemi</em>. KPA.</p>\n<p>Scott, J. C. (1976). <em>The moral economy of the peasant: Rebellion and subsistence in Southeast Asia</em>. Yale University Press.</p>\n<p>Scott, J. C. (1985). <em>Weapons of the weak: Everyday forms of peasant resistance</em>. Yale University Press.</p>\n<p>Scott, J. C. (1990). <em>Domination and the arts of resistance: Hidden transcripts</em>. Yale University Press.</p>\n<p>Scott, J. C. (1998). <em>Seeing like a state: How certain schemes to improve the human condition have failed</em>. Yale University Press.</p>\n<p>van der Ploeg, J. D. (2008). <em>The new peasantries: Struggles for autonomy and sustainability in an era of empire and globalization</em>. Earthscan.</p>\n<p>Wolf, E. R. (1969). <em>Peasant wars of the twentieth century</em>. Harper &amp; Row.</p>\n</section><hr class="article-disclosure-divider"><aside class="article-disclosure"><p><em>Artikel ini disusun dengan bantuan kecerdasan buatan dan telah ditinjau oleh redaksi SEPETAK. Referensi yang dicantumkan adalah sumber nyata yang dapat diverifikasi. Pandangan dalam artikel ini tidak selalu mencerminkan posisi resmi organisasi.</em></p></aside>	published	2026-04-17 23:54:44	1	2026-04-17 23:44:06	2026-04-17 23:54:44	\N	auto_generated	7	4	t
43	Teori Nilai-Lebih dan Eksploitasi Buruh Tani di Jawa Barat: Analisis Marxis terhadap Kondisi Agraria Kontemporer	teori-nilai-lebih-dan-eksploitasi-buruh-tani-di-jawa-barat-analisis-marxis-terhadap-kondisi-agraria-kontemporer	Artikel ini menganalisis relevansi teori nilai-lebih Karl Marx dalam memahami eksploitasi buruh tani di Jawa Barat, khususnya di Karawang. Melalui pendekatan Marxisme klasik, penelitian ini mengkaji mekanisme ekstraksi surplus value yang dialami petani dan buruh tani melalui sistem upah rendah, rent-seeking, dan ketergantungan terhadap input produksi korporat. Analisis menunjukkan bahwa transformasi agraria di Jawa Barat telah menciptakan kondisi yang memungkinkan kapitalis agraria mengekstraksi	<section class="article-abstract"><h2 id="abstrak">Abstrak</h2>\n<p>Artikel ini menganalisis relevansi teori nilai-lebih Karl Marx dalam memahami eksploitasi buruh tani di Jawa Barat, khususnya di Karawang. Melalui pendekatan Marxisme klasik, penelitian ini mengkaji mekanisme ekstraksi surplus value yang dialami petani dan buruh tani melalui sistem upah rendah, rent-seeking, dan ketergantungan terhadap input produksi korporat. Analisis menunjukkan bahwa transformasi agraria di Jawa Barat telah menciptakan kondisi yang memungkinkan kapitalis agraria mengekstraksi nilai-lebih melalui tiga mekanisme utama: eksploitasi tenaga kerja langsung, monopoli atas alat produksi, dan kontrol terhadap rantai distribusi. Kondisi ini diperparah oleh kebijakan neoliberal yang memprioritaskan efisiensi pasar di atas keadilan sosial. Studi ini menyimpulkan bahwa teori Marx tetap relevan dalam memahami dinamika kelas agraria kontemporer, di mana akumulasi kapital berlangsung melalui pemiskinan struktural petani kecil dan proletarisasi buruh tani. Implikasi teoretis dan praktis dari temuan ini mengarah pada perlunya reorganisasi hubungan produksi agraria yang lebih adil melalui reforma agraria sejati dan penguatan organisasi petani.</p>\n</section><h2 id="pendahuluan">Pendahuluan</h2>\n<p>Transformasi agraria di Indonesia, khususnya di Jawa Barat, telah mengalami perubahan fundamental sejak era Orde Baru hingga saat ini. Provinsi yang menjadi lumbung padi nasional ini menghadapi paradoks: produktivitas meningkat, namun kesejahteraan petani justru menurun. Fenomena ini tidak dapat dipahami secara memadai tanpa menggunakan kerangka analisis yang mampu mengungkap relasi produksi yang sesungguhnya terjadi di pedesaan.</p>\n<p>Teori nilai-lebih (surplus value) yang dikembangkan Karl Marx dalam <em>Das Kapital</em> menawarkan instrumen analitis yang tajam untuk memahami mekanisme eksploitasi dalam sistem produksi kapitalis (Marx, 1867). Meskipun dikembangkan dalam konteks industrialisasi Eropa abad ke-19, teori ini memiliki relevansi yang signifikan untuk memahami dinamika agraria kontemporer, termasuk di Jawa Barat.</p>\n<p>Permasalahan utama yang dihadapi buruh tani di Jawa Barat adalah eksploitasi sistematis yang terjadi melalui berbagai mekanisme: upah yang tidak sebanding dengan nilai yang diproduksi, ketergantungan terhadap input produksi yang dikuasai korporat, dan sistem bagi hasil yang merugikan petani penggarap. Kondisi ini menciptakan akumulasi kapital di satu sisi dan pemiskinan struktural di sisi lain.</p>\n<p>Artikel ini berargumen bahwa teori nilai-lebih Marx tetap relevan untuk menganalisis eksploitasi buruh tani di Jawa Barat. Melalui pemahaman terhadap mekanisme ekstraksi surplus value, kita dapat mengidentifikasi akar struktural kemiskinan agraria dan merumuskan strategi perlawanan yang tepat.</p>\n<div class="article-back-to-section"><a href="#daftar-isi" class="back-to-top-link" aria-label="Kembali ke daftar isi">&uarr; Kembali ke Daftar Isi</a></div><h2 id="kerangka-teoretis-nilai-lebih-dalam-produksi-agraria">Kerangka Teoretis: Nilai-Lebih dalam Produksi Agraria</h2>\n<h3 id="konsep-dasar-teori-nilai-lebih-marx">Konsep Dasar Teori Nilai-Lebih Marx</h3>\n<p>Karl Marx dalam <em>Das Kapital</em> menjelaskan bahwa nilai-lebih merupakan sumber keuntungan kapitalis yang diperoleh dari eksploitasi tenaga kerja (Marx, 1867). Dalam proses produksi, pekerja menghasilkan nilai yang lebih besar daripada nilai tenaga kerjanya sendiri. Selisih antara nilai yang diproduksi dengan upah yang diterima pekerja inilah yang disebut nilai-lebih.</p>\n<p>Marx membedakan dua bentuk nilai-lebih: absolut dan relatif. Nilai-lebih absolut diperoleh melalui perpanjangan jam kerja tanpa menaikkan upah, sedangkan nilai-lebih relatif diperoleh melalui peningkatan produktivitas yang memungkinkan pengurangan waktu kerja yang diperlukan untuk mereproduksi nilai tenaga kerja (Marx, 1867).</p>\n<p>Dalam konteks agraria, konsep ini dapat diaplikasikan untuk memahami bagaimana pemilik modal (tuan tanah, korporat agribisnis, tengkulak) mengekstraksi nilai dari kerja petani dan buruh tani. Proses ini tidak selalu terjadi melalui hubungan upah langsung, tetapi juga melalui berbagai bentuk rent dan kontrol atas alat produksi.</p>\n<h3 id="aplikasi-teori-dalam-konteks-agraria">Aplikasi Teori dalam Konteks Agraria</h3>\n<p>Henry Bernstein dalam <em>Class Dynamics of Agrarian Change</em> memperluas analisis Marxis ke dalam konteks agraria dengan memperkenalkan konsep &quot;petty commodity production&quot; dan &quot;subsumption of labour to capital&quot; (Bernstein, 2010). Menurut Bernstein, transformasi agraria kapitalis tidak selalu menghasilkan proletarisasi penuh, tetapi sering kali menciptakan bentuk-bentuk hibrida di mana petani kecil tetap memiliki akses terbatas terhadap alat produksi namun tunduk pada logika akumulasi kapital.</p>\n<p>Dalam konteks Indonesia, Gunawan Wiradi mengidentifikasi bahwa problema agraria tidak hanya berkaitan dengan distribusi tanah, tetapi juga dengan struktur sosial yang memungkinkan eksploitasi berlangsung (Wiradi, 2000). Analisis Wiradi menunjukkan bahwa reforma agraria tidak dapat dipisahkan dari transformasi hubungan produksi yang lebih fundamental.</p>\n<div class="article-back-to-section"><a href="#daftar-isi" class="back-to-top-link" aria-label="Kembali ke daftar isi">&uarr; Kembali ke Daftar Isi</a></div><h2 id="kondisi-objektif-buruh-tani-di-jawa-barat">Kondisi Objektif Buruh Tani di Jawa Barat</h2>\n<h3 id="struktur-kepemilikan-tanah-dan-proletarisasi">Struktur Kepemilikan Tanah dan Proletarisasi</h3>\n<p>Data Konsorsium Pembaruan Agraria menunjukkan bahwa konsentrasi kepemilikan tanah di Jawa Barat semakin menguat (Konsorsium Pembaruan Agraria, 2023). Sebagian besar petani hanya menguasai lahan kurang dari 0,5 hektar, sementara sebagian kecil elit agraria menguasai lahan dalam skala besar. Kondisi ini menciptakan ketergantungan struktural di mana petani kecil harus menjual tenaga kerjanya kepada pemilik modal yang lebih besar.</p>\n<p>Proses proletarisasi ini tidak terjadi secara linear. Banyak petani yang mengalami &quot;semi-proletarisasi&quot;, di mana mereka masih memiliki akses terbatas terhadap tanah tetapi harus bekerja sebagai buruh tani untuk memenuhi kebutuhan hidupnya. Kondisi ini menciptakan surplus tenaga kerja yang memungkinkan kapitalis agraria menekan upah di bawah nilai reproduksi tenaga kerja.</p>\n<h3 id="mekanisme-ekstraksi-nilai-lebih">Mekanisme Ekstraksi Nilai-Lebih</h3>\n<p>Ekstraksi nilai-lebih dalam sektor agraria Jawa Barat terjadi melalui beberapa mekanisme:</p>\n<p><strong>Pertama</strong>, sistem upah harian yang tidak mencerminkan produktivitas sesungguhnya. Buruh tani di Karawang rata-rata menerima upah Rp 80.000-100.000 per hari untuk jam kerja 8-10 jam, sementara nilai produksi yang dihasilkan jauh lebih besar. Diskrepansi ini memungkinkan pemilik modal mengakumulasi surplus value yang substansial.</p>\n<p><strong>Kedua</strong>, sistem bagi hasil yang timpang. Petani penggarap umumnya hanya menerima 30-40% dari hasil panen, sementara pemilik tanah yang tidak terlibat langsung dalam produksi menerima 60-70%. Sistem ini memungkinkan ekstraksi rent yang tidak sebanding dengan kontribusi produktif.</p>\n<p><strong>Ketiga</strong>, monopoli input produksi oleh korporat agribisnis. Petani terpaksa membeli benih, pupuk, dan pestisida dengan harga tinggi dari perusahaan multinasional, sementara harga jual produk pertanian ditentukan oleh mekanisme pasar yang dikuasai tengkulak dan korporat.</p>\n<div class="article-back-to-section"><a href="#daftar-isi" class="back-to-top-link" aria-label="Kembali ke daftar isi">&uarr; Kembali ke Daftar Isi</a></div><h2 id="transformasi-agraria-dan-akumulasi-kapital">Transformasi Agraria dan Akumulasi Kapital</h2>\n<h3 id="revolusi-hijau-dan-subsumsi-formal-tenaga-kerja">Revolusi Hijau dan Subsumsi Formal Tenaga Kerja</h3>\n<p>Revolusi Hijau yang dimulai pada era Orde Baru telah mengubah karakter produksi pertanian di Jawa Barat dari subsisten menjadi berorientasi pasar. Transformasi ini, meskipun meningkatkan produktivitas, juga menciptakan ketergantungan petani terhadap input eksternal dan teknologi yang dikuasai korporat multinasional.</p>\n<p>Marx menganalisis bagaimana kapital secara bertahap mensubsumsi proses kerja, pertama secara formal kemudian secara riil (Marx, 1867). Dalam konteks Jawa Barat, subsumsi formal terjadi ketika petani tetap menggunakan teknik tradisional tetapi produksinya sudah berorientasi pasar. Subsumsi riil terjadi ketika proses produksi itu sendiri direorganisasi sesuai dengan logika kapital, seperti penggunaan mesin, monokultur, dan standardisasi.</p>\n<h3 id="akumulasi-primitif-kontemporer">Akumulasi Primitif Kontemporer</h3>\n<p>David Harvey mengembangkan konsep &quot;accumulation by dispossession&quot; untuk menjelaskan bagaimana akumulasi kapital kontemporer berlangsung melalui perampasan aset-aset yang sebelumnya berada di luar logika pasar (Harvey, 2003). Dalam konteks Jawa Barat, proses ini terjadi melalui konversi lahan pertanian menjadi kawasan industri dan perumahan, privatisasi sumber daya air, dan komersialisasi benih lokal.</p>\n<p>Proses akumulasi primitif ini tidak hanya terjadi sekali pada awal perkembangan kapitalisme, tetapi berlangsung secara kontinyu sebagai mekanisme untuk mengatasi krisis akumulasi. Petani yang kehilangan tanahnya terpaksa menjadi buruh industri atau buruh tani dengan upah rendah, menciptakan surplus tenaga kerja yang menguntungkan kapital.</p>\n<div class="article-back-to-section"><a href="#daftar-isi" class="back-to-top-link" aria-label="Kembali ke daftar isi">&uarr; Kembali ke Daftar Isi</a></div><h2 id="resistensi-dan-organisasi-petani">Resistensi dan Organisasi Petani</h2>\n<h3 id="bentuk-bentuk-perlawanan">Bentuk-Bentuk Perlawanan</h3>\n<p>James C. Scott dalam <em>Weapons of the Weak</em> mengidentifikasi berbagai bentuk resistensi sehari-hari yang dilakukan petani terhadap eksploitasi (Scott, 1985). Di Jawa Barat, resistensi ini mengambil berbagai bentuk: dari sabotase halus terhadap sistem kerja hingga pembentukan organisasi petani yang lebih terstruktur.</p>\n<p>Serikat Pekerja Tani Karawang (SEPETAK) merupakan salah satu contoh organisasi yang berupaya melawan eksploitasi struktural melalui pendidikan politik, advokasi kebijakan, dan aksi kolektif. Organisasi ini menyadari bahwa perlawanan individual tidak akan mampu mengubah struktur eksploitasi yang sistemik.</p>\n<h3 id="strategi-transformasi-struktural">Strategi Transformasi Struktural</h3>\n<p>Perlawanan terhadap eksploitasi nilai-lebih tidak dapat hanya mengandalkan peningkatan upah atau perbaikan kondisi kerja yang parsial. Diperlukan transformasi struktural yang mengubah hubungan produksi itu sendiri. Hal ini mencakup:</p>\n<p>Redistribusi tanah yang genuine, bukan hanya sertifikasi lahan yang sudah ada. Reforma agraria sejati harus mengubah struktur kepemilikan yang timpang dan memberikan akses yang adil terhadap sumber daya produktif.</p>\n<p>Penguatan ekonomi kolektif melalui koperasi produksi, pengolahan, dan pemasaran yang dikontrol petani. Ini akan mengurangi ketergantungan terhadap tengkulak dan korporat agribisnis.</p>\n<p>Pengembangan teknologi yang sesuai dengan kebutuhan petani kecil, bukan teknologi yang memperkuat dominasi korporat multinasional.</p>\n<div class="article-back-to-section"><a href="#daftar-isi" class="back-to-top-link" aria-label="Kembali ke daftar isi">&uarr; Kembali ke Daftar Isi</a></div><h2 id="kesimpulan">Kesimpulan</h2>\n<p>Analisis terhadap kondisi buruh tani di Jawa Barat melalui kerangka teori nilai-lebih Marx menunjukkan bahwa eksploitasi yang dialami petani bukan sekadar fenomena pasar, tetapi merupakan konsekuensi logis dari struktur hubungan produksi kapitalis. Ekstraksi surplus value terjadi melalui berbagai mekanisme yang saling terkait: upah rendah, sistem bagi hasil yang timpang, monopoli input produksi, dan akumulasi primitif yang berkelanjutan.</p>\n<p>Transformasi agraria yang terjadi sejak Revolusi Hijau telah mengintegrasikan petani Jawa Barat ke dalam sistem produksi kapitalis global, namun dalam posisi yang subordinat. Petani kehilangan kontrol atas proses produksi dan terpaksa menerima bagian yang kecil dari nilai yang mereka ciptakan.</p>\n<p>Teori Marx tetap relevan karena mampu mengungkap kontradiksi fundamental dalam sistem produksi agraria kapitalis. Peningkatan produktivitas tidak otomatis meningkatkan kesejahteraan petani selama struktur eksploitasi tetap dipertahankan. Sebaliknya, produktivitas yang tinggi justru memungkinkan ekstraksi surplus value yang lebih besar.</p>\n<p>Implikasi praktis dari analisis ini adalah perlunya strategi transformasi yang tidak hanya berfokus pada peningkatan pendapatan petani secara individual, tetapi pada perubahan struktur hubungan produksi. Reforma agraria, penguatan organisasi petani, dan pengembangan ekonomi kolektif merupakan elemen-elemen penting dalam strategi transformasi struktural.</p>\n<p>Organisasi seperti SEPETAK memiliki peran strategis dalam membangun kesadaran kelas di kalangan petani dan buruh tani. Melalui pendidikan politik dan aksi kolektif, organisasi petani dapat menjadi kekuatan penggerak perubahan struktural yang diperlukan untuk mengakhiri eksploitasi sistematis terhadap produsen pangan.</p>\n<div class="article-back-to-section"><a href="#daftar-isi" class="back-to-top-link" aria-label="Kembali ke daftar isi">&uarr; Kembali ke Daftar Isi</a></div><section class="article-bibliography"><h2 id="daftar-pustaka">Daftar Pustaka</h2>\n<p>Bernstein, H. (2010). <em>Class dynamics of agrarian change</em>. Fernwood Publishing.</p>\n<p>Harvey, D. (2003). <em>The new imperialism</em>. Oxford University Press.</p>\n<p>Konsorsium Pembaruan Agraria. (2023). <em>Catatan akhir tahun 2023: Reforma agraria di tengah pusaran krisis multidimensional</em>. KPA.</p>\n<p>Marx, K. (1867). <em>Das Kapital: A critique of political economy, Volume I</em>. Progress Publishers.</p>\n<p>Scott, J. C. (1985). <em>Weapons of the weak: Everyday forms of peasant resistance</em>. Yale University Press.</p>\n<p>Wiradi, G. (2000). <em>Reforma agraria: Perjalanan yang belum berakhir</em>. KPA-Pustaka Pelajar.</p>\n</section><hr class="article-disclosure-divider"><aside class="article-disclosure"><p><em>Artikel ini disusun dengan bantuan kecerdasan buatan dan telah ditinjau oleh redaksi SEPETAK. Referensi yang dicantumkan adalah sumber nyata yang dapat diverifikasi. Pandangan dalam artikel ini tidak selalu mencerminkan posisi resmi organisasi.</em></p></aside>	published	2026-04-17 23:20:57	1	2026-04-17 23:05:17	2026-04-17 23:57:11	\N	auto_generated	1	1	t
47	Akumulasi melalui Perampasan: David Harvey dan Konflik Agraria di Indonesia	akumulasi-melalui-perampasan-teori-david-harvey-dan-realitas-konflik-agraria-di-indonesia	Artikel ini menganalisis fenomena konflik agraria di Indonesia kontemporer melalui kerangka teori accumulation by dispossession yang dikembangkan oleh David Harvey. Penelitian ini menggunakan pendekatan analisis neo-Marxian untuk memahami bagaimana mekanisme akumulasi primitif yang dikonseptualisasikan Marx tidak hanya terjadi pada fase awal kapitalisme, tetapi terus berlangsung sebagai strategi pemecahan krisis kapital. Temuan menunjukkan bahwa konflik agraria di Indonesia—mulai dari land grabb	<div class="article-meta"><p><strong>Kata Kunci:</strong> accumulation by dispossession, David Harvey, konflik agraria, land grabbing, neoliberalisme\n<strong>Waktu Baca:</strong> ± 15 menit</p></div>\n<nav class="article-toc"><h2 id="daftar-isi">Daftar Isi</h2><ol>\n<li><a href="#abstrak">Abstrak</a></li>\n<li><a href="#pendahuluan">Pendahuluan</a></li>\n<li><a href="#teori-akumulasi-melalui-perampasan-david-harvey">Teori Akumulasi melalui Perampasan David Harvey</a></li>\n<li><a href="#manifestasi-akumulasi-primitif-di-indonesia-kontemporer">Manifestasi Akumulasi Primitif di Indonesia Kontemporer</a></li>\n<li><a href="#mekanisme-perampasan-dalam-proyek-pembangunan-dan-investasi">Mekanisme Perampasan dalam Proyek Pembangunan dan Investasi</a></li>\n<li><a href="#resistensi-petani-dan-kontradiksi-akumulasi-kapital">Resistensi Petani dan Kontradiksi Akumulasi Kapital</a></li>\n<li><a href="#kesimpulan">Kesimpulan</a></li>\n<li><a href="#daftar-pustaka">Daftar Pustaka</a></li>\n</ol></nav>\n<section class="article-abstract"><h2 id="abstrak">Abstrak</h2>\n<p>Artikel ini menganalisis fenomena konflik agraria di Indonesia kontemporer melalui kerangka teori <strong>accumulation by dispossession</strong> yang dikembangkan oleh David Harvey. Penelitian ini menggunakan pendekatan analisis neo-Marxian untuk memahami bagaimana mekanisme akumulasi primitif yang dikonseptualisasikan Marx tidak hanya terjadi pada fase awal kapitalisme, tetapi terus berlangsung sebagai strategi pemecahan krisis kapital. Temuan menunjukkan bahwa konflik agraria di Indonesia—mulai dari land grabbing untuk perkebunan kelapa sawit, proyek infrastruktur strategis nasional, hingga kawasan ekonomi khusus—merupakan manifestasi konkret dari proses perampasan sistematis yang memungkinkan akumulasi kapital melalui penciptaan &quot;primitive accumulation&quot; berkelanjutan. Mekanisme ini difasilitasi oleh kebijakan neoliberal yang mentransformasikan tanah dari nilai guna menjadi komoditas, sekaligus menciptakan surplus tenaga kerja melalui proletarisasi petani. Resistensi petani dan komunitas adat menunjukkan kontradiksi inheren dalam proses akumulasi ini, yang memerlukan intervensi negara yang semakin represif untuk mempertahankan kondisi akumulasi. Artikel ini menyimpulkan bahwa memahami konflik agraria melalui lensa Harvey memberikan kerangka analitis yang lebih komprehensif untuk memahami dinamika kapitalisme kontemporer di Indonesia.</p>\n</section><h2 id="pendahuluan">Pendahuluan</h2>\n<p>Konflik agraria di Indonesia telah mencapai intensitas yang mengkhawatirkan dalam dua dekade terakhir. Data Konsorsium Pembaruan Agraria (2023) mencatat 212 konflik agraria sepanjang tahun 2023 dengan luas wilayah sengketa mencapai 324.717 hektare, melibatkan 145.793 kepala keluarga petani. Angka ini menunjukkan tren peningkatan yang konsisten sejak era reformasi, mengindikasikan bahwa persoalan agraria bukan sekadar masalah teknis distribusi lahan, melainkan manifestasi dari kontradiksi struktural yang lebih fundamental dalam sistem ekonomi politik Indonesia.</p>\n<p>Dalam konteks teoretis, fenomena ini memerlukan kerangka analisis yang mampu menjelaskan tidak hanya dimensi ekonomi konflik agraria, tetapi juga relasi kuasa yang memungkinkan terjadinya perampasan sistematis atas sumber daya agraria. Teori <strong>accumulation by dispossession</strong> yang dikembangkan David Harvey (2003, 2005) menawarkan perspektif analitis yang relevan untuk memahami dinamika ini. Harvey mengembangkan konsep Marx tentang akumulasi primitif (<em>primitive accumulation</em>) dengan argumen bahwa proses perampasan bukan hanya terjadi pada fase awal kapitalisme, tetapi merupakan strategi berkelanjutan untuk mengatasi krisis akumulasi kapital.</p>\n<p>Permasalahan utama yang hendak dijawab dalam artikel ini adalah: bagaimana teori accumulation by dispossession Harvey dapat menjelaskan pola dan mekanisme konflik agraria di Indonesia kontemporer? Lebih spesifik, artikel ini akan menganalisis bagaimana proses perampasan tanah dan sumber daya alam difasilitasi oleh kebijakan neoliberal, sekaligus mengkaji resistensi yang muncul dari komunitas petani sebagai respons terhadap proses akumulasi tersebut.</p>\n<p>Tesis utama artikel ini adalah bahwa konflik agraria di Indonesia merupakan manifestasi konkret dari accumulation by dispossession, di mana negara berperan aktif memfasilitasi perampasan sumber daya agraria untuk kepentingan akumulasi kapital domestik dan internasional. Proses ini tidak hanya menciptakan surplus value melalui eksploitasi tenaga kerja, tetapi juga melalui apropriasi langsung atas <em>commons</em> dan transformasi nilai guna menjadi nilai tukar.</p>\n<p>Artikel ini akan diorganisir dalam empat bagian pembahasan utama. Pertama, elaborasi teoretis mengenai konsep accumulation by dispossession Harvey dan relevansinya dengan kondisi Indonesia. Kedua, identifikasi manifestasi konkret akumulasi primitif dalam konteks agraria Indonesia kontemporer. Ketiga, analisis mekanisme perampasan dalam proyek-proyek pembangunan dan investasi. Keempat, pembahasan mengenai resistensi petani dan kontradiksi yang muncul dalam proses akumulasi kapital.</p>\n<div class="article-back-to-section"><a href="#daftar-isi" class="back-to-top-link" aria-label="Kembali ke daftar isi">&uarr; Kembali ke Daftar Isi</a></div><h2 id="teori-akumulasi-melalui-perampasan-david-harvey">Teori Akumulasi melalui Perampasan David Harvey</h2>\n<p>David Harvey dalam <em>The New Imperialism</em> (2003) mengembangkan konsep Marx tentang akumulasi primitif menjadi teori yang lebih komprehensif tentang <strong>accumulation by dispossession</strong>. Marx dalam <em>Das Kapital</em> menjelaskan bahwa akumulasi primitif merupakan proses historis yang memisahkan produsen langsung dari alat-alat produksi, khususnya tanah, sehingga menciptakan kondisi bagi berkembangnya hubungan produksi kapitalis. Namun Harvey berargumen bahwa proses ini bukan hanya fenomena historis yang terjadi sekali pada awal kapitalisme, melainkan strategi berkelanjutan yang digunakan kapital untuk mengatasi krisis akumulasi.</p>\n<p>Konsep accumulation by dispossession Harvey dibangun atas kritik terhadap teori imperialisme klasik yang cenderung menekankan eksploitasi surplus value melalui hubungan kerja upahan. Harvey menunjukkan bahwa kapitalisme kontemporer juga bergantung pada apropriasi langsung atas aset-aset yang sebelumnya berada di luar sphere pasar. Proses ini melibatkan transformasi berbagai bentuk hak kepemilikan—komunal, kolektif, atau negara—menjadi hak kepemilikan privat yang dapat diperdagangkan di pasar.</p>\n<p>Rosa Luxemburg dalam <em>The Accumulation of Capital</em> telah mengantisipasi argumen Harvey dengan menekankan bahwa kapitalisme memerlukan &quot;lingkungan non-kapitalis&quot; untuk terus berakumulasi. Harvey mengembangkan insight Luxemburg dengan menunjukkan bahwa penciptaan lingkungan non-kapitalis ini bukan hanya terjadi melalui ekspansi geografis, tetapi juga melalui komodifikasi aspek-aspek kehidupan yang sebelumnya belum terkomodifikasi.</p>\n<p>Mekanisme accumulation by dispossession menurut Harvey (2005) meliputi empat proses utama. Pertama, <strong>privatisasi dan komodifikasi</strong> aset-aset publik dan komunal, termasuk tanah, air, udara, dan bahkan layanan publik seperti pendidikan dan kesehatan. Kedua, <strong>finansialisasi</strong> yang memungkinkan akumulasi melalui manipulasi sistem kredit dan utang. Ketiga, <strong>manajemen dan manipulasi krisis</strong> yang menciptakan peluang akumulasi melalui devaluasi aset. Keempat, <strong>redistribusi negara</strong> melalui kebijakan yang menguntungkan kelas kapitalis.</p>\n<p>Dalam konteks agraria, accumulation by dispossession terutama termanifestasi melalui proses <strong>land grabbing</strong> dan transformasi sistem tenure tanah. Harvey menekankan bahwa tanah memiliki karakteristik unik sebagai komoditas karena tidak dapat diproduksi dan memiliki lokasi tetap. Hal ini menciptakan potensi <strong>monopoly rent</strong> yang sangat menguntungkan bagi pemilik kapital yang berhasil mengontrol tanah-tanah strategis.</p>\n<p>Peran negara dalam proses ini sangat krusial. Harvey mengadaptasi konsep Gramsci tentang hegemoni untuk menjelaskan bagaimana negara tidak hanya menggunakan koersi, tetapi juga konsensus untuk melegitimasi proses perampasan. Negara menciptakan kerangka hukum dan regulasi yang memfasilitasi akumulasi, sekaligus mengembangkan narasi pembangunan yang menjustifikasi perampasan sebagai &quot;kepentingan nasional&quot;.</p>\n<p>Kritik terhadap teori Harvey terutama datang dari perspektif yang menekankan agency komunitas lokal dan kompleksitas relasi kuasa di tingkat lokal. Namun, kekuatan analitis teori Harvey terletak pada kemampuannya menghubungkan fenomena lokal dengan dinamika kapitalisme global, sekaligus menunjukkan kontinuitas historis antara akumulasi primitif klasik dengan perampasan kontemporer.</p>\n<div class="article-key-takeaway"><div class="key-takeaway-label">Poin Penting</div><p>Teori accumulation by dispossession Harvey memberikan kerangka analitis untuk memahami bagaimana kapitalisme kontemporer tidak hanya bergantung pada eksploitasi tenaga kerja, tetapi juga pada apropriasi langsung atas commons melalui mekanisme perampasan yang difasilitasi negara.</p></div>\n<div class="article-back-to-section"><a href="#daftar-isi" class="back-to-top-link" aria-label="Kembali ke daftar isi">&uarr; Kembali ke Daftar Isi</a></div><h2 id="manifestasi-akumulasi-primitif-di-indonesia-kontemporer">Manifestasi Akumulasi Primitif di Indonesia Kontemporer</h2>\n<p>Transformasi ekonomi politik Indonesia sejak era Orde Baru hingga kontemporer menunjukkan manifestasi konkret dari accumulation by dispossession dalam berbagai bentuk. Proses ini dipercepat melalui adopsi kebijakan neoliberal yang dimulai pada 1980-an dan mengalami intensifikasi pasca-krisis 1997-1998 melalui program structural adjustment yang dipaksakan IMF dan Bank Dunia.</p>\n<p><strong>Land grabbing</strong> untuk ekspansi perkebunan kelapa sawit merupakan manifestasi paling masif dari accumulation by dispossession di Indonesia. Data Sawit Watch menunjukkan bahwa luas perkebunan kelapa sawit meningkat dari 294.560 hektare pada 1980 menjadi lebih dari 16 juta hektare pada 2020. Ekspansi ini tidak hanya melibatkan konversi hutan, tetapi juga perampasan tanah-tanah komunal dan adat yang telah dikelola secara berkelanjutan oleh komunitas lokal selama berabad-abad.</p>\n<p>Mekanisme perampasan ini difasilitasi melalui instrumen hukum seperti Hak Guna Usaha (HGU) yang memberikan akses eksklusif kepada korporasi atas tanah-tanah yang diklaim sebagai &quot;tanah negara&quot;. Konsep tanah negara sendiri merupakan produk kolonial yang diadopsi dan diperluas oleh rezim post-kolonial untuk memfasilitasi akumulasi kapital. Undang-Undang Pokok Agraria 1960 yang sebenarnya dimaksudkan untuk melakukan redistribusi lahan justru menjadi instrumen legitimasi bagi perampasan melalui klausul &quot;fungsi sosial&quot; yang ditafsirkan secara sepihak oleh negara.</p>\n<p>Kasus perkebunan kelapa sawit di Kalimantan dan Sumatera menunjukkan bagaimana proses accumulation by dispossession beroperasi. Komunitas Dayak dan Melayu yang telah mengelola hutan dan lahan secara adat dipaksa melepaskan tanah mereka dengan kompensasi yang tidak memadai atau bahkan tanpa kompensasi sama sekali. Tanah-tanah tersebut kemudian ditransformasikan menjadi monokultur kelapa sawit yang menghasilkan profit bagi korporasi multinasional dan domestik.</p>\n<p>Proyek infrastruktur strategis nasional juga menjadi arena penting accumulation by dispossession. Program seperti pembangunan jalan tol, bandara, dan kawasan industri melibatkan pembebasan lahan dalam skala masif. Undang-Undang Nomor 2 Tahun 2012 tentang Pengadaan Tanah bagi Pembangunan untuk Kepentingan Umum memberikan kewenangan luas kepada negara untuk melakukan pencabutan hak atas tanah dengan dalih &quot;kepentingan umum&quot; yang didefinisikan secara elastis.</p>\n<p>Kasus pembangunan Bandara Internasional Yogyakarta di Kulon Progo mengilustrasikan mekanisme ini. Petani yang tanahnya dibebaskan tidak hanya kehilangan akses terhadap means of production, tetapi juga tercerabut dari sistem sosial-ekonomi yang telah mereka bangun. Kompensasi yang diberikan tidak mempertimbangkan nilai sosial dan budaya tanah, hanya nilai ekonomi yang ditetapkan secara sepihak oleh negara.</p>\n<p><strong>Finansialisasi</strong> tanah juga menjadi dimensi penting accumulation by dispossession di Indonesia. Tanah semakin diperlakukan sebagai aset finansial yang dapat diperjualbelikan, diagunkan, dan dijadikan instrumen spekulasi. Real Estate Investment Trusts (REITs) dan berbagai produk derivatif properti menciptakan gelembung spekulatif yang menaikkan harga tanah secara artifisial, sehingga semakin menyulitkan akses petani dan masyarakat miskin terhadap tanah.</p>\n<p>Kawasan Ekonomi Khusus (KEK) yang dikembangkan di berbagai daerah juga merupakan manifestasi accumulation by dispossession. KEK menciptakan enclave ekonomi yang memberikan privilese khusus kepada investor, termasuk kemudahan perizinan, insentif fiskal, dan akses terhadap tanah dengan harga murah. Pembentukan KEK sering kali melibatkan perampasan tanah produktif milik petani yang kemudian ditransformasikan menjadi zona akumulasi kapital.</p>\n<div class="article-key-takeaway"><div class="key-takeaway-label">Poin Penting</div><p>Manifestasi accumulation by dispossession di Indonesia terjadi melalui multiple channels—ekspansi perkebunan, proyek infrastruktur, finansialisasi tanah, dan pembentukan KEK—yang semuanya difasilitasi oleh transformasi kerangka hukum dan regulasi yang mengutamakan kepentingan akumulasi kapital atas hak-hak komunitas lokal.</p></div>\n<div class="article-back-to-section"><a href="#daftar-isi" class="back-to-top-link" aria-label="Kembali ke daftar isi">&uarr; Kembali ke Daftar Isi</a></div><h2 id="mekanisme-perampasan-dalam-proyek-pembangunan-dan-investasi">Mekanisme Perampasan dalam Proyek Pembangunan dan Investasi</h2>\n<p>Analisis mekanisme perampasan dalam konteks proyek pembangunan dan investasi di Indonesia menunjukkan sofistikasi strategi accumulation by dispossession yang melibatkan kolaborasi kompleks antara negara, kapital domestik, dan kapital internasional. Mekanisme ini beroperasi melalui multiple layers yang saling memperkuat, mulai dari transformasi kerangka hukum hingga penggunaan aparatus keamanan untuk menekan resistensi.</p>\n<p><strong>Transformasi kerangka hukum</strong> menjadi instrumen utama dalam memfasilitasi perampasan. Rachman (2012) menunjukkan bahwa reformasi hukum agraria pasca-1998 justru memperkuat orientasi neoliberal dalam pengelolaan sumber daya alam. Undang-Undang Nomor 25 Tahun 2007 tentang Penanaman Modal memberikan jaminan kepastian investasi yang ditafsirkan sebagai prioritas akses investor terhadap tanah dan sumber daya alam. Regulasi ini menciptakan hierarki hak yang menempatkan hak investor di atas hak komunitas lokal.</p>\n<p>Konsep &quot;highest and best use&quot; yang diadopsi dalam berbagai regulasi mencerminkan logika kapitalis yang mereduksi tanah menjadi faktor produksi yang harus dioptimalkan untuk menghasilkan nilai tukar maksimal. Konsep ini mengabaikan dimensi sosial, budaya, dan ekologis tanah yang tidak dapat dikuantifikasi dalam perhitungan ekonomi konvensional. Sebagaimana Harvey (2001) argumentasikan, reduksi tanah menjadi komoditas merupakan bentuk &quot;commodity fetishism&quot; yang menyembunyikan relasi sosial di balik pertukaran ekonomi.</p>\n<p><strong>Mekanisme kompensasi</strong> yang diterapkan dalam pembebasan lahan juga mencerminkan logika accumulation by dispossession. Kompensasi dihitung berdasarkan Nilai Jual Objek Pajak (NJOP) yang umumnya jauh di bawah harga pasar, apalagi jika dibandingkan dengan nilai produktivitas jangka panjang tanah tersebut. Sistem kompensasi ini tidak mengakui konsep <strong>reproduction cost</strong>—biaya yang diperlukan untuk mereproduksi kondisi sosial-ekonomi yang hilang akibat perampasan tanah.</p>\n<p>Kasus pembangunan pabrik semen di Rembang menunjukkan bagaimana mekanisme kompensasi menjadi instrumen perampasan. Petani tidak hanya kehilangan tanah pertanian, tetapi juga akses terhadap mata air yang selama ini menjadi sumber irigasi. Kompensasi yang diberikan tidak memperhitungkan kerugian ekologis dan sosial jangka panjang, sehingga menciptakan <strong>environmental debt</strong> yang ditanggung oleh komunitas lokal.</p>\n<p><strong>Fragmentasi resistensi</strong> menjadi strategi penting dalam melancarkan proses perampasan. Korporasi dan negara menggunakan berbagai taktik untuk memecah solidaritas komunitas, termasuk pemberian kompensasi yang berbeda-beda, rekrutmen tokoh lokal sebagai mediator, dan penciptaan konflik horizontal antar kelompok masyarakat. Strategi ini mencerminkan apa yang Gramsci sebut sebagai &quot;transformisme&quot;—kooptasi elemen-elemen oposisi ke dalam blok hegemonik yang dominan.</p>\n<p><strong>Militarisasi</strong> wilayah konflik agraria juga menjadi mekanisme penting dalam memfasilitasi accumulation by dispossession. Data KPA menunjukkan bahwa 70% konflik agraria melibatkan kekerasan dari aparatus keamanan negara. Kekerasan ini bukan sekadar efek samping dari konflik, tetapi strategi sistematis untuk menciptakan kondisi yang kondusif bagi akumulasi kapital. Sebagaimana Harvey (2003) jelaskan, &quot;the state's monopoly of violence and definitions of legality&quot; menjadi instrumen krusial dalam proses perampasan.</p>\n<p>Kasus Mesuji di Lampung mengilustrasikan bagaimana kekerasan negara difungsikan untuk memfasilitasi ekspansi perkebunan. Petani yang melakukan okupasi lahan yang diklaim sebagai HGU perusahaan menghadapi represi brutal dari gabungan TNI, Polri, dan preman bayaran perusahaan. Kekerasan ini menciptakan <strong>climate of fear</strong> yang memaksa petani melepaskan klaim mereka atas tanah.</p>\n<p><strong>Diskursif hegemoni</strong> pembangunan juga berperan dalam melegitimasi perampasan. Narasi &quot;pembangunan untuk kesejahteraan rakyat&quot; dan &quot;percepatan pertumbuhan ekonomi&quot; digunakan untuk menjustifikasi pengorbanan hak-hak komunitas lokal demi &quot;kepentingan yang lebih besar&quot;. Diskursus ini menciptakan false choice antara pembangunan dan konservasi, antara modernitas dan tradisi, yang menyembunyikan kemungkinan alternatif pembangunan yang lebih adil dan berkelanjutan.</p>\n<div class="article-key-takeaway"><div class="key-takeaway-label">Poin Penting</div><p>Mekanisme perampasan dalam proyek pembangunan beroperasi melalui transformasi hukum, manipulasi kompensasi, fragmentasi resistensi, militarisasi, dan hegemoni diskursif yang secara sinergis menciptakan kondisi optimal bagi accumulation by dispossession sambil meminimalkan potensi resistensi terorganisir.</p></div>\n<div class="article-back-to-section"><a href="#daftar-isi" class="back-to-top-link" aria-label="Kembali ke daftar isi">&uarr; Kembali ke Daftar Isi</a></div><h2 id="resistensi-petani-dan-kontradiksi-akumulasi-kapital">Resistensi Petani dan Kontradiksi Akumulasi Kapital</h2>\n<p>Proses accumulation by dispossession tidak berlangsung tanpa resistensi. Komunitas petani dan masyarakat adat di Indonesia telah mengembangkan berbagai bentuk perlawanan yang menunjukkan kontradiksi inheren dalam sistem akumulasi kapitalis. Resistensi ini tidak hanya berfungsi sebagai respons defensif terhadap perampasan, tetapi juga sebagai artikulasi alternatif model pembangunan yang lebih demokratis dan berkelanjutan.</p>\n<p><strong>Resistensi terorganisir</strong> melalui serikat-serikat petani seperti Serikat Petani Indonesia (SPI), Aliansi Gerakan Reforma Agraria (AGRA), dan berbagai organisasi lokal menunjukkan kapasitas petani dalam membangun solidaritas lintas wilayah. Organisasi-organisasi ini tidak hanya melakukan advokasi kebijakan, tetapi juga memfasilitasi <strong>land occupation</strong> sebagai bentuk direct action untuk merebut kembali tanah yang dirampas. Gerakan okupasi lahan di berbagai daerah—dari Jenggawah di Jember hingga Mesuji di Lampung—menunjukkan bahwa petani tidak pasif menerima perampasan.</p>\n<p>Konsep <strong>kedaulatan pangan</strong> yang diperjuangkan gerakan petani merupakan counter-hegemoni terhadap logika accumulation by dispossession. Kedaulatan pangan tidak hanya menekankan aspek teknis produksi pertanian, tetapi juga kontrol demokratis atas sistem pangan, akses terhadap tanah dan benih, serta penolakan terhadap komodifikasi pangan. Konsep ini menantang fundamental assumption kapitalisme bahwa efisiensi pasar merupakan mekanisme optimal untuk alokasi sumber daya.</p>\n<p><strong>Revitalisasi sistem pengelolaan komunal</strong> juga menjadi bentuk resistensi penting terhadap privatisasi tanah. Berbagai komunitas adat berupaya memperkuat sistem tenure tradisional sebagai alternatif terhadap sistem kepemilikan individual yang rentan terhadap komodifikasi. Inisiatif seperti hutan adat, sistem subak di Bali, dan pengelolaan komunal lahan di berbagai daerah menunjukkan viabilitas sistem pengelolaan non-kapitalis.</p>\n<p>Namun, resistensi petani juga menghadapi <strong>kontradiksi internal</strong> yang mencerminkan kompleksitas proses akumulasi kapital. Sebagian petani yang terlibat dalam resistensi terhadap land grabbing secara bersamaan juga terjebak dalam logika pasar melalui ketergantungan pada input pertanian industrial, kredit bank, dan orientasi produksi untuk pasar. Kontradiksi ini menciptakan <strong>ambivalensi</strong> dalam perjuangan petani yang tidak selalu konsisten menentang logika kapitalisme.</p>\n<p><strong>Kooptasi</strong> gerakan petani oleh negara dan partai politik juga menjadi tantangan serius. Program-program seperti redistribusi aset (land reform) yang dilakukan pemerintah sering kali berfungsi sebagai safety valve untuk meredakan tekanan sosial tanpa mengubah struktur fundamental sistem agraria. Pembagian sertifikat tanah dalam jumlah terbatas kepada sebagian petani dapat menciptakan ilusi reformasi sambil mempertahankan dominasi korporasi atas sumber daya agraria strategis.</p>\n<p><strong>Fragmentasi</strong> gerakan petani berdasarkan identitas etnis, agama, dan regional juga melemahkan potensi resistensi kolektif. Strategi divide et impera yang digunakan negara dan korporasi berhasil menciptakan kompetisi antar kelompok petani untuk mendapatkan akses terbatas terhadap tanah dan sumber daya. Fragmentasi ini mencerminkan apa yang Marx sebut sebagai kompetisi antar pekerja yang menguntungkan kapital.</p>\n<p>Meski demikian, resistensi petani telah menciptakan <strong>krisis legitimasi</strong> bagi proyek-proyek accumulation by dispossession. Kasus seperti penolakan petani terhadap reklamasi Teluk Jakarta, resistensi masyarakat Kendeng terhadap pabrik semen, dan perjuangan masyarakat adat Dayak melawan ekspansi perkebunan sawit telah memaksa negara mengeluarkan biaya politik dan ekonomi yang tinggi untuk mempertahankan proses akumulasi.</p>\n<p><strong>Solidaritas internasional</strong> juga memperkuat resistensi lokal melalui jaringan seperti La Via Campesina yang menghubungkan gerakan petani Indonesia dengan gerakan global. Solidaritas ini tidak hanya memberikan dukungan moral dan politik, tetapi juga memfasilitasi pertukaran strategi dan taktik perjuangan. Kerangka analisis tentang land grabbing sebagai fenomena global membantu gerakan lokal memahami posisi mereka dalam konteks yang lebih luas.</p>\n<p>Resistensi petani juga menghasilkan <strong>inovasi organisasional</strong> yang menantang bentuk-bentuk organisasi konvensional. Gerakan seperti Serikat Pekerja Tani Karawang (SEPETAK) mengembangkan model organisasi yang mengombinasikan perjuangan ekonomi dan politik, sekaligus membangun alternatif ekonomi melalui koperasi dan sistem pertanian berkelanjutan. Model ini menunjukkan kemungkinan membangun counter-hegemoni yang tidak hanya menentang kapitalisme tetapi juga membangun alternatifnya.</p>\n<div class="article-key-takeaway"><div class="key-takeaway-label">Poin Penting</div><p>Resistensi petani terhadap accumulation by dispossession menciptakan kontradiksi dalam sistem akumulasi kapital yang memaksa negara mengeluarkan biaya tinggi untuk mempertahankan kondisi akumulasi, sekaligus membuka ruang untuk artikulasi alternatif pembangunan yang lebih demokratis dan berkelanjutan.</p></div>\n<div class="article-back-to-section"><a href="#daftar-isi" class="back-to-top-link" aria-label="Kembali ke daftar isi">&uarr; Kembali ke Daftar Isi</a></div><h2 id="kesimpulan">Kesimpulan</h2>\n<p>Analisis konflik agraria di Indonesia melalui kerangka teori accumulation by dispossession David Harvey menunjukkan bahwa perampasan tanah dan sumber daya alam bukan sekadar efek samping dari pembangunan, melainkan strategi sistematis untuk mengatasi krisis akumulasi kapital. Proses ini melibatkan transformasi fundamental dalam relasi sosial agraria, di mana tanah yang sebelumnya memiliki fungsi sosial, budaya, dan ekologis direduksi menjadi komoditas yang dapat diperjualbelikan di pasar.</p>\n<p>Manifestasi accumulation by dispossession di Indonesia terjadi melalui multiple channels yang saling memperkuat: ekspansi perkebunan monokultur, proyek infrastruktur strategis, finansialisasi tanah, dan pembentukan kawasan ekonomi khusus. Semua proses ini difasilitasi oleh transformasi kerangka hukum yang mengutamakan kepentingan investasi atas hak-hak komunitas lokal, sekaligus menggunakan aparatus keamanan negara untuk menekan resistensi.</p>\n<p>Mekanisme perampasan beroperasi tidak hanya melalui koersi langsung, tetapi juga melalui hegemoni diskursif yang melegitimasi perampasan sebagai &quot;kepentingan pembangunan nasional&quot;. Sistem kompensasi yang tidak memadai, fragmentasi resistensi, dan kooptasi elemen-elemen oposisi menjadi instrumen penting dalam melancarkan proses akumulasi. Hal ini menunjukkan bahwa accumulation by dispossession bukan hanya proses ekonomi, tetapi juga proses politik yang melibatkan rekonfigurasi relasi kuasa.</p>\n<p>Resistensi petani dan masyarakat adat terhadap perampasan menunjukkan bahwa proses accumulation by dispossession tidak berlangsung tanpa kontradiksi. Gerakan okupasi lahan, revitalisasi sistem pengelolaan komunal, dan artikulasi konsep kedaulatan pangan merupakan bentuk-bentuk counter-hegemoni yang menantang logika kapitalisme. Meski menghadapi fragmentasi internal dan kooptasi, resistensi ini telah menciptakan krisis legitimasi yang memaksa negara mengeluarkan biaya politik dan ekonomi tinggi untuk mempertahankan kondisi akumulasi.</p>\n<p>Dari perspektif teoretis, kasus Indonesia memperkuat argumen Harvey bahwa accumulation by dispossession merupakan feature permanen kapitalisme kontemporer, bukan hanya fenomena historis yang terjadi pada fase awal akumulasi primitif. Proses ini menunjukkan bahwa kapitalisme tidak hanya bergantung pada eksploitasi surplus value melalui hubungan kerja upahan, tetapi juga pada apropriasi langsung atas commons dan transformasi nilai guna menjadi nilai tukar.</p>\n<p><strong>Implikasi praktis</strong> dari analisis ini menunjukkan pentingnya gerakan petani mengembangkan strategi perjuangan yang tidak hanya defensif tetapi juga ofensif dalam membangun alternatif sistem agraria. Perjuangan land reform tidak dapat dipisahkan dari kritik terhadap sistem kapitalisme secara keseluruhan, karena selama logika akumulasi kapital masih dominan, tekanan terhadap sumber daya agraria akan terus berlanjut.</p>\n<p><strong>Rekomendasi untuk gerakan petani</strong> meliputi: pertama, penguatan solidaritas lintas sektoral dengan gerakan buruh, lingkungan, dan hak asasi manusia untuk membangun blok counter-hegemonik yang lebih luas. Kedua, pengembangan alternatif ekonomi melalui koperasi, sistem pertanian berkelanjutan, dan ekonomi komunal yang dapat menunjukkan viabilitas model pembangunan non-kapitalis. Ketiga, penguatan kapasitas analisis untuk memahami dinamika kapitalisme global dan mengembangkan strategi yang sesuai dengan konteks lokal.</p>\n<p>Pada akhirnya, konflik agraria di Indonesia menunjukkan bahwa pertanyaan tentang tanah adalah pertanyaan tentang model pembangunan dan sistem ekonomi politik secara keseluruhan. Penyelesaian konflik agraria memerlukan transformasi struktural yang melampaui redistribusi lahan, yaitu demokratisasi kontrol atas sumber daya produktif dan pengembangan sistem ekonomi yang mengutamakan kebutuhan manusia atas akumulasi kapital.</p>\n<div class="article-back-to-section"><a href="#daftar-isi" class="back-to-top-link" aria-label="Kembali ke daftar isi">&uarr; Kembali ke Daftar Isi</a></div><section class="article-bibliography"><h2 id="daftar-pustaka">Daftar Pustaka</h2>\n<p>Gramsci, A. (1971). <em>Selections from the Prison Notebooks</em>. International Publishers.</p>\n<p>Harvey, D. (2001). <em>Spaces of Capital: Towards a Critical Geography</em>. Edinburgh University Press.</p>\n<p>Harvey, D. (2003). <em>The New Imperialism</em>. Oxford University Press.</p>\n<p>Harvey, D. (2005). <em>A Brief History of Neoliberalism</em>. Oxford University Press.</p>\n<p>Konsorsium Pembaruan Agraria. (2023). <em>Catatan Akhir Tahun 2023: Reforma Agraria Terhambat, Konflik Agraria Meningkat</em>. KPA.</p>\n<p>Luxemburg, R. (1913). <em>The Accumulation of Capital</em>. Monthly Review Press.</p>\n<p>Marx, K. (1867). <em>Das Kapital: A Critique of Political Economy Volume 1</em>. Vintage Books.</p>\n<p>Poulantzas, N. (1978). <em>State, Power, Socialism</em>. New Left Books.</p>\n<p>Rachman, N. F. (2012). <em>Land Reform dari Masa ke Masa</em>. Tanah Air Beta.</p>\n<p>Wallerstein, I. (2004). <em>World-Systems Analysis: An Introduction</em>. Duke University Press.</p>\n</section><hr class="article-disclosure-divider"><aside class="article-disclosure"><p><em>Artikel ini disusun dengan bantuan kecerdasan buatan dan telah ditinjau oleh redaksi SEPETAK. Referensi yang dicantumkan adalah sumber nyata yang dapat diverifikasi. Pandangan dalam artikel ini tidak selalu mencerminkan posisi resmi organisasi.</em></p></aside>	published	2026-04-18 00:21:57	1	2026-04-18 00:20:15	2026-04-18 00:21:57	\N	auto_generated	5	5	t
48	Pertanyaan Agraria Abad ke-21: Dari Kautsky hingga Bernstein dan Relevansinya bagi Transformasi Pedesaan Indonesia	pertanyaan-agraria-abad-ke-21-dari-kautsky-hingga-bernstein-dan-relevansinya-bagi-transformasi-pedesaan-indonesia	Pertanyaan agraria (The Agrarian Question) yang pertama kali dirumuskan Karl Kautsky pada 1899 tetap relevan dalam memahami dinamika pedesaan abad ke-21. Artikel ini mengkaji evolusi konseptual pertanyaan agraria dari formulasi klasik Kautsky hingga reformulasi kontemporer Henry Bernstein, serta menganalisis relevansinya bagi transformasi pedesaan Indonesia. Melalui analisis literatur ekonomi politik agraria, artikel ini menunjukkan bahwa pertanyaan agraria telah bertransformasi dari fokus pada 	<div class="article-meta"><p><strong>Kata Kunci:</strong> pertanyaan agraria, Kautsky, Bernstein, transformasi pedesaan, ekonomi politik agraria</p>\n<p><strong>Waktu Baca:</strong> ± 12 menit</p></div>\n<nav class="article-toc"><h2 id="daftar-isi">Daftar Isi</h2><ol>\n<li><a href="#abstrak">Abstrak</a></li>\n<li><a href="#pendahuluan">Pendahuluan</a></li>\n<li><a href="#warisan-kautsky-fondasi-pertanyaan-agraria-klasik">Warisan Kautsky: Fondasi Pertanyaan Agraria Klasik</a></li>\n<li><a href="#evolusi-pemikiran-agraria-dari-diferensiasi-hingga-depeasantisasi">Evolusi Pemikiran Agraria: Dari Diferensiasi hingga Depeasantisasi</a></li>\n<li><a href="#bernstein-dan-reformulasi-pertanyaan-agraria-kontemporer">Bernstein dan Reformulasi Pertanyaan Agraria Kontemporer</a></li>\n<li><a href="#transformasi-agraria-indonesia-dalam-perspektif-global">Transformasi Agraria Indonesia dalam Perspektif Global</a></li>\n<li><a href="#kesimpulan">Kesimpulan</a></li>\n<li><a href="#daftar-pustaka">Daftar Pustaka</a></li>\n</ol></nav>\n<section class="article-abstract"><h2 id="abstrak">Abstrak</h2>\n<p>Pertanyaan agraria (<em>The Agrarian Question</em>) yang pertama kali dirumuskan Karl Kautsky pada 1899 tetap relevan dalam memahami dinamika pedesaan abad ke-21. Artikel ini mengkaji evolusi konseptual pertanyaan agraria dari formulasi klasik Kautsky hingga reformulasi kontemporer Henry Bernstein, serta menganalisis relevansinya bagi transformasi pedesaan Indonesia. Melalui analisis literatur ekonomi politik agraria, artikel ini menunjukkan bahwa pertanyaan agraria telah bertransformasi dari fokus pada diferensiasi petani menjadi analisis kompleks tentang <strong>depeasantisasi</strong>, <strong>repeasantisasi</strong>, dan integrasi petani dalam rantai nilai global. Temuan utama menunjukkan bahwa kondisi agraria Indonesia mencerminkan kontradiksi global antara logika akumulasi kapital dan persistensi ekonomi petani. Artikel ini berargumen bahwa memahami evolusi pertanyaan agraria menjadi kunci dalam merumuskan strategi perjuangan agraria yang relevan dengan kondisi kontemporer, khususnya dalam menghadapi penetrasi kapital finansial dan ekspansi agribisnis di pedesaan Indonesia.</p>\n</section><h2 id="pendahuluan">Pendahuluan</h2>\n<p><strong>Pertanyaan agraria</strong> (<em>The Agrarian Question</em>) merupakan salah satu konsep fundamental dalam ekonomi politik yang telah membentuk pemahaman kita tentang dinamika pedesaan selama lebih dari satu abad. Pertama kali dirumuskan oleh Karl Kautsky dalam karyanya <em>Die Agrarfrage</em> (1899), pertanyaan agraria pada dasarnya mempertanyakan nasib petani dalam perkembangan kapitalisme dan bagaimana sektor pertanian terintegrasi dalam sistem ekonomi kapitalis yang lebih luas.</p>\n<p>Relevansi pertanyaan agraria tidak surut seiring berjalannya waktu. Bahkan, dalam konteks globalisasi dan financialization yang mengkarakterisasi abad ke-21, pertanyaan ini menjadi semakin mendesak. Henry Bernstein (2010) dalam <em>Class Dynamics of Agrarian Change</em> menegaskan bahwa pertanyaan agraria kontemporer tidak lagi sekadar tentang diferensiasi petani, melainkan tentang proses <strong>depeasantisasi</strong> yang kompleks dan kontradiktif dalam era kapitalisme global.</p>\n<p>Indonesia, sebagai negara agraris dengan 70% penduduk bergantung pada sektor pertanian, menjadi laboratorium empiris yang menarik untuk memahami evolusi pertanyaan agraria. Transformasi pedesaan Indonesia sejak era Orde Baru hingga reformasi menunjukkan dinamika yang kompleks antara persistensi ekonomi petani dan penetrasi kapital agribisnis (White &amp; Wiradi, 2012).</p>\n<p>Artikel ini berargumen bahwa evolusi konseptual pertanyaan agraria dari Kautsky hingga Bernstein memberikan kerangka analitis yang kritis untuk memahami transformasi agraria Indonesia kontemporer. Tesis utama yang akan dibangun adalah bahwa <strong>pertanyaan agraria abad ke-21 tidak lagi tentang apakah petani akan menghilang, melainkan tentang bagaimana petani bertransformasi dan beradaptasi dalam kondisi kapitalisme global yang semakin penetratif</strong>.</p>\n<p>Struktur artikel ini akan menelusuri genealogi intelektual pertanyaan agraria, dimulai dari formulasi klasik Kautsky, evolusi pemikiran agraria melalui berbagai kontribusi teoretis, reformulasi kontemporer Bernstein, dan aplikasinya dalam konteks transformasi pedesaan Indonesia. Melalui analisis komparatif dan dialektis, artikel ini berupaya memberikan kontribusi pada pemahaman teoretis sekaligus praktis tentang dinamika agraria kontemporer.</p>\n<div class="article-back-to-section"><a href="#daftar-isi" class="back-to-top-link" aria-label="Kembali ke daftar isi">&uarr; Kembali ke Daftar Isi</a></div><h2 id="warisan-kautsky-fondasi-pertanyaan-agraria-klasik">Warisan Kautsky: Fondasi Pertanyaan Agraria Klasik</h2>\n<p>Karl Kautsky dalam <em>Die Agrarfrage</em> (1899) merumuskan pertanyaan agraria sebagai investigasi tentang <strong>bagaimana kapitalisme mentransformasi pertanian dan nasib kelas petani dalam proses tersebut</strong>. Kautsky mengidentifikasi dua kecenderungan utama dalam perkembangan kapitalis di sektor pertanian: <strong>konsentrasi</strong> dan <strong>diferensiasi</strong>. Konsentrasi merujuk pada proses akumulasi tanah dan modal dalam unit-unit produksi yang lebih besar, sementara diferensiasi menunjukkan polarisasi kelas petani menjadi kapitalis agraris dan buruh tani.</p>\n<p>Kontribusi teoretis Kautsky yang paling fundamental adalah identifikasi <strong>kontradiksi spesifik kapitalisme agraris</strong>. Berbeda dengan industri, pertanian menghadapi kendala biologis dan ekologis yang membatasi intensifikasi kapital. Kautsky menunjukkan bahwa tanah sebagai <em>means of production</em> memiliki karakteristik unik: tidak dapat diperbanyak, memiliki fertilitas yang bervariasi, dan terikat pada siklus biologis yang tidak dapat sepenuhnya disubordinasi pada logika kapital.</p>\n<p>Analisis Kautsky tentang <strong>persistensi petani kecil</strong> menjadi paradoks yang terus relevan. Meskipun logika kapitalisme mendorong konsentrasi, petani kecil memiliki kemampuan bertahan karena kesediaannya bekerja dengan tingkat eksploitasi diri (<em>self-exploitation</em>) yang tinggi. Fenomena ini kemudian dikenal sebagai <strong>Chayanov effect</strong>, meskipun Kautsky telah mengidentifikasinya lebih awal.</p>\n<p>Dalam konteks Indonesia, observasi Kautsky tentang persistensi petani kecil terbukti akurat. Data BPS menunjukkan bahwa 70% rumah tangga pertanian Indonesia masih menguasai lahan kurang dari 0,5 hektar, namun tetap bertahan dalam sistem produksi yang terintegrasi dengan pasar global (White &amp; Wiradi, 2012). Hal ini mengkonfirmasi prediksi Kautsky bahwa <strong>diferensiasi petani tidak selalu berujung pada hilangnya petani kecil, melainkan pada transformasi relasi produksi</strong>.</p>\n<p>Kautsky juga mengantisipasi peran <strong>teknologi</strong> dalam transformasi agraria. Ia berpendapat bahwa adopsi teknologi modern akan mempercepat diferensiasi dengan memberikan keunggulan kompetitif pada petani yang memiliki akses modal. Dalam konteks Indonesia kontemporer, hal ini termanifestasi dalam <strong>digital divide</strong> antara petani yang memiliki akses teknologi informasi dan yang tidak, serta polarisasi akses terhadap input produksi modern.</p>\n<h3 id="kritik-terhadap-formulasi-klasik">Kritik terhadap Formulasi Klasik</h3>\n<p>Meskipun memberikan fondasi teoretis yang kokoh, formulasi Kautsky memiliki keterbatasan. Pertama, <strong>determinisme ekonomi</strong> yang terlalu kuat dalam memprediksi hilangnya petani kecil. Kenyataan menunjukkan bahwa petani kecil memiliki resiliensi yang lebih besar dari yang diprediksi. Kedua, <strong>underestimasi terhadap agency petani</strong> dalam merespons tekanan kapitalisme. Ketiga, <strong>fokus yang terlalu sempit pada diferensiasi internal</strong> tanpa mempertimbangkan faktor eksternal seperti kebijakan negara dan dinamika pasar global.</p>\n<div class="article-key-takeaway"><div class="key-takeaway-label">Poin Penting</div><p>Warisan Kautsky memberikan kerangka analitis fundamental tentang kontradiksi kapitalisme agraris, namun memerlukan reformulasi untuk menangkap kompleksitas transformasi agraria abad ke-21 yang melibatkan dimensi global, teknologi digital, dan financialization.</p></div>\n<div class="article-back-to-section"><a href="#daftar-isi" class="back-to-top-link" aria-label="Kembali ke daftar isi">&uarr; Kembali ke Daftar Isi</a></div><h2 id="evolusi-pemikiran-agraria-dari-diferensiasi-hingga-depeasantisasi">Evolusi Pemikiran Agraria: Dari Diferensiasi hingga Depeasantisasi</h2>\n<p>Setelah Kautsky, pemikiran agraria mengalami evolusi signifikan melalui kontribusi berbagai pemikir. <strong>Alexander Chayanov</strong> (1925) memberikan perspektif alternatif dengan teori ekonomi petani (<em>peasant economy theory</em>) yang menekankan logika produksi rumah tangga petani yang berbeda dari logika kapitalis. Chayanov berargumen bahwa petani kecil memiliki <strong>rasionalitas ekonomi spesifik</strong> yang tidak semata-mata berorientasi pada maksimalisasi profit, melainkan pada keseimbangan antara kerja dan konsumsi rumah tangga.</p>\n<p><strong>Eric Wolf</strong> dalam <em>Peasant Wars of the Twentieth Century</em> (1969) memperluas analisis dengan memasukkan dimensi politik dan perlawanan petani. Wolf menunjukkan bahwa petani bukan sekadar objek pasif transformasi kapitalisme, melainkan <strong>subjek politik aktif</strong> yang mampu melakukan perlawanan terorganisir. Konsep <strong>moral economy</strong> yang dikembangkan James Scott (1976) melengkapi perspektif ini dengan menekankan bahwa petani memiliki sistem nilai dan norma ekonomi yang berakar pada prinsip subsistensi dan reciprocity.</p>\n<p>Dalam konteks Indonesia, perspektif moral economy termanifestasi dalam praktik <strong>gotong royong</strong>, <strong>bawon</strong>, dan sistem <strong>gadai tanah</strong> yang masih bertahan di berbagai daerah. Penelitian White dan Wiradi (2012) menunjukkan bahwa institusi-institusi tradisional ini berfungsi sebagai <strong>mekanisme adaptasi</strong> petani dalam menghadapi penetrasi pasar dan tekanan ekonomi.</p>\n<h3 id="kontribusi-marxisme-agraris">Kontribusi Marxisme Agraris</h3>\n<p>Perkembangan pemikiran Marxis agraris memberikan kontribusi penting melalui karya <strong>Terence Byres</strong> dan <strong>Tom Brass</strong>. Byres (1991) mengembangkan konsep <strong>transisi agraris</strong> yang menekankan peran sektor pertanian dalam akumulasi primitif kapital. Sementara Brass (2011) memperkenalkan konsep <strong>unfree labor</strong> untuk menunjukkan bahwa kapitalisme agraris tidak selalu berujung pada proletarisasi penuh, melainkan seringkali menciptakan bentuk-bentuk kerja semi-bebas.</p>\n<p>Dalam konteks Indonesia, fenomena <strong>buruh tani musiman</strong>, <strong>sistem bagi hasil</strong>, dan <strong>kontrak farming</strong> mencerminkan karakteristik unfree labor yang diidentifikasi Brass. Petani tidak sepenuhnya terproletarisasi, namun juga tidak memiliki kontrol penuh atas proses produksi dan distribusi.</p>\n<h3 id="pendekatan-rantai-nilai-global">Pendekatan Rantai Nilai Global</h3>\n<p>Munculnya <strong>Global Value Chain (GVC) analysis</strong> dalam studi agraria memberikan perspektif baru tentang integrasi petani dalam ekonomi global. <strong>Jan Douwe van der Ploeg</strong> (2008) dalam <em>The New Peasantries</em> berargumen bahwa globalisasi menciptakan kondisi paradoksal: di satu sisi mendorong depeasantisasi melalui penetrasi agribisnis, di sisi lain membuka peluang <strong>repeasantisasi</strong> melalui diversifikasi ekonomi dan koneksi langsung dengan pasar.</p>\n<p>Konsep <strong>repeasantisasi</strong> menjadi relevan dalam konteks Indonesia dengan munculnya <strong>pertanian organik</strong>, <strong>agrowisata</strong>, dan <strong>direct marketing</strong> yang memungkinkan petani memperoleh value added yang lebih besar. Namun, akses terhadap peluang repeasantisasi ini tidak merata dan seringkali terbatas pada petani dengan modal sosial dan ekonomi yang memadai.</p>\n<h3 id="feminisasi-pertanian">Feminisasi Pertanian</h3>\n<p>Dimensi gender dalam transformasi agraria mendapat perhatian khusus melalui konsep <strong>feminisasi pertanian</strong>. Penelitian menunjukkan bahwa migrasi laki-laki ke sektor non-pertanian meningkatkan peran perempuan dalam aktivitas pertanian. Namun, feminisasi ini seringkali tidak diikuti dengan akses yang setara terhadap sumber daya produktif dan pengambilan keputusan (Sachs, 2018).</p>\n<p>Di Indonesia, feminisasi pertanian termanifestasi dalam peningkatan partisipasi perempuan dalam <strong>kelompok tani</strong>, <strong>koperasi</strong>, dan <strong>usaha mikro berbasis pertanian</strong>. Namun, kontrol terhadap tanah dan akses kredit masih didominasi laki-laki, menciptakan <strong>paradoks feminisasi</strong> yang perlu mendapat perhatian dalam analisis agraria kontemporer.</p>\n<div class="article-key-takeaway"><div class="key-takeaway-label">Poin Penting</div><p>Evolusi pemikiran agraria menunjukkan bahwa transformasi pedesaan tidak mengikuti pola linear diferensiasi, melainkan melibatkan proses kompleks yang mencakup resistensi petani, adaptasi institusional, dan reintegrasi dalam ekonomi global dengan berbagai modalitas.</p></div>\n<div class="article-back-to-section"><a href="#daftar-isi" class="back-to-top-link" aria-label="Kembali ke daftar isi">&uarr; Kembali ke Daftar Isi</a></div><h2 id="bernstein-dan-reformulasi-pertanyaan-agraria-kontemporer">Bernstein dan Reformulasi Pertanyaan Agraria Kontemporer</h2>\n<p>Henry Bernstein dalam <em>Class Dynamics of Agrarian Change</em> (2010) merumuskan kembali pertanyaan agraria untuk abad ke-21 dengan mengintegrasikan perkembangan teoretis dan empiris selama satu abad terakhir. <strong>Reformulasi Bernstein</strong> berpusat pada empat pertanyaan fundamental: (1) Siapa yang memiliki tanah? (2) Siapa yang bekerja di tanah? (3) Siapa yang memperoleh apa yang diproduksi dari tanah? (4) Apa yang mereka lakukan dengan surplus yang diperoleh?</p>\n<p>Kontribusi teoretis utama Bernstein adalah konsep <strong>&quot;farming for capital&quot;</strong> versus <strong>&quot;capital in farming&quot;</strong>. Farming for capital merujuk pada situasi di mana petani memproduksi komoditas untuk pasar kapitalis namun tidak sepenuhnya terintegrasi dalam relasi produksi kapitalis. Sementara capital in farming menunjukkan penetrasi langsung kapital dalam proses produksi pertanian melalui agribisnis dan korporasi multinasional.</p>\n<h3 id="depeasantisasi-dan-proletarisasi-parsial">Depeasantisasi dan Proletarisasi Parsial</h3>\n<p>Bernstein mengembangkan konsep <strong>depeasantisasi</strong> sebagai proses kompleks yang tidak selalu berujung pada proletarisasi penuh. Depeasantisasi meliputi: (1) kehilangan akses terhadap tanah, (2) ketergantungan pada pasar untuk reproduksi sosial, (3) diversifikasi sumber pendapatan di luar pertanian, dan (4) transformasi identitas sosial dari petani menjadi pekerja.</p>\n<p>Dalam konteks Indonesia, proses depeasantisasi termanifestasi dalam fenomena <strong>petani-buruh</strong> yang bekerja paruh waktu di pertanian dan paruh waktu di sektor lain. Data menunjukkan bahwa 60% rumah tangga petani Indonesia memperoleh pendapatan dari sumber non-pertanian (White &amp; Wiradi, 2012). Hal ini mencerminkan <strong>proletarisasi parsial</strong> yang diidentifikasi Bernstein.</p>\n<h3 id="financialization-dan-pertanian">Financialization dan Pertanian</h3>\n<p>Bernstein memberikan perhatian khusus pada <strong>financialization</strong> sebagai karakteristik baru kapitalisme agraris abad ke-21. Financialization merujuk pada penetrasi logika finansial dalam sektor pertanian melalui <strong>commodity derivatives</strong>, <strong>land grabbing</strong>, dan <strong>carbon trading</strong>. Proses ini menciptakan <strong>abstraksi baru</strong> dalam ekonomi agraris di mana nilai tanah dan produk pertanian semakin ditentukan oleh spekulasi finansial ketimbang produktivitas riil.</p>\n<p>Di Indonesia, financialization termanifestasi dalam ekspansi <strong>perkebunan kelapa sawit</strong> yang didorong oleh investasi finansial global, <strong>sertifikasi lahan</strong> untuk akses kredit perbankan, dan <strong>asuransi pertanian</strong> yang mengintegrasikan petani dalam sistem keuangan formal. Namun, integrasi ini seringkali menciptakan <strong>ketergantungan baru</strong> dan meningkatkan vulnerabilitas petani terhadap volatilitas pasar finansial.</p>\n<h3 id="kontradiksi-agraria-kontemporer">Kontradiksi Agraria Kontemporer</h3>\n<p>Bernstein mengidentifikasi <strong>tiga kontradiksi utama</strong> dalam agraria kontemporer. Pertama, <strong>kontradiksi antara produksi pangan dan produksi energi</strong> (biofuel) yang menciptakan kompetisi untuk lahan dan sumber daya. Kedua, <strong>kontradiksi antara intensifikasi dan sustainability</strong> yang mempertanyakan viabilitas jangka panjang pertanian industrial. Ketiga, <strong>kontradiksi antara globalisasi dan food sovereignty</strong> yang menciptakan ketegangan antara efisiensi ekonomi dan kedaulatan pangan.</p>\n<p>Kontradiksi-kontradiksi ini sangat relevan dalam konteks Indonesia. <strong>Ekspansi perkebunan kelapa sawit</strong> untuk biodiesel menciptakan kompetisi dengan produksi pangan dan mengancam ketahanan pangan lokal. <strong>Intensifikasi pertanian</strong> melalui revolusi hijau menunjukkan tanda-tanda <strong>ecological fatigue</strong> dengan penurunan produktivitas tanah dan pencemaran lingkungan. <strong>Liberalisasi perdagangan</strong> pertanian mengancam <strong>kedaulatan pangan</strong> dengan meningkatkan ketergantungan pada impor pangan strategis.</p>\n<h3 id="agency-dan-resistensi-dalam-era-global">Agency dan Resistensi dalam Era Global</h3>\n<p>Meskipun menekankan dominasi kapital, Bernstein tidak mengabaikan <strong>agency petani</strong> dalam merespons transformasi agraria. Ia mengidentifikasi berbagai bentuk resistensi: <strong>everyday resistance</strong> (Scott, 1985), <strong>exit strategies</strong> (migrasi dan diversifikasi), dan <strong>collective action</strong> melalui organisasi petani dan gerakan sosial.</p>\n<p>Dalam konteks Indonesia, agency petani termanifestasi dalam <strong>gerakan reforma agraria</strong>, <strong>serikat petani</strong>, dan <strong>inovasi teknologi lokal</strong>. Serikat Petani Indonesia (SPI) sebagai bagian dari La Via Campesina menunjukkan kemampuan petani untuk berorganisasi dalam skala global dan mengadvokasi <strong>food sovereignty</strong> sebagai alternatif terhadap food security yang berorientasi pasar.</p>\n<div class="article-key-takeaway"><div class="key-takeaway-label">Poin Penting</div><p>Reformulasi Bernstein menunjukkan bahwa pertanyaan agraria abad ke-21 bukan lagi tentang apakah petani akan menghilang, melainkan tentang modalitas transformasi agraria dalam era financialization dan bagaimana petani mempertahankan agency dalam kondisi dominasi kapital yang semakin penetratif.</p></div>\n<div class="article-back-to-section"><a href="#daftar-isi" class="back-to-top-link" aria-label="Kembali ke daftar isi">&uarr; Kembali ke Daftar Isi</a></div><h2 id="transformasi-agraria-indonesia-dalam-perspektif-global">Transformasi Agraria Indonesia dalam Perspektif Global</h2>\n<p>Indonesia menyediakan kasus empiris yang menarik untuk menguji relevansi evolusi pertanyaan agraria dari Kautsky hingga Bernstein. <strong>Transformasi agraria Indonesia</strong> sejak 1960-an menunjukkan karakteristik yang kompleks dan seringkali kontradiktif dengan prediksi teoretis klasik.</p>\n<h3 id="era-revolusi-hijau-dan-modernisasi-pertanian">Era Revolusi Hijau dan Modernisasi Pertanian</h3>\n<p><strong>Revolusi Hijau</strong> (1970-1990) di Indonesia mencerminkan upaya negara untuk memodernisasi pertanian melalui <strong>paket teknologi</strong> (bibit unggul, pupuk kimia, pestisida) dan <strong>intensifikasi produksi</strong>. Program ini berhasil mencapai <strong>swasembada beras</strong> pada 1984, namun juga menciptakan <strong>ketergantungan teknologi</strong> dan <strong>degradasi ekologi</strong> yang signifikan.</p>\n<p>Dari perspektif Kautsky, revolusi hijau dapat dipahami sebagai proses <strong>subsumsi formal</strong> pertanian ke dalam logika kapital melalui input industri. Namun, struktur agraria Indonesia tidak mengalami konsentrasi tanah yang diprediksi Kautsky. Sebaliknya, <strong>fragmentasi lahan</strong> semakin intensif dengan rata-rata kepemilikan turun dari 0,7 hektar (1973) menjadi 0,4 hektar (2013).</p>\n<h3 id="liberalisasi-dan-integrasi-pasar-global">Liberalisasi dan Integrasi Pasar Global</h3>\n<p><strong>Liberalisasi ekonomi</strong> pasca-1980an mengintegrasikan pertanian Indonesia dalam <strong>rantai nilai global</strong>. Ekspor komoditas perkebunan (kelapa sawit, karet, kakao) meningkat signifikan, namun impor pangan strategis (beras, jagung, kedelai) juga mengalami peningkatan. Hal ini mencerminkan <strong>spesialisasi komoditas</strong> yang diprediksi dalam teori perdagangan internasional, namun juga menciptakan <strong>vulnerabilitas pangan</strong> yang mengancam kedaulatan nasional.</p>\n<p>Dalam kerangka Bernstein, integrasi ini menunjukkan transisi dari <strong>farming for capital</strong> menuju <strong>capital in farming</strong>. <strong>Agribisnis multinasional</strong> seperti Cargill, Wilmar, dan Sinar Mas mengontrol segmen hulu dan hilir rantai nilai, sementara petani terjebak dalam posisi <strong>price taker</strong> dengan margin keuntungan yang semakin tipis.</p>\n<h3 id="financialization-dan-land-grabbing">Financialization dan Land Grabbing</h3>\n<p><strong>Financialization</strong> pertanian Indonesia termanifestasi dalam <strong>ekspansi perkebunan kelapa sawit</strong> yang didorong oleh investasi finansial global. Luas perkebunan kelapa sawit meningkat dari 1,1 juta hektar (1990) menjadi 14,3 juta hektar (2018), menjadikan Indonesia produsen terbesar dunia. Namun, ekspansi ini seringkali melibatkan <strong>land grabbing</strong> yang merugikan masyarakat adat dan petani kecil.</p>\n<p><strong>Konflik agraria</strong> meningkat signifikan dengan 212 kasus pada 2018 (KPA, 2019), sebagian besar terkait ekspansi perkebunan dan pembangunan infrastruktur. Hal ini mencerminkan <strong>kontradiksi fundamental</strong> antara akumulasi kapital dan hak-hak agraria masyarakat yang diidentifikasi dalam literatur agraria kritis.</p>\n<h3 id="depeasantisasi-dan-diversifikasi-ekonomi">Depeasantisasi dan Diversifikasi Ekonomi</h3>\n<p><strong>Depeasantisasi</strong> di Indonesia tidak mengikuti pola linear proletarisasi. Sebaliknya, terjadi <strong>diversifikasi ekonomi</strong> yang kompleks di mana rumah tangga petani mengombinasikan aktivitas pertanian dengan pekerjaan non-pertanian. <strong>Migrasi sirkuler</strong> menjadi strategi adaptasi utama dengan anggota keluarga bekerja di sektor industri dan jasa sambil mempertahankan koneksi dengan pertanian.</p>\n<p>Data menunjukkan bahwa <strong>50% tenaga kerja pertanian</strong> bekerja paruh waktu, mengkombinasikan pertanian dengan aktivitas lain (White &amp; Wiradi, 2012). Fenomena <strong>petani-buruh</strong> ini mencerminkan <strong>proletarisasi parsial</strong> yang diidentifikasi Bernstein, di mana petani tidak sepenuhnya terpisah dari means of production namun juga tidak memiliki kontrol penuh atas proses produksi.</p>\n<h3 id="gerakan-petani-dan-food-sovereignty">Gerakan Petani dan Food Sovereignty</h3>\n<p><strong>Gerakan petani Indonesia</strong> menunjukkan agency kolektif dalam merespons transformasi agraria. <strong>Serikat Petani Indonesia (SPI)</strong> sebagai organisasi petani terbesar mengadvokasi <strong>reforma agraria</strong> dan <strong>kedaulatan pangan</strong> sebagai alternatif terhadap liberalisasi pertanian. <strong>Aliansi Gerakan Reforma Agraria (AGRA)</strong> memperjuangkan redistribusi tanah dan demokratisasi akses sumber daya agraria.</p>\n<p>Konsep <strong>food sovereignty</strong> yang diperjuangkan gerakan petani Indonesia sejalan dengan kritik Bernstein terhadap <strong>food security</strong> yang berorientasi pasar. Food sovereignty menekankan hak petani dan masyarakat untuk menentukan sistem pangan mereka sendiri, termasuk <strong>hak atas benih</strong>, <strong>teknologi ramah lingkungan</strong>, dan <strong>pasar lokal</strong>.</p>\n<h3 id="teknologi-digital-dan-pertanian-presisi">Teknologi Digital dan Pertanian Presisi</h3>\n<p><strong>Digitalisasi pertanian</strong> melalui aplikasi mobile, sensor IoT, dan <strong>precision agriculture</strong> membuka peluang sekaligus tantangan baru. Di satu sisi, teknologi digital dapat meningkatkan efisiensi produksi dan akses pasar petani kecil. Di sisi lain, <strong>digital divide</strong> dapat memperdalam kesenjangan antara petani yang memiliki akses teknologi dan yang tidak.</p>\n<p><strong>Platform digital</strong> seperti TaniHub, iGrow, dan Crowde mengintegrasikan petani dalam <strong>ekonomi digital</strong>, namun juga menciptakan <strong>ketergantungan baru</strong> pada infrastruktur teknologi dan algoritma yang dikontrol korporasi. Hal ini mencerminkan <strong>subsumsi riil</strong> pertanian ke dalam logika kapital digital yang belum sepenuhnya diantisipasi dalam literatur agraria klasik.</p>\n<div class="article-key-takeaway"><div class="key-takeaway-label">Poin Penting</div><p>Transformasi agraria Indonesia menunjukkan kompleksitas empiris yang memvalidasi evolusi teoretis pertanyaan agraria, dari diferensiasi klasik hingga depeasantisasi kontemporer, sambil menghadirkan fenomena baru seperti financialization dan digitalisasi yang memerlukan pengembangan teoretis lebih lanjut.</p></div>\n<div class="article-back-to-section"><a href="#daftar-isi" class="back-to-top-link" aria-label="Kembali ke daftar isi">&uarr; Kembali ke Daftar Isi</a></div><h2 id="kesimpulan">Kesimpulan</h2>\n<p>Penelusuran evolusi pertanyaan agraria dari Kautsky hingga Bernstein mengungkapkan transformasi fundamental dalam memahami dinamika pedesaan dan nasib petani dalam kapitalisme global. <strong>Reformulasi pertanyaan agraria abad ke-21</strong> tidak lagi berpusat pada prediksi deterministik tentang hilangnya petani, melainkan pada analisis kompleks tentang modalitas transformasi agraria dalam era financialization, digitalisasi, dan integrasi rantai nilai global.</p>\n<p><strong>Kontribusi teoretis utama</strong> dari evolusi ini adalah pengakuan bahwa <strong>depeasantisasi</strong> merupakan proses yang kontradiktif dan tidak linear. Petani tidak sekadar menjadi korban pasif penetrasi kapital, melainkan <strong>subjek aktif</strong> yang mengembangkan strategi adaptasi, resistensi, dan transformasi. Konsep <strong>proletarisasi parsial</strong>, <strong>diversifikasi ekonomi</strong>, dan <strong>repeasantisasi</strong> memberikan nuansa pada pemahaman kita tentang persistensi dan transformasi ekonomi petani.</p>\n<p><strong>Kasus Indonesia</strong> memvalidasi kompleksitas teoretis ini dengan menunjukkan bahwa transformasi agraria melibatkan <strong>multiple pathways</strong> yang tidak dapat diprediksi melalui model tunggal. <strong>Fragmentasi lahan</strong> yang berkelanjutan, <strong>diversifikasi ekonomi</strong> rumah tangga petani, <strong>ekspansi agribisnis</strong> yang bersamaan dengan <strong>persistensi petani kecil</strong>, dan <strong>gerakan food sovereignty</strong> yang merespons liberalisasi menunjukkan dinamika yang kaya dan kontradiktif.</p>\n<p><strong>Implikasi praktis</strong> bagi gerakan petani dan serikat pekerja tani adalah perlunya <strong>strategi yang multi-dimensional</strong> dalam menghadapi transformasi agraria kontemporer. Perjuangan tidak dapat lagi terbatas pada <strong>redistribusi tanah</strong> klasik, melainkan harus mencakup <strong>kontrol atas teknologi</strong>, <strong>akses pasar yang adil</strong>, <strong>kedaulatan benih</strong>, dan <strong>demokratisasi sistem pangan</strong>. <strong>Aliansi strategis</strong> antara petani, buruh tani, masyarakat adat, dan gerakan lingkungan menjadi kunci dalam menghadapi dominasi kapital agraris yang semakin kompleks.</p>\n<p><strong>Rekomendasi untuk SEPETAK</strong> dan gerakan petani Indonesia meliputi: (1) <strong>Pengembangan kapasitas analitis</strong> untuk memahami dinamika rantai nilai global dan posisi petani di dalamnya; (2) <strong>Penguatan organisasi</strong> di tingkat lokal sambil membangun <strong>jaringan transnasional</strong> dengan gerakan petani global; (3) <strong>Advokasi kebijakan</strong> yang mendukung <strong>food sovereignty</strong> dan <strong>reforma agraria</strong> yang komprehensif; (4) <strong>Pengembangan alternatif ekonomi</strong> seperti <strong>pasar rakyat</strong>, <strong>koperasi produksi</strong>, dan <strong>teknologi ramah lingkungan</strong>; (5) <strong>Pendidikan politik</strong> yang mengintegrasikan analisis kelas dengan isu gender, lingkungan, dan kedaulatan pangan.</p>\n<p>Pertanyaan agraria abad ke-21 pada akhirnya adalah pertanyaan tentang <strong>jenis transformasi agraria</strong> yang kita inginkan: transformasi yang didominasi logika akumulasi kapital atau transformasi yang berpusat pada <strong>keadilan agraria</strong>, <strong>sustainability</strong>, dan <strong>kedaulatan rakyat</strong>. Jawaban atas pertanyaan ini tidak hanya menentukan nasib petani, melainkan juga karakter sistem pangan dan model pembangunan yang kita pilih untuk masa depan.</p>\n<div class="article-back-to-section"><a href="#daftar-isi" class="back-to-top-link" aria-label="Kembali ke daftar isi">&uarr; Kembali ke Daftar Isi</a></div><section class="article-bibliography"><h2 id="daftar-pustaka">Daftar Pustaka</h2>\n<p>Bernstein, H. (2010). <em>Class dynamics of agrarian change</em>. Fernwood Publishing.</p>\n<p>Brass, T. (2011). <em>Labour regime change in the twenty-first century: Unfreedom, capitalism and primitive accumulation</em>. Brill.</p>\n<p>Byres, T. J. (1991). The agrarian question and differing forms of capitalist agrarian transition: An essay with reference to Asia. In J. Breman &amp; S. Mundle (Eds.), <em>Rural transformation in Asia</em> (pp. 3-76). Oxford University Press.</p>\n<p>Chayanov, A. V. (1925). <em>The theory of peasant economy</em>. University of Wisconsin Press.</p>\n<p>Kautsky, K. (1899). <em>Die Agrarfrage: Eine Übersicht über die Tendenzen der modernen Landwirtschaft und die Agrarpolitik der Sozialdemokratie</em>. J. H. W. Dietz.</p>\n<p>Konsorsium Pembaruan Agraria. (2019). <em>Catatan akhir tahun 2018 konsorsium pembaruan agraria: Masa depan reforma agraria melampaui tahun politik</em>. KPA.</p>\n<p>Sachs, C. E. (2018). <em>Gendered fields: Rural women, agriculture, and environment</em>. Westview Press.</p>\n<p>Scott, J. C. (1976). <em>The moral economy of the peasant: Rebellion and subsistence in Southeast Asia</em>. Yale University Press.</p>\n<p>Scott, J. C. (1985). <em>Weapons of the weak: Everyday forms of peasant resistance</em>. Yale University Press.</p>\n<p>Van der Ploeg, J. D. (2008). <em>The new peasantries: Struggles for autonomy and sustainability in an era of empire and globalization</em>. Earthscan.</p>\n<p>White, B., &amp; Wiradi, G. (2012). <em>Agrarian and other transformations of the Indonesian countryside in the twentieth and early twenty-first centuries</em>. Indonesian Social Development Paper No. 2012-01. Indonesia Social Development Programme.</p>\n<p>Wolf, E. R. (1969). <em>Peasant wars of the twentieth century</em>. Harper &amp; Row.</p>\n</section><hr class="article-disclosure-divider"><aside class="article-disclosure"><p><em>Artikel ini disusun dengan bantuan kecerdasan buatan dan telah ditinjau oleh redaksi SEPETAK. Referensi yang dicantumkan adalah sumber nyata yang dapat diverifikasi. Pandangan dalam artikel ini tidak selalu mencerminkan posisi resmi organisasi.</em></p></aside>	published	2026-04-18 00:33:46	1	2026-04-18 00:31:53	2026-04-18 00:33:46	\N	auto_generated	6	7	t
\.


--
-- Data for Name: role_has_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_has_permissions (permission_id, role_id) FROM stdin;
1	1
2	1
3	1
4	1
5	1
6	1
7	1
1	2
2	2
3	2
4	2
5	2
6	2
7	2
1	3
2	3
3	3
4	3
5	3
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, guard_name, created_at, updated_at) FROM stdin;
1	superadmin	web	2026-04-16 15:33:55	2026-04-16 15:33:55
2	admin	web	2026-04-16 15:33:55	2026-04-16 15:33:55
3	operator	web	2026-04-16 15:33:55	2026-04-16 15:33:55
4	viewer	web	2026-04-16 15:33:55	2026-04-16 15:33:55
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions (id, user_id, ip_address, user_agent, payload, last_activity) FROM stdin;
1ESS0PhFd4zqvrLDGQvJhp25abhvPw3wRqt3Qtm4	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoibkFWWE9FZ1FrSE5GV0JjYnVKMTdsR3hoenhKZTJQd3JOTDZFcWNTQyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcva29udGFrIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776452836
ywdnZKn7FYiMesps1nWjiEFdXYA0NXGQZLZhRAkR	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTnd3M1lQaWZCU29vRmxiZlVWVDNHamFlMVhEdHI4MFhHZWtnYjRzVSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vc2VwZXRhay5vcmcvYXJ0aWtlbCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776446136
plMpTJTcrMdACuhpn7PmumXrQNeRwOVJ9zmIOLb7	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiNGJmTWFBTFZnMm5GdVZXRHZOWUhoWDMzdVI2WkxFZW4zSElzSFh6QiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvZ2FsZXJpIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776447381
Z7nSradMy1iajBL9e02UORBSRTYpL5CQbcjNZp2S	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQk9FamlRU0ZkNTRINDJ0dXJxUnVUdWxGanNWVFJ3QThKcUo4aVY0cSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvZ2FsZXJpIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776447488
eYbrpAvT0hvM74i15103rIxrfL8112Wh61IeYp1N	\N	72.61.143.92	curl/8.14.1	YToyOntzOjY6Il90b2tlbiI7czo0MDoiUnRzclRMUmpWSXJJQVZOeEhwZHp6M0hRMDZITGJRcFdrSzlpaml2YyI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776450226
uHDIjc0RHYsy9G7vWIwbRXliamXNYwmXGL6cDIie	\N	72.61.143.92	curl/8.14.1	YToyOntzOjY6Il90b2tlbiI7czo0MDoiVGJRTzcwTW40MEltY01pMjYzb1lNRnVLYXhPSjZmdDBYNno5dkN0QSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776451640
lKu6Bm2ZQhlQpNOBetpJ3Q99Urp6WmAYd4H03FBo	\N	72.61.143.92	curl/8.14.1	YToyOntzOjY6Il90b2tlbiI7czo0MDoib2FUREZlZGVLcml4Y3pIQlc4YkZWM21pa1FWc1hvc2dQQmNzc3hxdCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776452451
rNU2CvEH5vvmalZtF5f9W0Mu9ys1ENoFpdm8A2dz	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoibzBERkdGU0R1ajl2czVmeHd2c05mWkVvTkNwWlNZT2M5Njc5bXlxSSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc2VwZXRhay5vcmcvZGFmdGFyLWFuZ2dvdGEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776452451
XnANVHa7dLxRVIVTbz7sIfsnbi70YH96QO7nytWF	\N	72.61.143.92	curl/8.14.1	YToyOntzOjY6Il90b2tlbiI7czo0MDoiSFpnNmxub2pldnQ3YU9NZHY2RnFab3BicEF2RnZDc2luOGZpYzhDSiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776446533
y4XVOX6k9ITCqHu2i2By4W622KAL1LKaNx1wb67n	\N	72.61.143.92	curl/8.14.1	YToyOntzOjY6Il90b2tlbiI7czo0MDoidGlhNDZwOHZhaVpzTGtLSk5oYThDUEJFOFhSaXFiYlZlWUdBekF4USI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776447386
G9MGSjatGXyWbCcwUxN49ma57YmCmYjs0VZ4s1og	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiNW4wa3dXdVRvTE5sWjczd3UwR0x2Umo2NXdrWFZhR0xOMXI4dThIRCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvZ2FsZXJpIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776447496
VAs10tPARkWDX0bdLpFJSslxMdOebD48714oaTyD	\N	165.232.156.5	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiNkxuQU14T3pKVElyQ3NvUTl1VG1GRFg0NjNNRmRsZ0ZEemN2U0FaSyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776449815
mWyvKgrrUe3xoABkT92zfD0hMe3DhRPEoPmwVew8	\N	72.61.143.92	curl/8.14.1	YToyOntzOjY6Il90b2tlbiI7czo0MDoicVRYVWEzVlJWdFF4VmxwdVRmbGtja2NndDVhRk1UTHJjdndscXlDbyI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776450226
JvImCsavWfkIlTU3AVxJ5bkfRwq5ubrcQ4GHjaBh	\N	72.61.143.92	curl/8.14.1	YToyOntzOjY6Il90b2tlbiI7czo0MDoiYlZpREN6ckpxTGh5VW5uUGRUdkExbWkwVlZRcm1qTWlLU1BZNHh5ayI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776451640
Jf17e8330UsZdpHnA9u4paZabD2Vxp8OEBdAQW3N	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSTk5WkhoRVVwM25vc2djdjA5SEg4eTNUU3dHYzlmVFV5eVROV0VFcSI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czoxOToiaHR0cHM6Ly9zZXBldGFrLm9yZyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776452463
6Dua2smQ9razt8NPmrXfwHziLOoqydVMZkP2S8aF	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoib3V2NjJqWlZVMjgxeGJudTZ4QTU3Zm5aa2dIemhkZVNseGlqMmxTcSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTE3OiJodHRwczovL3NlcGV0YWsub3JnL2FydGlrZWwvYWt1bXVsYXNpLW1lbGFsdWktcGVyYW1wYXNhbi10ZW9yaS1kYXZpZC1oYXJ2ZXktZGFuLXJlYWxpdGFzLWtvbmZsaWstYWdyYXJpYS1kaS1pbmRvbmVzaWEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776446533
PSD1bemYiir4npNWcHehr4KPsMTo5cVu21e1qOeB	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoidUZkMW1jVFoxd0pqQjY1QVRzNHAwcldtZ0tIbkFWVThtbjRQcUpGQyI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czoxOToiaHR0cHM6Ly9zZXBldGFrLm9yZyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776447409
LYa7YElVp2y3fMbr5HluIJeg5mKd0GAasxeYRU2w	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQ3lTTUVWWE9keW9aTFJucVRvekhHcHIxQnZIVE9rellNQkZRS3d6SCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvZ2FsZXJpIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776447503
PLDG1eNP3y1768gEf7TL6R6599yAnZ8PXKqb2b2M	\N	72.61.143.92	curl/8.14.1	YToyOntzOjY6Il90b2tlbiI7czo0MDoiYU5yYmVadlpTTHM0dXl2Mmt2RjBPM3ZFdzRtVWU5NGhFSHlYeFc5eSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776450133
gTcjUj42ueED2SBuDf0iCiMw0Tqf4Vnfs1yZ6i27	\N	72.61.143.92	curl/8.14.1	YToyOntzOjY6Il90b2tlbiI7czo0MDoiRjYxeTNSaENkemE0ZzkxNjM2QnlNTkFrRjVoWVE2dlZJaWRNaWVkVCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776450226
OYv2WfAma8XQXmSAvgy5FJ2UwXf3eoYIbDPh597f	\N	72.61.143.92	curl/8.14.1	YToyOntzOjY6Il90b2tlbiI7czo0MDoiQWcxRjBrbjNSOG9KTndHNnlmandSMmx4cnRvU2VGMU95R2xacDdMUiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776451640
mWjTap0piPe5kdADbsK979R1iHzdrCfw18hIgu33	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQ25hVmlGZTJaNHFtc2o0cnYzbzZvME1rckpsdUNPZHRmamM1VnpLSSI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czoxOToiaHR0cHM6Ly9zZXBldGFrLm9yZyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776448011
T2wzbUG9Tcfws7qw9c9wAWnzAz8CmkVXpc8Hod7R	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiaVVoMWowQ05FemZrcmdqNHZQbzJ2bWs2Z3ZscHQyTkg5UVNqR1MzZCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTQxOiJodHRwczovL3NlcGV0YWsub3JnL2FydGlrZWwvcGVydGFueWFhbi1hZ3JhcmlhLWFiYWQta2UtMjEtZGFyaS1rYXV0c2t5LWhpbmdnYS1iZXJuc3RlaW4tZGFuLXJlbGV2YW5zaW55YS1iYWdpLXRyYW5zZm9ybWFzaS1wZWRlc2Fhbi1pbmRvbmVzaWEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776450134
SjwQTI8yXNjPBCseeIiyIXmVTKMtCkr5fS44P1Kx	\N	72.61.143.92	curl/8.14.1	YToyOntzOjY6Il90b2tlbiI7czo0MDoiOW9BRDNUTkVXWVl6UWRPYXU2eGFieDBmSmUxeDcwYWkzOE9FRzJvMyI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776450226
T7oaettXatVx8TZOUlxR5KTsChuN6BMhppivYhJV	\N	72.61.143.92	curl/8.14.1	YToyOntzOjY6Il90b2tlbiI7czo0MDoiUGxjMjVyWXlmSEJtVE8zM2xqMThEWExtam1rMEdyOVZTVHlGNEx6MCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776451646
voIIn1rX9TaBOd8C2emySFq168fCSWzVXTDEA9IE	1	45.198.11.249	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	YTo3OntzOjY6Il90b2tlbiI7czo0MDoiTUJtbFNNUUltOHdNRXNHSlhwVHZ2blhTVlFjRGxBUlFTazJTbHE2USI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO3M6MTc6InBhc3N3b3JkX2hhc2hfd2ViIjtzOjYwOiIkMnkkMTIkWHV2VGJtTWk2SlNEMEJIay8xZXJCZXIxQkNhNWtjaW1BRzZNL0JId2poRDJRdlRZazFFaWEiO3M6NjoidGFibGVzIjthOjI6e3M6NDE6IjE2ZDA1NjRjYThjNzc3NmEzMmMzMGEyNzU1ZGM5OGZhX3Blcl9wYWdlIjtzOjM6ImFsbCI7czo0MToiYzlhNTM5YmMxNTkyMWM5MjEwNzE1ZTZiOGUyOGNiZWRfcGVyX3BhZ2UiO3M6MjoiNTAiO31zOjg6ImZpbGFtZW50IjthOjA6e319	1776452952
PJLTyfNJ2Mqe9Psa5gQLErVPm1ZZj3X8quChiCXA	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZlk1SnhoRXlIdDJ6QmFOcHYzNU1EZ1RLR0tWUXlWT3VEVGhHTjgwMSI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czoxOToiaHR0cHM6Ly9zZXBldGFrLm9yZyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776448011
cKFHbq8mTFLPf0A1Ielha3k9kwyhu1TaERpvzlpa	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSUlkWURoM3RKVm41VmlpeFRFaDZFWnFoamFQcE15NG1pYXR1U1dJMyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vc2VwZXRhay5vcmcvc2l0ZW1hcC54bWwiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776450134
EPXaDdpCsonPWl4XjdnFaRri9qrbHhim5iA1RnHU	\N	72.61.143.92	curl/8.14.1	YToyOntzOjY6Il90b2tlbiI7czo0MDoiWHR4a0Z5VnBjYzc5YjRITU1ZeDhiOFN6cUtIbUpOZTU3Y2JBU1VoZiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776450226
euCjHIR0orxtx96w3KQq3yj8pvxyIfJmc2av3SDg	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoid0phWXRHV280RlphcTlNbTh3aUVQaUl0RlYycE5vMmp5bVBGaFhzaiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcva29udGFrIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776451653
ieNFSXybtsAZCZcU3LCB4guRWZWSl8Q1VXodjaPL	\N	72.61.143.92	curl/8.14.1	YToyOntzOjY6Il90b2tlbiI7czo0MDoiR0l2OWlnZGVRUkp2dFY1T3BDUlVZb1diM1BGa3E2M1pyUVBWVDRKcCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776452663
oJVaP4g9YJXzTgafyNmKMLXyWL2ozg9ruwg3B6Ry	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiekFxREg2RUdyS25XNVpDVklnRjJQcVJ2bURsZzNQRlFxUHFTWmF5RSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc2VwZXRhay5vcmcvZGFmdGFyLWFuZ2dvdGEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776452663
bCiQZIuFn9Q9XuUg2z69hG4pLAQY2u8fLZL0OMQq	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQ1RRYXJhdmg5SjZub3dhSEMzRTdERXRHeXFhOEx1RU80STZpcVZ1aSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776450134
Ame2J4hZYUXlw7pxbto7FFTkru2sKJLKh7qT9vYk	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiOEh6NkJScTVLUHJVeG1pU0trYWg5TW51RDZFWXo1MnJwU1JiTzFjRCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvYWdlbmRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776451653
r3CnmdNEQncNn67Yx6rBocXaJsDUbxjkk4W0opt0	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiYXE1cmJLRUt4TDJ2eW1YOFFONmFSdGNpRXVydWY4SmpaZGxQSkExRSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTQxOiJodHRwczovL3NlcGV0YWsub3JnL2FydGlrZWwvcGVydGFueWFhbi1hZ3JhcmlhLWFiYWQta2UtMjEtZGFyaS1rYXV0c2t5LWhpbmdnYS1iZXJuc3RlaW4tZGFuLXJlbGV2YW5zaW55YS1iYWdpLXRyYW5zZm9ybWFzaS1wZWRlc2Fhbi1pbmRvbmVzaWEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776448019
N6AlJHrkL4wFLP56PP1Al7gWZeDVgpyNteF96QCt	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTFNNYTNlcHNjdDBqbW9sbGxLQzdpcEs2ckgzaFIyallYZUFzN3ROUiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc2VwZXRhay5vcmcvZGFmdGFyLWFuZ2dvdGEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776452717
uUvJWhpGieLa7dHEdWagOIr4ABXCCfRwXKkjOnil	\N	116.203.34.44	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.9 Safari/536.5	YTozOntzOjY6Il90b2tlbiI7czo0MDoiazkxa3B3TmU0dXF5Rmt4TUR0NnI3MTg5UXRHOFNESTJEZUtYdkpDUSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776451911
beAKqBYNfl08gztHP79f1YSjCUDgrkfWZ04zwSk0	\N	72.61.143.92	curl/8.14.1	YToyOntzOjY6Il90b2tlbiI7czo0MDoiZlhwWHl1UXp1OTZLU01mWERFMk0xVlc2S0o4aFJGcWE3bW45TTVVaiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776450134
MZ9GZEW3fb97bzoBzBJAhdOssqC0zXslTuyo206j	\N	72.61.143.92	curl/8.14.1	YToyOntzOjY6Il90b2tlbiI7czo0MDoiZTZFVlFmbjFnenVHRjlOaHVtTE10eGlmNVk1ZlBKUlZNU21iS2dUWCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776450134
\.


--
-- Data for Name: site_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.site_settings (id, setting_key, setting_value, group_name, created_at, updated_at) FROM stdin;
1	site_name	SEPETAK - Serikat Pekerja Tani Karawang	umum	2026-04-16 15:32:51	2026-04-18 01:59:44
2	site_tagline	Rebut Kedaulatan Agraria, Bangun Industrialisasi Pertanian	umum	2026-04-16 15:32:51	2026-04-18 01:59:44
3	site_description	SEPETAK (Serikat Pekerja Tani Karawang) adalah organisasi massa berbasis pekerja tani dan nelayan di Kabupaten Karawang, Jawa Barat, yang memperjuangkan TANI MOTEKAR (Tanah, Infrastruktur, Modal, Teknologi, Akses Pasar) sejak 10 Desember 2007.	umum	2026-04-16 15:32:51	2026-04-18 01:59:44
20	founded_year	2007	umum	2026-04-18 01:59:44	2026-04-18 01:59:44
4	contact_email	info@sepetak.org	kontak	2026-04-16 15:32:51	2026-04-18 01:59:44
9	social_twitter	\N	sosial	2026-04-16 15:32:51	2026-04-18 01:59:44
21	social_youtube	\N	sosial	2026-04-18 01:59:44	2026-04-18 01:59:44
22	social_tiktok	\N	sosial	2026-04-18 01:59:44	2026-04-18 01:59:44
23	seo_default_og_image	\N	seo	2026-04-18 01:59:44	2026-04-18 01:59:44
24	seo_robots	\N	seo	2026-04-18 01:59:44	2026-04-18 01:59:44
25	seo_google_site_verification	\N	seo	2026-04-18 01:59:44	2026-04-18 01:59:44
5	contact_phone	+6281382605030	kontak	2026-04-16 15:32:51	2026-04-18 02:01:19
6	contact_address	Perumahan Johar Indah, Blok J No 20, Kel. Adiarsa Timur, Kecamatan Karawang Tmur, Kabupaten Karawang, Jawa Barat, Indonesia	kontak	2026-04-16 15:32:51	2026-04-18 02:01:19
8	social_instagram	https://www.instagram.com/sepetak_official	sosial	2026-04-16 15:32:51	2026-04-18 02:02:26
7	social_facebook	https://www.facebook.com/sepetak.org/	sosial	2026-04-16 15:32:51	2026-04-18 02:02:26
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tags (id, name, slug, created_at, updated_at) FROM stdin;
1	Karl Marx	karl-marx	2026-04-17 23:03:44	2026-04-17 23:03:44
2	Friedrich Engels	friedrich-engels	2026-04-17 23:03:44	2026-04-17 23:03:44
3	Antonio Gramsci	antonio-gramsci	2026-04-17 23:03:44	2026-04-17 23:03:44
4	David Harvey	david-harvey	2026-04-17 23:03:44	2026-04-17 23:03:44
5	Reforma Agraria	reforma-agraria	2026-04-17 23:03:44	2026-04-17 23:03:44
6	Konflik Agraria	konflik-agraria	2026-04-17 23:03:44	2026-04-17 23:03:44
7	Materialisme Historis	materialisme-historis	2026-04-17 23:03:44	2026-04-17 23:03:44
8	Kapitalisme	kapitalisme	2026-04-17 23:03:44	2026-04-17 23:03:44
9	Neoliberalisme	neoliberalisme	2026-04-17 23:03:44	2026-04-17 23:03:44
10	Hegemoni	hegemoni	2026-04-17 23:03:44	2026-04-17 23:03:44
11	Petani	petani	2026-04-17 23:03:44	2026-04-17 23:03:44
12	Buruh Tani	buruh-tani	2026-04-17 23:03:44	2026-04-17 23:03:44
13	Ekologi Politik	ekologi-politik	2026-04-17 23:03:44	2026-04-17 23:03:44
14	Hak Atas Tanah	hak-atas-tanah	2026-04-17 23:03:44	2026-04-17 23:03:44
15	Post-Development	post-development	2026-04-17 23:03:44	2026-04-17 23:03:44
16	Subaltern	subaltern	2026-04-17 23:03:44	2026-04-17 23:03:44
17	Akumulasi Primitif	akumulasi-primitif	2026-04-17 23:03:44	2026-04-17 23:03:44
18	Kedaulatan Pangan	kedaulatan-pangan	2026-04-17 23:03:44	2026-04-17 23:03:44
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, name, email, email_verified_at, password, remember_token, is_active, last_login_at, created_at, updated_at, deleted_at) FROM stdin;
1	Redaksi SEPETAK	admin@sepetak.org	\N	$2y$12$XuvTbmMi6JSD0BHk/1erBer1BCa5kcimAG6M/BHwjhD2QvTYk1Eia	9YoYcNSiekiE7fA8Eg0dgCsqSHmfDQLzyuDGBeZshSU9CkuvLEo9pw7JiCox	t	\N	2026-04-16 15:32:51	2026-04-17 23:31:57	\N
28	Smoke Test	smoke-test@sepetak.local	\N	$2y$12$B/tpk5Jz8jV1qdQFJyE5TexJoUa2cgsmH40GgoaWus7xBFfqIp8K2	\N	t	\N	2026-04-17 02:08:25	2026-04-17 02:10:09	2026-04-17 02:10:09
2	Redaksi SEPETAK	redaksi@sepetak.org	\N	$2y$12$1kfq1dWXIBS3ct8laJV/leuqaBvBVLkALbcPmXfvVb8TZ/FHkeKai	\N	t	\N	2026-04-16 16:08:01	2026-04-17 00:32:25	\N
3	Akun Viewer SEPETAK	publik@sepetak.org	\N	$2y$12$D3/JPwe5cavrjMevfR1yV.ctz9qWAVfXPM2CTpQWWzGobOcB9GGPq	\N	t	\N	2026-04-16 16:08:01	2026-04-17 00:32:25	\N
\.


--
-- Name: addresses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.addresses_id_seq', 4, true);


--
-- Name: advocacy_actions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.advocacy_actions_id_seq', 36, true);


--
-- Name: advocacy_programs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.advocacy_programs_id_seq', 17, true);


--
-- Name: agrarian_case_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agrarian_case_files_id_seq', 1, false);


--
-- Name: agrarian_case_parties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agrarian_case_parties_id_seq', 31, true);


--
-- Name: agrarian_case_updates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agrarian_case_updates_id_seq', 1, false);


--
-- Name: agrarian_cases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agrarian_cases_id_seq', 43, true);


--
-- Name: article_generation_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.article_generation_logs_id_seq', 7, true);


--
-- Name: article_pools_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.article_pools_id_seq', 3, true);


--
-- Name: article_topics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.article_topics_id_seq', 15, true);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 1, false);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.categories_id_seq', 13, true);


--
-- Name: event_attendance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.event_attendance_id_seq', 5, true);


--
-- Name: events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.events_id_seq', 10, true);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, true);


--
-- Name: gallery_albums_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gallery_albums_id_seq', 1, false);


--
-- Name: gallery_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gallery_items_id_seq', 1, false);


--
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.jobs_id_seq', 10, true);


--
-- Name: media_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.media_id_seq', 15, true);


--
-- Name: member_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_documents_id_seq', 1, false);


--
-- Name: members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.members_id_seq', 50, true);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.migrations_id_seq', 32, true);


--
-- Name: pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pages_id_seq', 15, true);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.permissions_id_seq', 7, true);


--
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.posts_id_seq', 48, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.roles_id_seq', 4, true);


--
-- Name: site_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.site_settings_id_seq', 25, true);


--
-- Name: tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tags_id_seq', 18, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 161, true);


--
-- Name: addresses addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.addresses
    ADD CONSTRAINT addresses_pkey PRIMARY KEY (id);


--
-- Name: advocacy_actions advocacy_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.advocacy_actions
    ADD CONSTRAINT advocacy_actions_pkey PRIMARY KEY (id);


--
-- Name: advocacy_programs advocacy_programs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.advocacy_programs
    ADD CONSTRAINT advocacy_programs_pkey PRIMARY KEY (id);


--
-- Name: advocacy_programs advocacy_programs_program_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.advocacy_programs
    ADD CONSTRAINT advocacy_programs_program_code_unique UNIQUE (program_code);


--
-- Name: agrarian_case_files agrarian_case_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_case_files
    ADD CONSTRAINT agrarian_case_files_pkey PRIMARY KEY (id);


--
-- Name: agrarian_case_parties agrarian_case_parties_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_case_parties
    ADD CONSTRAINT agrarian_case_parties_pkey PRIMARY KEY (id);


--
-- Name: agrarian_case_updates agrarian_case_updates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_case_updates
    ADD CONSTRAINT agrarian_case_updates_pkey PRIMARY KEY (id);


--
-- Name: agrarian_cases agrarian_cases_case_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_cases
    ADD CONSTRAINT agrarian_cases_case_code_unique UNIQUE (case_code);


--
-- Name: agrarian_cases agrarian_cases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_cases
    ADD CONSTRAINT agrarian_cases_pkey PRIMARY KEY (id);


--
-- Name: article_generation_logs article_generation_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_generation_logs
    ADD CONSTRAINT article_generation_logs_pkey PRIMARY KEY (id);


--
-- Name: article_pool_topic article_pool_topic_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_pool_topic
    ADD CONSTRAINT article_pool_topic_pkey PRIMARY KEY (article_pool_id, article_topic_id);


--
-- Name: article_pools article_pools_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_pools
    ADD CONSTRAINT article_pools_pkey PRIMARY KEY (id);


--
-- Name: article_pools article_pools_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_pools
    ADD CONSTRAINT article_pools_slug_unique UNIQUE (slug);


--
-- Name: article_topic_tags article_topic_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_topic_tags
    ADD CONSTRAINT article_topic_tags_pkey PRIMARY KEY (article_topic_id, tag_id);


--
-- Name: article_topics article_topics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_topics
    ADD CONSTRAINT article_topics_pkey PRIMARY KEY (id);


--
-- Name: article_topics article_topics_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_topics
    ADD CONSTRAINT article_topics_slug_unique UNIQUE (slug);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: cache_locks cache_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cache_locks
    ADD CONSTRAINT cache_locks_pkey PRIMARY KEY (key);


--
-- Name: cache cache_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cache
    ADD CONSTRAINT cache_pkey PRIMARY KEY (key);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: categories categories_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_slug_unique UNIQUE (slug);


--
-- Name: event_attendance event_attendance_event_id_member_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_attendance
    ADD CONSTRAINT event_attendance_event_id_member_id_unique UNIQUE (event_id, member_id);


--
-- Name: event_attendance event_attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_attendance
    ADD CONSTRAINT event_attendance_pkey PRIMARY KEY (id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: gallery_albums gallery_albums_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gallery_albums
    ADD CONSTRAINT gallery_albums_pkey PRIMARY KEY (id);


--
-- Name: gallery_albums gallery_albums_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gallery_albums
    ADD CONSTRAINT gallery_albums_slug_unique UNIQUE (slug);


--
-- Name: gallery_items gallery_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gallery_items
    ADD CONSTRAINT gallery_items_pkey PRIMARY KEY (id);


--
-- Name: job_batches job_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_batches
    ADD CONSTRAINT job_batches_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: media media_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_pkey PRIMARY KEY (id);


--
-- Name: media media_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_uuid_unique UNIQUE (uuid);


--
-- Name: member_documents member_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_documents
    ADD CONSTRAINT member_documents_pkey PRIMARY KEY (id);


--
-- Name: members members_member_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_member_code_unique UNIQUE (member_code);


--
-- Name: members members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: model_has_permissions model_has_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_has_permissions
    ADD CONSTRAINT model_has_permissions_pkey PRIMARY KEY (permission_id, model_id, model_type);


--
-- Name: model_has_roles model_has_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_has_roles
    ADD CONSTRAINT model_has_roles_pkey PRIMARY KEY (role_id, model_id, model_type);


--
-- Name: pages pages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_pkey PRIMARY KEY (id);


--
-- Name: pages pages_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_unique UNIQUE (slug);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


--
-- Name: permissions permissions_name_guard_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_name_guard_name_unique UNIQUE (name, guard_name);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: post_category post_category_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_category
    ADD CONSTRAINT post_category_pkey PRIMARY KEY (post_id, category_id);


--
-- Name: post_tag post_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_tag
    ADD CONSTRAINT post_tag_pkey PRIMARY KEY (post_id, tag_id);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- Name: posts posts_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_slug_unique UNIQUE (slug);


--
-- Name: role_has_permissions role_has_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_pkey PRIMARY KEY (permission_id, role_id);


--
-- Name: roles roles_name_guard_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_guard_name_unique UNIQUE (name, guard_name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: site_settings site_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_settings
    ADD CONSTRAINT site_settings_pkey PRIMARY KEY (id);


--
-- Name: site_settings site_settings_setting_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_settings
    ADD CONSTRAINT site_settings_setting_key_unique UNIQUE (setting_key);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: tags tags_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_slug_unique UNIQUE (slug);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: jobs_queue_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX jobs_queue_index ON public.jobs USING btree (queue);


--
-- Name: media_model_type_model_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX media_model_type_model_id_index ON public.media USING btree (model_type, model_id);


--
-- Name: media_order_column_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX media_order_column_index ON public.media USING btree (order_column);


--
-- Name: model_has_permissions_model_id_model_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_has_permissions_model_id_model_type_index ON public.model_has_permissions USING btree (model_id, model_type);


--
-- Name: model_has_roles_model_id_model_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_has_roles_model_id_model_type_index ON public.model_has_roles USING btree (model_id, model_type);


--
-- Name: sessions_last_activity_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_last_activity_index ON public.sessions USING btree (last_activity);


--
-- Name: sessions_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_user_id_index ON public.sessions USING btree (user_id);


--
-- Name: advocacy_actions advocacy_actions_advocacy_program_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.advocacy_actions
    ADD CONSTRAINT advocacy_actions_advocacy_program_id_foreign FOREIGN KEY (advocacy_program_id) REFERENCES public.advocacy_programs(id) ON DELETE CASCADE;


--
-- Name: advocacy_actions advocacy_actions_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.advocacy_actions
    ADD CONSTRAINT advocacy_actions_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: advocacy_programs advocacy_programs_lead_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.advocacy_programs
    ADD CONSTRAINT advocacy_programs_lead_user_id_foreign FOREIGN KEY (lead_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: agrarian_case_files agrarian_case_files_agrarian_case_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_case_files
    ADD CONSTRAINT agrarian_case_files_agrarian_case_id_foreign FOREIGN KEY (agrarian_case_id) REFERENCES public.agrarian_cases(id) ON DELETE CASCADE;


--
-- Name: agrarian_case_parties agrarian_case_parties_agrarian_case_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_case_parties
    ADD CONSTRAINT agrarian_case_parties_agrarian_case_id_foreign FOREIGN KEY (agrarian_case_id) REFERENCES public.agrarian_cases(id) ON DELETE CASCADE;


--
-- Name: agrarian_case_updates agrarian_case_updates_agrarian_case_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_case_updates
    ADD CONSTRAINT agrarian_case_updates_agrarian_case_id_foreign FOREIGN KEY (agrarian_case_id) REFERENCES public.agrarian_cases(id) ON DELETE CASCADE;


--
-- Name: agrarian_case_updates agrarian_case_updates_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_case_updates
    ADD CONSTRAINT agrarian_case_updates_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: agrarian_cases agrarian_cases_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_cases
    ADD CONSTRAINT agrarian_cases_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: agrarian_cases agrarian_cases_lead_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_cases
    ADD CONSTRAINT agrarian_cases_lead_user_id_foreign FOREIGN KEY (lead_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: agrarian_cases agrarian_cases_updated_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_cases
    ADD CONSTRAINT agrarian_cases_updated_by_foreign FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: article_generation_logs article_generation_logs_article_pool_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_generation_logs
    ADD CONSTRAINT article_generation_logs_article_pool_id_foreign FOREIGN KEY (article_pool_id) REFERENCES public.article_pools(id) ON DELETE SET NULL;


--
-- Name: article_generation_logs article_generation_logs_article_topic_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_generation_logs
    ADD CONSTRAINT article_generation_logs_article_topic_id_foreign FOREIGN KEY (article_topic_id) REFERENCES public.article_topics(id) ON DELETE SET NULL;


--
-- Name: article_generation_logs article_generation_logs_post_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_generation_logs
    ADD CONSTRAINT article_generation_logs_post_id_foreign FOREIGN KEY (post_id) REFERENCES public.posts(id) ON DELETE SET NULL;


--
-- Name: article_pool_topic article_pool_topic_article_pool_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_pool_topic
    ADD CONSTRAINT article_pool_topic_article_pool_id_foreign FOREIGN KEY (article_pool_id) REFERENCES public.article_pools(id) ON DELETE CASCADE;


--
-- Name: article_pool_topic article_pool_topic_article_topic_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_pool_topic
    ADD CONSTRAINT article_pool_topic_article_topic_id_foreign FOREIGN KEY (article_topic_id) REFERENCES public.article_topics(id) ON DELETE CASCADE;


--
-- Name: article_topic_tags article_topic_tags_article_topic_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_topic_tags
    ADD CONSTRAINT article_topic_tags_article_topic_id_foreign FOREIGN KEY (article_topic_id) REFERENCES public.article_topics(id) ON DELETE CASCADE;


--
-- Name: article_topic_tags article_topic_tags_tag_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_topic_tags
    ADD CONSTRAINT article_topic_tags_tag_id_foreign FOREIGN KEY (tag_id) REFERENCES public.tags(id) ON DELETE CASCADE;


--
-- Name: article_topics article_topics_category_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_topics
    ADD CONSTRAINT article_topics_category_id_foreign FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE SET NULL;


--
-- Name: article_topics article_topics_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_topics
    ADD CONSTRAINT article_topics_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_logs audit_logs_actor_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_actor_id_foreign FOREIGN KEY (actor_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: event_attendance event_attendance_event_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_attendance
    ADD CONSTRAINT event_attendance_event_id_foreign FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: event_attendance event_attendance_member_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_attendance
    ADD CONSTRAINT event_attendance_member_id_foreign FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: events events_organizer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_organizer_id_foreign FOREIGN KEY (organizer_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: gallery_albums gallery_albums_author_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gallery_albums
    ADD CONSTRAINT gallery_albums_author_id_foreign FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: gallery_items gallery_items_gallery_album_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gallery_items
    ADD CONSTRAINT gallery_items_gallery_album_id_foreign FOREIGN KEY (gallery_album_id) REFERENCES public.gallery_albums(id) ON DELETE CASCADE;


--
-- Name: member_documents member_documents_member_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_documents
    ADD CONSTRAINT member_documents_member_id_foreign FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: members members_address_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_address_id_foreign FOREIGN KEY (address_id) REFERENCES public.addresses(id) ON DELETE SET NULL;


--
-- Name: members members_approved_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_approved_by_foreign FOREIGN KEY (approved_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: members members_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: members members_updated_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_updated_by_foreign FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: members members_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: model_has_permissions model_has_permissions_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_has_permissions
    ADD CONSTRAINT model_has_permissions_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: model_has_roles model_has_roles_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_has_roles
    ADD CONSTRAINT model_has_roles_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: pages pages_author_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_author_id_foreign FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: post_category post_category_category_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_category
    ADD CONSTRAINT post_category_category_id_foreign FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: post_category post_category_post_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_category
    ADD CONSTRAINT post_category_post_id_foreign FOREIGN KEY (post_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: post_tag post_tag_post_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_tag
    ADD CONSTRAINT post_tag_post_id_foreign FOREIGN KEY (post_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: post_tag post_tag_tag_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_tag
    ADD CONSTRAINT post_tag_tag_id_foreign FOREIGN KEY (tag_id) REFERENCES public.tags(id) ON DELETE CASCADE;


--
-- Name: posts posts_article_topic_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_article_topic_id_foreign FOREIGN KEY (article_topic_id) REFERENCES public.article_topics(id) ON DELETE SET NULL;


--
-- Name: posts posts_author_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_author_id_foreign FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: posts posts_generation_log_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_generation_log_id_foreign FOREIGN KEY (generation_log_id) REFERENCES public.article_generation_logs(id) ON DELETE SET NULL;


--
-- Name: role_has_permissions role_has_permissions_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_has_permissions role_has_permissions_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict h4GYfCR4xqn4Ewnw8nw7OMauOG2eGPrFp37zBnJRJt3SZwbLUW1oyjwQDp0Zaz0

