--
-- PostgreSQL database dump
--

\restrict v2IsFGoLtc2UHKmNdwgB9VbftfLqY0ZYoLG1wFmHiYiKPhQcfgCoCc8zWmaXgbd

-- Dumped from database version 17.9 (Debian 17.9-0+deb13u1)
-- Dumped by pg_dump version 17.9 (Debian 17.9-0+deb13u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: addresses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.addresses (
    id bigint NOT NULL,
    line_1 character varying(200),
    line_2 character varying(200),
    village character varying(100),
    district character varying(100),
    regency character varying(100),
    province character varying(100),
    postal_code character varying(10),
    latitude numeric(10,7),
    longitude numeric(10,7),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: addresses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.addresses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: addresses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.addresses_id_seq OWNED BY public.addresses.id;


--
-- Name: advocacy_actions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.advocacy_actions (
    id bigint NOT NULL,
    advocacy_program_id bigint NOT NULL,
    action_date date NOT NULL,
    action_type character varying(255) NOT NULL,
    notes text,
    outcome text,
    created_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT advocacy_actions_action_type_check CHECK (((action_type)::text = ANY ((ARRAY['meeting'::character varying, 'training'::character varying, 'campaign'::character varying, 'field_visit'::character varying, 'legal'::character varying, 'other'::character varying])::text[])))
);


--
-- Name: advocacy_actions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.advocacy_actions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: advocacy_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.advocacy_actions_id_seq OWNED BY public.advocacy_actions.id;


--
-- Name: advocacy_programs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.advocacy_programs (
    id bigint NOT NULL,
    program_code character varying(30) NOT NULL,
    title character varying(200) NOT NULL,
    description text NOT NULL,
    status character varying(255) DEFAULT 'planned'::character varying NOT NULL,
    start_date date,
    end_date date,
    lead_user_id bigint,
    location_text character varying(200),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    CONSTRAINT advocacy_programs_status_check CHECK (((status)::text = ANY ((ARRAY['planned'::character varying, 'active'::character varying, 'paused'::character varying, 'completed'::character varying])::text[])))
);


--
-- Name: advocacy_programs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.advocacy_programs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: advocacy_programs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.advocacy_programs_id_seq OWNED BY public.advocacy_programs.id;


--
-- Name: agrarian_case_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agrarian_case_files (
    id bigint NOT NULL,
    agrarian_case_id bigint NOT NULL,
    file_category character varying(80),
    label character varying(150),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: agrarian_case_files_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agrarian_case_files_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agrarian_case_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agrarian_case_files_id_seq OWNED BY public.agrarian_case_files.id;


--
-- Name: agrarian_case_parties; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agrarian_case_parties (
    id bigint NOT NULL,
    agrarian_case_id bigint NOT NULL,
    party_type character varying(255) NOT NULL,
    name character varying(200) NOT NULL,
    role character varying(150),
    contact character varying(150),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT agrarian_case_parties_party_type_check CHECK (((party_type)::text = ANY ((ARRAY['member'::character varying, 'community'::character varying, 'institution'::character varying, 'company'::character varying, 'government'::character varying, 'other'::character varying])::text[])))
);


--
-- Name: agrarian_case_parties_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agrarian_case_parties_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agrarian_case_parties_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agrarian_case_parties_id_seq OWNED BY public.agrarian_case_parties.id;


--
-- Name: agrarian_case_updates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agrarian_case_updates (
    id bigint NOT NULL,
    agrarian_case_id bigint NOT NULL,
    update_date date NOT NULL,
    summary text NOT NULL,
    next_step text,
    status character varying(255) NOT NULL,
    created_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT agrarian_case_updates_status_check CHECK (((status)::text = ANY ((ARRAY['reported'::character varying, 'under_review'::character varying, 'mediation'::character varying, 'legal_process'::character varying, 'resolved'::character varying, 'closed'::character varying])::text[])))
);


--
-- Name: agrarian_case_updates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agrarian_case_updates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agrarian_case_updates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agrarian_case_updates_id_seq OWNED BY public.agrarian_case_updates.id;


--
-- Name: agrarian_cases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agrarian_cases (
    id bigint NOT NULL,
    case_code character varying(30) NOT NULL,
    title character varying(200) NOT NULL,
    summary text NOT NULL,
    description text NOT NULL,
    location_text character varying(200),
    start_date date NOT NULL,
    status character varying(255) DEFAULT 'reported'::character varying NOT NULL,
    priority character varying(255) DEFAULT 'medium'::character varying NOT NULL,
    lead_user_id bigint,
    created_by bigint,
    updated_by bigint,
    closed_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    CONSTRAINT agrarian_cases_priority_check CHECK (((priority)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying, 'urgent'::character varying])::text[]))),
    CONSTRAINT agrarian_cases_status_check CHECK (((status)::text = ANY ((ARRAY['reported'::character varying, 'under_review'::character varying, 'mediation'::character varying, 'legal_process'::character varying, 'resolved'::character varying, 'closed'::character varying])::text[])))
);


--
-- Name: agrarian_cases_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agrarian_cases_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agrarian_cases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agrarian_cases_id_seq OWNED BY public.agrarian_cases.id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id bigint NOT NULL,
    actor_id bigint,
    action character varying(120) NOT NULL,
    subject_type character varying(120) NOT NULL,
    subject_id bigint NOT NULL,
    meta json,
    created_at timestamp(0) without time zone
);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: cache; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cache (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    expiration integer NOT NULL
);


--
-- Name: cache_locks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cache_locks (
    key character varying(255) NOT NULL,
    owner character varying(255) NOT NULL,
    expiration integer NOT NULL
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(120) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: event_attendance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_attendance (
    id bigint NOT NULL,
    event_id bigint NOT NULL,
    member_id bigint NOT NULL,
    attendance_status character varying(255) DEFAULT 'present'::character varying NOT NULL,
    notes character varying(200),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT event_attendance_attendance_status_check CHECK (((attendance_status)::text = ANY ((ARRAY['present'::character varying, 'absent'::character varying, 'excused'::character varying])::text[])))
);


--
-- Name: event_attendance_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.event_attendance_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: event_attendance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.event_attendance_id_seq OWNED BY public.event_attendance.id;


--
-- Name: events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.events (
    id bigint NOT NULL,
    title character varying(200) NOT NULL,
    description text NOT NULL,
    event_date timestamp(0) without time zone NOT NULL,
    location_text character varying(200),
    status character varying(255) DEFAULT 'planned'::character varying NOT NULL,
    organizer_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    CONSTRAINT events_status_check CHECK (((status)::text = ANY ((ARRAY['planned'::character varying, 'done'::character varying, 'canceled'::character varying])::text[])))
);


--
-- Name: events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.events_id_seq OWNED BY public.events.id;


--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: job_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.job_batches (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    total_jobs integer NOT NULL,
    pending_jobs integer NOT NULL,
    failed_jobs integer NOT NULL,
    failed_job_ids text NOT NULL,
    options text,
    cancelled_at integer,
    created_at integer NOT NULL,
    finished_at integer
);


--
-- Name: jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.jobs (
    id bigint NOT NULL,
    queue character varying(255) NOT NULL,
    payload text NOT NULL,
    attempts smallint NOT NULL,
    reserved_at integer,
    available_at integer NOT NULL,
    created_at integer NOT NULL
);


--
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.jobs_id_seq OWNED BY public.jobs.id;


--
-- Name: media; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.media (
    id bigint NOT NULL,
    model_type character varying(255) NOT NULL,
    model_id bigint NOT NULL,
    uuid uuid,
    collection_name character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    file_name character varying(255) NOT NULL,
    mime_type character varying(255),
    disk character varying(255) NOT NULL,
    conversions_disk character varying(255),
    size bigint NOT NULL,
    manipulations json NOT NULL,
    custom_properties json NOT NULL,
    generated_conversions json NOT NULL,
    responsive_images json NOT NULL,
    order_column integer,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: media_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.media_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: media_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.media_id_seq OWNED BY public.media.id;


--
-- Name: member_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_documents (
    id bigint NOT NULL,
    member_id bigint NOT NULL,
    document_type character varying(255) NOT NULL,
    title character varying(150),
    issued_at date,
    expires_at date,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT member_documents_document_type_check CHECK (((document_type)::text = ANY ((ARRAY['ktp'::character varying, 'kk'::character varying, 'card'::character varying, 'other'::character varying])::text[])))
);


--
-- Name: member_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_documents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: member_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_documents_id_seq OWNED BY public.member_documents.id;


--
-- Name: members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.members (
    id bigint NOT NULL,
    user_id bigint,
    member_code character varying(30) NOT NULL,
    full_name character varying(150) NOT NULL,
    gender character varying(255) NOT NULL,
    birth_place character varying(100),
    birth_date date,
    nik character varying(32),
    phone character varying(30),
    email character varying(150),
    address_id bigint,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    joined_at date,
    approved_at timestamp(0) without time zone,
    notes text,
    created_by bigint,
    updated_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    CONSTRAINT members_gender_check CHECK (((gender)::text = ANY ((ARRAY['male'::character varying, 'female'::character varying, 'other'::character varying])::text[]))),
    CONSTRAINT members_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'active'::character varying, 'inactive'::character varying, 'resigned'::character varying, 'deceased'::character varying])::text[])))
);


--
-- Name: members_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.members_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.members_id_seq OWNED BY public.members.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: model_has_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_has_permissions (
    permission_id bigint NOT NULL,
    model_type character varying(255) NOT NULL,
    model_id bigint NOT NULL
);


--
-- Name: model_has_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_has_roles (
    role_id bigint NOT NULL,
    model_type character varying(255) NOT NULL,
    model_id bigint NOT NULL
);


--
-- Name: pages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pages (
    id bigint NOT NULL,
    title character varying(200) NOT NULL,
    slug character varying(200) NOT NULL,
    body text NOT NULL,
    status character varying(255) DEFAULT 'draft'::character varying NOT NULL,
    published_at timestamp(0) without time zone,
    author_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    CONSTRAINT pages_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'published'::character varying, 'archived'::character varying])::text[])))
);


--
-- Name: pages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pages_id_seq OWNED BY public.pages.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permissions (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    guard_name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: post_category; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.post_category (
    post_id bigint NOT NULL,
    category_id bigint NOT NULL
);


--
-- Name: post_tag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.post_tag (
    post_id bigint NOT NULL,
    tag_id bigint NOT NULL
);


--
-- Name: posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.posts (
    id bigint NOT NULL,
    title character varying(200) NOT NULL,
    slug character varying(200) NOT NULL,
    excerpt text,
    body text NOT NULL,
    status character varying(255) DEFAULT 'draft'::character varying NOT NULL,
    published_at timestamp(0) without time zone,
    author_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    CONSTRAINT posts_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'published'::character varying, 'archived'::character varying])::text[])))
);


--
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.posts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.posts_id_seq OWNED BY public.posts.id;


--
-- Name: role_has_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_has_permissions (
    permission_id bigint NOT NULL,
    role_id bigint NOT NULL
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    guard_name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id character varying(255) NOT NULL,
    user_id bigint,
    ip_address character varying(45),
    user_agent text,
    payload text NOT NULL,
    last_activity integer NOT NULL
);


--
-- Name: site_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.site_settings (
    id bigint NOT NULL,
    setting_key character varying(120) NOT NULL,
    setting_value text,
    group_name character varying(80),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: site_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.site_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: site_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.site_settings_id_seq OWNED BY public.site_settings.id;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tags (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(120) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: tags_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tags_id_seq OWNED BY public.tags.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    remember_token character varying(100),
    is_active boolean DEFAULT true NOT NULL,
    last_login_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: addresses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.addresses ALTER COLUMN id SET DEFAULT nextval('public.addresses_id_seq'::regclass);


--
-- Name: advocacy_actions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.advocacy_actions ALTER COLUMN id SET DEFAULT nextval('public.advocacy_actions_id_seq'::regclass);


--
-- Name: advocacy_programs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.advocacy_programs ALTER COLUMN id SET DEFAULT nextval('public.advocacy_programs_id_seq'::regclass);


--
-- Name: agrarian_case_files id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_case_files ALTER COLUMN id SET DEFAULT nextval('public.agrarian_case_files_id_seq'::regclass);


--
-- Name: agrarian_case_parties id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_case_parties ALTER COLUMN id SET DEFAULT nextval('public.agrarian_case_parties_id_seq'::regclass);


--
-- Name: agrarian_case_updates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_case_updates ALTER COLUMN id SET DEFAULT nextval('public.agrarian_case_updates_id_seq'::regclass);


--
-- Name: agrarian_cases id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_cases ALTER COLUMN id SET DEFAULT nextval('public.agrarian_cases_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: event_attendance id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_attendance ALTER COLUMN id SET DEFAULT nextval('public.event_attendance_id_seq'::regclass);


--
-- Name: events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs ALTER COLUMN id SET DEFAULT nextval('public.jobs_id_seq'::regclass);


--
-- Name: media id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media ALTER COLUMN id SET DEFAULT nextval('public.media_id_seq'::regclass);


--
-- Name: member_documents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_documents ALTER COLUMN id SET DEFAULT nextval('public.member_documents_id_seq'::regclass);


--
-- Name: members id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members ALTER COLUMN id SET DEFAULT nextval('public.members_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: pages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pages ALTER COLUMN id SET DEFAULT nextval('public.pages_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: posts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts ALTER COLUMN id SET DEFAULT nextval('public.posts_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: site_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_settings ALTER COLUMN id SET DEFAULT nextval('public.site_settings_id_seq'::regclass);


--
-- Name: tags id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags ALTER COLUMN id SET DEFAULT nextval('public.tags_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: addresses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.addresses (id, line_1, line_2, village, district, regency, province, postal_code, latitude, longitude, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: advocacy_actions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.advocacy_actions (id, advocacy_program_id, action_date, action_type, notes, outcome, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: advocacy_programs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.advocacy_programs (id, program_code, title, description, status, start_date, end_date, lead_user_id, location_text, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: agrarian_case_files; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agrarian_case_files (id, agrarian_case_id, file_category, label, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agrarian_case_parties; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agrarian_case_parties (id, agrarian_case_id, party_type, name, role, contact, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agrarian_case_updates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agrarian_case_updates (id, agrarian_case_id, update_date, summary, next_step, status, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agrarian_cases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agrarian_cases (id, case_code, title, summary, description, location_text, start_date, status, priority, lead_user_id, created_by, updated_by, closed_at, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, actor_id, action, subject_type, subject_id, meta, created_at) FROM stdin;
\.


--
-- Data for Name: cache; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cache (key, value, expiration) FROM stdin;
sepetak_cachelivewire-rate-limiter:e7fb79ac980b65b907cb033a9edf4c14fc128ae1:timer	i:1776366542;	1776366542
sepetak_cachelivewire-rate-limiter:e7fb79ac980b65b907cb033a9edf4c14fc128ae1	i:1;	1776366542
sepetak_cachespatie.permission.cache	a:3:{s:5:"alias";a:4:{s:1:"a";s:2:"id";s:1:"b";s:4:"name";s:1:"c";s:10:"guard_name";s:1:"r";s:5:"roles";}s:11:"permissions";a:7:{i:0;a:4:{s:1:"a";i:1;s:1:"b";s:14:"manage-members";s:1:"c";s:3:"web";s:1:"r";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:1;a:4:{s:1:"a";i:2;s:1:"b";s:12:"manage-cases";s:1:"c";s:3:"web";s:1:"r";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:2;a:4:{s:1:"a";i:3;s:1:"b";s:15:"manage-advocacy";s:1:"c";s:3:"web";s:1:"r";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:3;a:4:{s:1:"a";i:4;s:1:"b";s:13:"manage-events";s:1:"c";s:3:"web";s:1:"r";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:4;a:4:{s:1:"a";i:5;s:1:"b";s:14:"manage-content";s:1:"c";s:3:"web";s:1:"r";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:5;a:4:{s:1:"a";i:6;s:1:"b";s:15:"manage-settings";s:1:"c";s:3:"web";s:1:"r";a:2:{i:0;i:1;i:1;i:2;}}i:6;a:4:{s:1:"a";i:7;s:1:"b";s:12:"manage-users";s:1:"c";s:3:"web";s:1:"r";a:2:{i:0;i:1;i:1;i:2;}}}s:5:"roles";a:3:{i:0;a:3:{s:1:"a";i:1;s:1:"b";s:10:"superadmin";s:1:"c";s:3:"web";}i:1;a:3:{s:1:"a";i:2;s:1:"b";s:5:"admin";s:1:"c";s:3:"web";}i:2;a:3:{s:1:"a";i:3;s:1:"b";s:8:"operator";s:1:"c";s:3:"web";}}}	1776452882
\.


--
-- Data for Name: cache_locks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cache_locks (key, owner, expiration) FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, name, slug, created_at, updated_at) FROM stdin;
1	Berita	berita	2026-04-16 15:32:51	2026-04-16 15:32:51
2	Advokasi	advokasi	2026-04-16 15:32:51	2026-04-16 15:32:51
3	Kegiatan	kegiatan	2026-04-16 15:32:51	2026-04-16 15:32:51
4	Pengumuman	pengumuman	2026-04-16 15:32:51	2026-04-16 15:32:51
5	Opini	opini	2026-04-16 15:32:51	2026-04-16 15:32:51
\.


--
-- Data for Name: event_attendance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.event_attendance (id, event_id, member_id, attendance_status, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.events (id, title, description, event_date, location_text, status, organizer_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- Data for Name: job_batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.job_batches (id, name, total_jobs, pending_jobs, failed_jobs, failed_job_ids, options, cancelled_at, created_at, finished_at) FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.jobs (id, queue, payload, attempts, reserved_at, available_at, created_at) FROM stdin;
\.


--
-- Data for Name: media; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.media (id, model_type, model_id, uuid, collection_name, name, file_name, mime_type, disk, conversions_disk, size, manipulations, custom_properties, generated_conversions, responsive_images, order_column, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: member_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.member_documents (id, member_id, document_type, title, issued_at, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.members (id, user_id, member_code, full_name, gender, birth_place, birth_date, nik, phone, email, address_id, status, joined_at, approved_at, notes, created_by, updated_by, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.migrations (id, migration, batch) FROM stdin;
1	0001_01_01_000000_create_users_table	1
2	0001_01_01_000001_create_cache_table	1
3	0001_01_01_000002_create_jobs_table	1
4	2025_01_01_000001_create_addresses_table	1
5	2025_01_01_000002_create_members_table	1
6	2025_01_01_000003_create_member_documents_table	1
7	2025_01_01_000004_create_agrarian_cases_table	1
8	2025_01_01_000005_create_agrarian_case_parties_table	1
9	2025_01_01_000006_create_agrarian_case_updates_table	1
10	2025_01_01_000007_create_agrarian_case_files_table	1
11	2025_01_01_000008_create_advocacy_programs_table	1
12	2025_01_01_000009_create_advocacy_actions_table	1
13	2025_01_01_000010_create_events_table	1
14	2025_01_01_000011_create_event_attendance_table	1
15	2025_01_01_000012_create_categories_table	1
16	2025_01_01_000013_create_tags_table	1
17	2025_01_01_000014_create_posts_table	1
18	2025_01_01_000015_create_post_category_table	1
19	2025_01_01_000016_create_post_tag_table	1
20	2025_01_01_000017_create_pages_table	1
21	2025_01_01_000018_create_site_settings_table	1
22	2025_01_01_000019_create_audit_logs_table	1
23	2026_04_16_153336_create_permission_tables	2
24	2026_04_16_154218_create_media_table	3
25	2026_04_16_160500_make_addresses_line_1_nullable	4
\.


--
-- Data for Name: model_has_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_has_permissions (permission_id, model_type, model_id) FROM stdin;
\.


--
-- Data for Name: model_has_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_has_roles (role_id, model_type, model_id) FROM stdin;
1	App\\Models\\User	1
3	App\\Models\\User	2
4	App\\Models\\User	3
\.


--
-- Data for Name: pages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pages (id, title, slug, body, status, published_at, author_id, created_at, updated_at, deleted_at) FROM stdin;
1	Tentang Kami	tentang-kami	<h2>Tentang SEPETAK</h2><p><strong>SEPETAK (Serikat Pekerja Tani Karawang)</strong> adalah organisasi massa berbasis pekerja tani dan nelayan yang bersifat terbuka di Kabupaten Karawang, Jawa Barat. SEPETAK didirikan melalui <strong>Kongres I pada 3–4 November 2007</strong> dan dideklarasikan pada <strong>10 Desember 2007</strong> di Karawang.</p><p>Sejak <strong>Kongres III tahun 2015</strong>, nama resmi organisasi berubah dari <em>Serikat Petani Karawang</em> menjadi <strong>Serikat Pekerja Tani Karawang</strong>. Perubahan nama ini menegaskan posisi anggota sebagai <em>pekerja</em> yang berdaulat atas alat produksi, sekaligus memperluas keanggotaan secara formal bagi pekerja tani penggarap, buruh tani, dan nelayan kecil pesisir.</p><h3>Konteks Kabupaten Karawang</h3><p>Karawang adalah daerah tingkat II di utara Jawa Barat, mencakup <strong>30 kecamatan, 297 desa, dan 12 kelurahan</strong> dengan luas daratan ±1.753,27 km² (3,73% luas Jawa Barat) dan wilayah laut ±4 mil × 57 km. Topografinya didominasi dataran rendah (&lt;200 mdpl); hanya tiga kecamatan di selatan yang berada pada ketinggian &gt;200 mdpl hingga lebih dari 1.000 mdpl. Karawang dikenal sebagai <strong>salah satu sentra padi nasional</strong> sekaligus kawasan industri yang berkembang sejak 1989.</p><p>Kombinasi ini membuat Karawang menghadapi tekanan agraria yang khas: di satu sisi ada sawah pangan dan pesisir nelayan, di sisi lain ada konversi lahan untuk zona industri, perumahan, dan infrastruktur. Konflik agraria di sini tidak selalu tampak sebagai konflik terbuka seperti di dataran tinggi, melainkan berlangsung melalui mekanisme pasar tanah dan praktik kepemilikan <em>absentee</em>.</p><h3>Sifat dan Bentuk Organisasi</h3><p>SEPETAK adalah <strong>organisasi tani berbasis massa dan bersifat terbuka</strong>. Kami tidak membatasi keanggotaan pada satu lapisan ekonomi tertentu — anggota SEPETAK datang dari berbagai lapisan sosial pedesaan Karawang, termasuk buruh tani (<em>landless-peasant</em>), petani penyakap (<em>landless-tenant</em>), petani pemilik lahan kecil, serta warga yang menggantungkan hidup dari laut, perikanan, dan pariwisata pesisir.</p><h3>Tujuan Organisasi</h3><ol><li>Mewujudkan masyarakat Karawang yang <strong>demokratis, berkeadilan sosial, dan berkedaulatan</strong>.</li><li>Membebaskan pekerja tani dari segala bentuk penindasan dan pembodohan untuk mencapai <strong>kesetaraan dalam bidang ekonomi, sosial, budaya, hukum, dan politik</strong>.</li><li>Memperkuat posisi pekerja tani dalam menentukan <strong>kebijakan politik, hukum, sosial, dan budaya</strong> demi terwujudnya kesejahteraan yang adil, makmur, dan merata.</li></ol><h3>Pokok-pokok Perjuangan</h3><ol><li>Terlibat aktif dan memimpin perjuangan pekerja tani dalam memperjuangkan hak-haknya.</li><li>Aktif dalam membangun, mendorong, dan memajukan kesadaran pekerja tani dan organisasi tani.</li><li>Mendorong dan memajukan kesejahteraan pekerja tani.</li><li>Aktif dalam kerja-kerja solidaritas dan perjuangan Rakyat tertindas lainnya.</li></ol><h3>Jaringan Perjuangan</h3><ul><li><strong>Nasional</strong>: SEPETAK adalah anggota <a href="https://kpa.or.id" target="_blank" rel="noopener"><strong>Konsorsium Pembaruan Agraria (KPA)</strong></a> — konsorsium yang menghimpun 173 organisasi gerakan tani, masyarakat adat, dan nelayan.</li><li><strong>Daerah</strong>: SEPETAK kerap dipercaya sebagai pelopor aliansi lintas sektor di Karawang. <strong>ALIANSI PERAK</strong> (Aliansi Pergerakan Rakyat Karawang) — gabungan SEPETAK dan beberapa serikat buruh — pernah menjadi warna kuat dalam kampanye isu agraria, sosial budaya, dan tekanan politik kepada pemerintah daerah.</li><li><strong>Lintas ormas lokal</strong>: SEPETAK juga menjalin relasi dengan berbagai LSM dan ormas Karawang seperti <strong>GMBI</strong> (Gerakan Masyarakat Bawah Indonesia) dan <strong>LMP</strong> (Laskar Merah Putih) melalui proses konsolidasi gagasan yang panjang.</li></ul>	published	2026-04-16 16:57:26	1	2026-04-16 15:32:51	2026-04-16 16:57:26	\N
2	Visi dan Misi	visi-misi	<h2>Visi</h2><p><strong>“Rebut Kedaulatan Agraria, Bangun Industrialisasi Pertanian.”</strong></p><p>Terwujudnya reforma agraria sejati, kedaulatan pangan, dan kesejahteraan pekerja tani serta nelayan Karawang yang berkeadilan sosial, berdaulat secara ekonomi, dan berkelanjutan secara ekologis.</p><h2>Program Perjuangan — TANI MOTEKAR</h2><p><strong>TANI MOTEKAR</strong> adalah program tuntutan dan platform perjuangan SEPETAK yang dirumuskan pada <strong>Kongres II tahun 2012</strong>. Akronim ini menyatakan lima pilar yang harus dikuasai pekerja tani agar kemandirian dan kesejahteraan benar-benar berpijak pada kontrol produksi sendiri:</p><ol><li><strong>T — Tanah</strong>: pokok dasar perjuangan; alat produksi utama yang harus dikuasai dan didistribusikan secara adil kepada pekerja tani.</li><li><strong>I — Infrastruktur</strong>: jalan desa, irigasi teknis, dan fasilitas pasca-panen sebagai prasyarat produksi pertanian rakyat yang efisien.</li><li><strong>M — Modal</strong>: bukan sekadar uang, tetapi seluruh input pertanian — benih, pupuk, dan alat-mesin pertanian — yang harus berada dalam kontrol pekerja tani, bukan korporasi.</li><li><strong>T — Teknologi</strong>: teknologi tepat guna yang meningkatkan produktivitas tanpa membuat pekerja tani tergantung pada pasokan eksternal.</li><li><strong>A — Akses Pasar</strong>: rantai pemasaran produk pertanian dan olahan lanjutan yang memutus praktik tengkulak eksploitatif melalui model pertukaran antar-organisasi di basis massa.</li></ol><p><em>TANI MOTEKAR sebagai jalan menuju Industrialisasi Pertanian</em> — industri yang diselenggarakan di sektor pertanian pedesaan, berlandaskan partisipasi penuh masyarakat, ketersediaan bahan baku lokal, kelestarian lingkungan, dan pengabdian pada kepentingan publik. Dengan begitu, pengembangan industri di Karawang tidak lagi semata-mata berarti <em>konversi sawah menjadi pabrik</em>, melainkan penguatan produksi pertanian rakyat hingga hilirnya.</p><h2>Misi</h2><ul><li>Memperjuangkan <strong>redistribusi tanah</strong> bagi pekerja tani tak bertanah dan penyelesaian konflik agraria struktural di Karawang.</li><li>Mendampingi pekerja tani dan nelayan dalam sengketa agraria, klaim kawasan hutan Perhutani, tuntutan ganti rugi gagal tanam, hingga kriminalisasi anggota.</li><li>Membangun kesadaran hukum agraria dan pendidikan kritis anggota melalui <strong>sekolah tani, diskusi dusun, dan propaganda internal</strong>.</li><li>Mendorong kebijakan pertanian dan perikanan daerah yang berpihak pada pekerja tani kecil dan nelayan tradisional — termasuk intervensi atas Perda RTRW dan perencanaan infrastruktur.</li><li>Membangun <strong>aliansi lintas sektor</strong> bersama serikat buruh, mahasiswa, dan gerakan masyarakat sipil (ALIANSI PERAK, KPA, dll.) untuk memperkuat gerakan agraria nasional.</li><li>Membangun model <strong>pertanian kolektif</strong> di desa-desa basis sebagai strategi mengakumulasi surplus produksi bagi pengambilalihan bertahap tanah <em>absentee</em>.</li><li>Menyediakan <strong>advokasi pelayanan publik</strong> bagi anggota — mulai dari pendampingan pelayanan PLN, layanan kesehatan (Jamkesda/Jamkesmas ke RSUD Karawang), hingga pendaftaran hak atas tanah — sebagai wujud nyata keberpihakan organisasi pada kesejahteraan anggota.</li></ul>	published	2026-04-16 16:57:26	1	2026-04-16 15:32:51	2026-04-16 16:57:26	\N
4	Sejarah SEPETAK	sejarah	<h2>Sejarah Singkat SEPETAK</h2><h3>Latar: Gerakan Tani Karawang Sebelum SEPETAK</h3><p>Gerakan tani di Karawang menggeliat kembali pada era pasca reformasi 1998. Pada momen itu, gagasan-gagasan progresif kaum muda mulai masuk ke pedesaan Karawang melalui dua jalur utama:</p><ul><li><strong>Serikat Tani Nasional (STN)</strong> — mengawali advokasi kasus tanah <em>Kuta Tandingan</em> di Kecamatan Telukjambe Barat dan mengorganisir petani di Desa Karang Jaya, Kecamatan Pedes. Advokasi ini sempat terhenti karena represi aparat dan perubahan situasi lokal, namun berhasil menyisakan pengalaman dan kader awal.</li><li><strong>NGO Duta Tani Karawang</strong> — fokus awalnya bukan pada konflik agraria, melainkan pada advokasi produksi pertanian (termasuk pengendalian hama terpadu). Dari Duta Tani inilah kemudian lahir <strong>Dewan Tani Karawang</strong>, sebuah organisasi tani lokal yang berbasis di Cilamaya Kulon, Cilamaya Wetan, dan Pakisjaya. Dewan Tani Karawang akhirnya pecah karena perbedaan pandangan internal, terutama soal penggabungan dengan organ tani nasional.</li></ul><p>Dari dua titik masuk berbeda ini, gagasan gerakan tani terus bergulir hingga akhirnya mengkristal menjadi <strong>Serikat Petani Karawang (SEPETAK)</strong>.</p><h3>Kongres I — 3–4 November 2007</h3><p>Kongres pertama diadakan di Karawang dan menghasilkan <strong>deklarasi pembentukan organisasi pada 10 Desember 2007</strong>. Basis awal adalah lima desa di Kecamatan <em>Cilamaya Kulon, Cilamaya Wetan, dan Pakisjaya</em> — wilayah yang sebelumnya menjadi basis Dewan Tani Karawang. Kongres I menetapkan Anggaran Dasar dan struktur organisasi: Kongres, Dewan Tani, Dewan Pimpinan Tani Kabupaten (DPTK), Dewan Pimpinan Tani Desa (DPTD), dan Kelompok Kerja (Pokja).</p><h3>Kongres II — 2012</h3><p>Kongres II merumuskan dua capaian strategis:</p><ol><li><strong>TANI MOTEKAR</strong> (Tanah, Infrastruktur, Modal, Teknologi, Akses Pasar) sebagai program tuntutan dan platform perjuangan.</li><li><strong>“Bangun Industrialisasi Pertanian”</strong> sebagai program perjuangan jangka panjang.</li></ol><p>Pasca Kongres II, SEPETAK melakukan pemetaan wilayah dan menetapkan <strong>lima kategori wilayah rawan konflik agraria</strong> di Karawang: (a) masyarakat desa hutan, (b) eks Tegalwaru landen, (c) sekitar zona industri, (d) wilayah pangan, dan (e) pesisir. Pemetaan ini menjadi basis prioritas organisasi dalam membangun Pokja dan DPTD baru.</p><h3>Kongres III — 2015</h3><p>Kongres III memutuskan <strong>perubahan nama resmi</strong> dari <em>Serikat Petani Karawang</em> menjadi <strong>Serikat Pekerja Tani Karawang</strong>. Perubahan ini menegaskan posisi anggota sebagai <em>pekerja</em> yang berdaulat atas alat produksi, bukan sekadar profesi turunan. Kongres III juga memperluas keanggotaan secara formal bagi pekerja tani penggarap (<em>landless-tenant</em>) dan nelayan kecil pesisir.</p><h3>Rangkaian Aksi Perjuangan</h3><ul><li><strong>Penolakan Penambangan Pasir Laut Tanjung Pakis (2008–2009)</strong> — advokasi nelayan, pedagang wisata pantai, dan warga terdampak; berhasil menghentikan kegiatan tambang dan melahirkan basis SEPETAK baru di pesisir utara.</li><li><strong>Penolakan Penambangan Batu Andesit Tegalwaru (2009–2010)</strong> — perlawanan terhadap industri ekstraktif di dataran selatan Karawang.</li><li><strong>Aksi Ganti Rugi Gagal Tanam Cilamaya (2011)</strong> — memperjuangkan kompensasi bagi anggota yang gagal panen.</li><li><strong>Aksi Lintas Sektor &amp; Solidaritas</strong> — SEPETAK rutin terlibat dalam aksi bersama serikat buruh dan mahasiswa di Karawang untuk tuntutan ekonomis seperti infrastruktur desa, perbaikan irigasi, dan bantuan musim kekeringan.</li><li><strong>Sengketa Teluk Jambe (2013)</strong> — gugatan perdata 350 hektare lahan tiga desa melawan PT Sumber Air Mas Pratama (SAMP, diakuisisi Agung Podomoro Land) hingga Mahkamah Agung.</li><li><strong>Aksi Tol Jakarta–Cikampek (11 Juli 2013)</strong> — pekerja tani SEPETAK menutup akses tol sebagai respons putusan yang tidak berpihak.</li><li><strong>Penolakan Revisi Perda RTRW Karawang</strong> — intervensi atas rencana perubahan tata ruang, khususnya perubahan status kawasan Cilamaya Wetan menjadi kawasan perkotaan yang mengancam lahan anggota.</li><li><strong>Advokasi Pelayanan Publik</strong> — pendampingan anggota dalam urusan PLN, rujukan layanan Jamkesda/Jamkesmas ke RSUD Karawang (aksi 2012 yang kemudian melahirkan hubungan kelembagaan dengan RSUD).</li><li><strong>Aksi BPN Karawang (27 Juli 2023)</strong> — ribuan pekerja tani bersama LBH Arya Mandalika mendaftarkan <strong>88 bidang tanah di 13 desa</strong> yang diklaim sebagai kawasan hutan Perhutani tanpa dokumen utuh.</li><li><strong>Pernyataan Sikap 1 Agustus 2023</strong> — melawan kriminalisasi anggota oleh FORKOPIMDA Karawang pasca aksi 27 Juli.</li><li><strong>Hari Tani Nasional 2025 (24 September 2025)</strong> — SEPETAK bersama 139 organisasi tani-nelayan di bawah KPA menuntut 24 agenda perbaikan struktural agraria di Jakarta.</li></ul><h3>Eksperimen Pertanian Kolektif Telukjaya</h3><p>Sebagai implementasi langsung dari TANI MOTEKAR, SEPETAK pernah membangun model <em>pertanian kolektif</em> di <strong>Desa Telukjaya, Kecamatan Pakisjaya</strong>. Skema kerjanya:</p><ol><li>Organisasi menyewa lahan dari tuan tanah <em>absentee</em>.</li><li>Organisasi menyediakan seluruh input produksi — benih, pupuk, obat-obatan, serta alat dan mesin pertanian — sehingga anggota tidak terjerat tengkulak.</li><li>Surplus produksi dikumpulkan untuk <strong>membeli tanah absentee secara bertahap</strong> dan menjadi aset kolektif organisasi.</li><li>Paralel, SEPETAK juga mengadvokasi pemerintah daerah untuk turut mengambil alih tanah absentee sebagai objek reforma agraria.</li></ol><p>Eksperimen ini sempat terhambat karena persoalan internal — sebagian pengurus DPTD setempat memakai hasil produksi untuk kepentingan pribadi, dan organisasi mengambil sikap tegas memberhentikan pihak yang bersangkutan. Pengalaman ini menjadi pelajaran penting tentang perlunya <strong>kaderisasi yang kuat, transparansi keuangan, dan kontrol kolektif</strong> pada setiap skema produksi.</p><p><em>Hingga hari ini, perjuangan SEPETAK tidak pernah berhenti.</em> <strong>Tanah untuk pekerja tani. Laut untuk nelayan. Keadilan untuk semua.</strong></p>	published	2026-04-16 16:57:26	1	2026-04-16 16:32:49	2026-04-16 16:57:26	\N
5	Struktur Organisasi	struktur-organisasi	<h2>Struktur Organisasi SEPETAK</h2><p>Struktur SEPETAK disusun berdasarkan Anggaran Dasar hasil Kongres I dan disempurnakan pada kongres berikutnya. Struktur dirancang agar pengambilan keputusan dilakukan secara kolektif dari tingkat dusun hingga kabupaten — <em>dari bawah ke atas</em>.</p><h3>1. Kongres</h3><p>Forum tertinggi pembuat dan pengambil keputusan. Dilaksanakan <strong>sekurang-kurangnya tiga tahun sekali</strong>. Peserta terdiri dari seluruh jajaran pimpinan SEPETAK di setiap tingkat struktur dan anggota yang mendapat rekomendasi Dewan Pimpinan.</p><h3>2. Dewan Tani</h3><p>Pembuat keputusan tertinggi setelah Kongres. Rapat dilaksanakan <strong>minimal satu kali dalam enam bulan</strong>. Anggota Dewan Tani:</p><ul><li>Seluruh jajaran Dewan Pimpinan Tani Kabupaten (DPTK).</li><li>Ketua atau perwakilan Pimpinan Tani Desa.</li><li>Anggota SEPETAK yang mendapat rekomendasi Dewan Pimpinan Tani.</li></ul><h3>3. Dewan Pimpinan Tani Kabupaten (DPTK)</h3><p>Badan pimpinan tertinggi di bawah Dewan Tani. Dipilih, diangkat, dan diberhentikan oleh Kongres untuk <strong>masa jabatan tiga tahun</strong>. DPTK adalah pimpinan harian dan pembuat keputusan harian organisasi.</p><p>Komposisi DPTK:</p><ul><li>Ketua Umum</li><li>Sekretaris Umum</li><li>Ketua Departemen dan staf, terdiri dari:<ol><li><strong>Departemen Internal</strong> — pengorganisasian, kaderisasi, keanggotaan.</li><li><strong>Departemen Advokasi dan Perjuangan Tani</strong> — advokasi hukum, kampanye, aksi massa.</li><li><strong>Departemen Dana dan Usaha</strong> — pengelolaan keuangan organisasi dan usaha produktif.</li><li><strong>Departemen Pendidikan, Penelitian, dan Propaganda</strong> — sekolah tani, riset, publikasi.</li></ol></li></ul><p>Seluruh kerja harian departemen dikoordinasi dan dikontrol oleh Sekretaris Umum.</p><h3>4. Dewan Pimpinan Tani Desa (DPTD)</h3><p>Struktur organisasi tertinggi di tingkat desa. Dibentuk melalui Konferensi atau Musyawarah Desa untuk <strong>masa jabatan dua tahun</strong>. Syarat pembentukan DPTD: <strong>minimal tiga Pokja telah terbentuk</strong> di desa tersebut. Komposisi: Ketua, Sekretaris, dan staf departemen.</p><h3>5. Kelompok Kerja (Pokja)</h3><p>Unit organisasi terkecil, terdiri dari <strong>minimal lima anggota SEPETAK</strong> dan berkedudukan di wilayah kerja 1–2 dusun. Pokja dipimpin seorang Koordinator yang dipilih oleh anggota. Tugas utama Pokja: mengkoordinasikan kerja anggota di wilayahnya dan memperluas keanggotaan ke dusun-dusun di sekitarnya.</p><h3>Dua Jalur Pengorganisasian</h3><p>Dalam praktik, SEPETAK menempuh <strong>dua jalur</strong> untuk membangun basis massa di sebuah wilayah baru:</p><ol><li><strong>Rekrutmen individu langsung</strong> — kader melakukan pendekatan satu-persatu hingga terkumpul 3–5 calon anggota di sebuah dusun, lalu membentuk Pokja.</li><li><strong>Pintu masuk konflik</strong> — pendekatan dimulai dari persoalan nyata yang dialami warga (konflik tanah, ganti rugi gagal tanam, tambang, dll.). Advokasi kolektif menjadi pengikat solidaritas yang kemudian dikonsolidasikan menjadi Pokja dan DPTD.</li></ol><p><em>Contoh historis:</em> Pembentukan Pokja di <strong>Dusun Cimahi, Desa Cikarang, Kecamatan Cilamaya Wetan pada 14 Februari 2012</strong> merupakan salah satu capaian penting yang menggabungkan kedua jalur di atas.</p><h3>Alur Rekruitmen Formal</h3><ol><li>Individu bergabung sebagai <strong>Anggota SEPETAK</strong>.</li><li>Jika ada <strong>3–5 anggota</strong> di satu dusun, bentuk <strong>Pokja</strong> dengan koordinator.</li><li>Jika terbentuk <strong>minimal tiga Pokja</strong> di satu desa, selenggarakan <strong>Konferensi / Musyawarah Desa</strong> untuk membentuk <strong>DPTD</strong>.</li><li>DPTD aktif memperluas basis ke dusun dan desa tetangga.</li></ol><h3>Catatan Kaderisasi</h3><p>Salah satu tantangan terberat organisasi adalah menghasilkan <strong>kader dari basis tani itu sendiri</strong>. Menjadi pengorganisir berarti memberikan waktu, tenaga, biaya, dan kadang keselamatan pribadi — sebuah beban yang sulit dipikul dari sektor tani yang ekonominya paling rentan. Karena itu SEPETAK terus menempatkan kaderisasi (sekolah tani, diskusi dusun, pendidikan publik) sebagai investasi jangka panjang organisasi.</p>	published	2026-04-16 16:57:26	1	2026-04-16 16:44:51	2026-04-16 16:57:26	\N
6	Wilayah Kerja & Pemetaan Konflik	wilayah-kerja	<h2>Wilayah Kerja dan Pemetaan Konflik Agraria</h2><p>Karawang adalah salah satu daerah paling padat persoalan agraria di Jawa Barat: wilayah dataran rendah yang sejak 1989 terus diubah menjadi zona industri, perumahan, dan jalan tol, sementara di saat yang sama tetap menjadi sentra padi nasional. Dalam laporan Konsorsium Pembaruan Agraria (KPA) 2011, terjadi <strong>163 konflik agraria</strong> di Indonesia — 60% di sektor perkebunan, 22% kehutanan, 13% infrastruktur, 4% tambang, 1% pesisir — dengan korban mencapai <strong>22 jiwa, 69.975 KK, dan 472.048 hektare lahan</strong>. Karawang berada dalam pusaran konflik ini.</p><p>Pasca Kongres II tahun 2012, SEPETAK menetapkan <strong>lima kategori wilayah rawan konflik agraria</strong> sebagai peta prioritas pengorganisasian:</p><h3>1. Wilayah Masyarakat Desa Hutan</h3><ul><li><strong>Pihak yang terlibat</strong>: Perum Perhutani, perusahaan tambang, swasta, militer, dan pemerintah.</li><li><strong>Jenis konflik</strong>: perampasan tanah, sengketa tapal batas, dan klaim kawasan wisata.</li></ul><h3>2. Wilayah Eks Tegalwaru Landen (Karawang Selatan)</h3><ul><li><strong>Pihak yang terlibat</strong>: swasta, operator zona industri, Perhutani, pemerintah.</li><li><strong>Jenis konflik</strong>: perampasan tanah dan sengketa tapal batas.</li></ul><h3>3. Wilayah Sekitar Zona Industri</h3><ul><li><strong>Pihak yang terlibat</strong>: pengembang zona industri, perumahan, pemerintah.</li><li><strong>Jenis konflik</strong>: perampasan tanah — konversi sawah produktif menjadi kawasan industri dan perumahan.</li></ul><h3>4. Wilayah Pangan (Sabuk Sawah Karawang)</h3><ul><li><strong>Pihak yang terlibat</strong>: tuan tanah absentee dan tuan tanah lokal.</li><li><strong>Jenis konflik</strong>: kepemilikan tanah absentee yang menjerat petani penggarap ke dalam sistem penyakapan (<em>sharecropping tenancy</em>) yang eksploitatif.</li></ul><h3>5. Wilayah Pesisir</h3><ul><li><strong>Pihak yang terlibat</strong>: Perhutani, swasta, perusahaan tambang pasir laut, pemerintah.</li><li><strong>Jenis konflik</strong>: kepemilikan absentee dan perampasan ruang hidup nelayan serta pedagang pariwisata pantai.</li></ul><h3>Strategi Pengorganisasian Sesuai Peta</h3><p>Pemetaan di atas menjadi pedoman SEPETAK dalam menentukan di desa mana Pokja perlu dibangun lebih dahulu, advokasi apa yang dijalankan sesuai karakter konflik, dan siapa mitra yang relevan. Lima desa basis awal di <strong>Cilamaya Kulon, Cilamaya Wetan, dan Pakisjaya</strong> masuk dalam wilayah pangan-pesisir; sementara wilayah selatan (Tegalwaru, Pangkalan) masuk kategori hutan &amp; ekstraktif.</p><p><em>Peta ini terus diperbarui</em> — setiap DPTD baru wajib melakukan pemetaan konflik agraria di desanya sebagai dasar kerja organisasi.</p>	published	2026-04-16 16:57:26	1	2026-04-16 16:44:51	2026-04-16 16:57:26	\N
3	Kontak	kontak	<h2>Hubungi Kami</h2><p>Untuk informasi lebih lanjut, permohonan pendampingan, kolaborasi lintas organisasi, atau kebutuhan data publik, silakan hubungi sekretariat SEPETAK:</p><ul><li><strong>Email resmi:</strong> info@sepetak.org</li><li><strong>Website:</strong> https://sepetak.org</li><li><strong>Alamat sekretariat:</strong> Kabupaten Karawang, Jawa Barat, Indonesia</li></ul><h3>Jalur Komunikasi</h3><ul><li><strong>Pendaftaran anggota baru</strong> — gunakan formulir online di <a href="/daftar-anggota">halaman pendaftaran anggota</a>. Setelah mendaftar, calon anggota akan dihubungi oleh Departemen Internal untuk verifikasi dan penempatan Pokja.</li><li><strong>Permohonan pendampingan kasus agraria</strong> — kirim ringkasan kasus (lokasi, pihak terlibat, kronologi, dokumen pendukung) ke email resmi. Akan ditangani oleh Departemen Advokasi dan Perjuangan Tani.</li><li><strong>Liputan media &amp; kerja sama publikasi</strong> — ajukan permohonan resmi via email dengan mencantumkan institusi, nama pewarta/perwakilan, serta topik peliputan atau kolaborasi. Akan ditangani oleh Departemen Pendidikan, Penelitian, dan Propaganda.</li><li><strong>Solidaritas dan donasi</strong> — untuk dukungan sumber daya atau solidaritas aksi, silakan konfirmasi terlebih dahulu via email agar SEPETAK dapat memberi rekening resmi dan peruntukan yang transparan.</li></ul><p><em>SEPETAK tidak memiliki hotline telepon resmi saat ini. Seluruh komunikasi resmi berjalan melalui email dan formulir di website.</em></p>	published	2026-04-16 16:57:26	1	2026-04-16 15:32:51	2026-04-16 16:57:26	\N
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.password_reset_tokens (email, token, created_at) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permissions (id, name, guard_name, created_at, updated_at) FROM stdin;
1	manage-members	web	2026-04-16 15:33:55	2026-04-16 15:33:55
2	manage-cases	web	2026-04-16 15:33:55	2026-04-16 15:33:55
3	manage-advocacy	web	2026-04-16 15:33:55	2026-04-16 15:33:55
4	manage-events	web	2026-04-16 15:33:55	2026-04-16 15:33:55
5	manage-content	web	2026-04-16 15:33:55	2026-04-16 15:33:55
6	manage-settings	web	2026-04-16 15:33:55	2026-04-16 15:33:55
7	manage-users	web	2026-04-16 15:33:55	2026-04-16 15:33:55
\.


--
-- Data for Name: post_category; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.post_category (post_id, category_id) FROM stdin;
\.


--
-- Data for Name: post_tag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.post_tag (post_id, tag_id) FROM stdin;
\.


--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.posts (id, title, slug, excerpt, body, status, published_at, author_id, created_at, updated_at, deleted_at) FROM stdin;
2	Perjuangan Reforma Agraria di Karawang	perjuangan-reforma-agraria-di-karawang	Reforma agraria merupakan inti dari perjuangan SEPETAK untuk mewujudkan keadilan bagi petani Karawang.	<p>Reforma agraria adalah redistribusi tanah dari tuan tanah kepada petani penggarap yang tidak memiliki lahan sendiri. Di Karawang, isu ini sangat krusial mengingat alih fungsi lahan pertanian yang terus terjadi.</p><p>SEPETAK aktif mendampingi petani dalam proses advokasi hukum, negosiasi dengan pemerintah daerah, dan kampanye kesadaran publik untuk mendorong pelaksanaan reforma agraria yang sejati.</p>	published	2026-04-13 16:57:26	1	2026-04-16 15:32:51	2026-04-16 16:57:26	\N
3	Kegiatan Pendampingan Petani 2025	kegiatan-pendampingan-petani-2025	Sepanjang tahun 2025, SEPETAK intensif melakukan pendampingan hukum dan pelatihan bagi petani anggota.	<p>Program pendampingan petani 2025 mencakup berbagai kegiatan mulai dari pelatihan hukum agraria, pendampingan kasus sengketa tanah, hingga lokakarya pertanian berkelanjutan.</p><p>Sebanyak ratusan petani di berbagai kecamatan di Karawang telah mendapat manfaat dari program ini. Kami berkomitmen untuk terus hadir dan mendampingi petani dalam setiap langkah perjuangan mereka.</p>	published	2026-04-09 16:57:26	1	2026-04-16 15:32:51	2026-04-16 16:57:26	\N
1	Selamat Datang di Website Resmi SEPETAK	selamat-datang-di-website-sepetak	Kami dengan bangga mempersembahkan website resmi SEPETAK (Serikat Pekerja Tani Karawang) sebagai pusat informasi perjuangan pekerja tani dan nelayan Karawang.	<p>Selamat datang di website resmi <strong>SEPETAK — Serikat Pekerja Tani Karawang</strong>. Melalui platform ini kami berbagi informasi, berita, dan perkembangan terkini seputar perjuangan hak-hak pekerja tani dan nelayan di Kabupaten Karawang, Jawa Barat.</p><p>SEPETAK berdiri sejak Kongres I pada 3–4 November 2007 dan dideklarasikan pada 10 Desember 2007 di Karawang. Sejak Kongres III, nama organisasi resmi berubah dari <em>Serikat Petani Karawang</em> menjadi <strong>Serikat Pekerja Tani Karawang</strong> untuk menegaskan bahwa kami adalah organisasi pekerja tani yang berdaulat, bukan sekadar kelompok profesi.</p><p>Website ini menjadi ruang digital bagi seluruh anggota dan simpatisan untuk tetap terhubung dengan gerakan reforma agraria yang kami perjuangkan bersama.</p>	published	2026-04-16 16:57:26	1	2026-04-16 15:32:51	2026-04-16 16:57:26	\N
\.


--
-- Data for Name: role_has_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_has_permissions (permission_id, role_id) FROM stdin;
1	1
2	1
3	1
4	1
5	1
6	1
7	1
1	2
2	2
3	2
4	2
5	2
6	2
7	2
1	3
2	3
3	3
4	3
5	3
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, guard_name, created_at, updated_at) FROM stdin;
1	superadmin	web	2026-04-16 15:33:55	2026-04-16 15:33:55
2	admin	web	2026-04-16 15:33:55	2026-04-16 15:33:55
3	operator	web	2026-04-16 15:33:55	2026-04-16 15:33:55
4	viewer	web	2026-04-16 15:33:55	2026-04-16 15:33:55
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions (id, user_id, ip_address, user_agent, payload, last_activity) FROM stdin;
p0haxmPMy8wGMsSbgo0QUU6veBBxV7JMFlGQ60Xu	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMU9TTWVXTzF2eVgzeUVPb3Q5ekNEYjU2TE5CeDhJaUFrWUtjNFN4TCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjU6Imh0dHA6Ly9zZXBldGFrLm9yZy9oZWFsdGgiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776360771
TGtwlXbf7O2D1Nch4oSGmRmvFEMmdLe5K7OY6daY	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZlNtUXhoTTJ4NzYyTjFTUGhQS0ZOUG40b09kTlBBRTh6d0N3aFRxbSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjU6Imh0dHA6Ly9zZXBldGFrLm9yZy9oZWFsdGgiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776360771
tMt4GCuEdH7mzxk7enweX5IFuaA9vY0SVU6Fb8R6	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoieFF0RzR1YmE1S0VST3poUHhZS2Z0eFlBRVRJMGNWMzZOWGtWY21sdSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvaGVhbHRoIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776360812
9nqgYiXtiqdY5oN9JjckBiSAevKpvOXCzcNCerqo	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiY29VWXdxRm5wOGVrQk0yN3VxeDByR2E2TnR4NkdLWFJseFJ1YTZ2bSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvaGVhbHRoIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776360812
iGNrKPcx8l9cv44A6Lorq3PRtBEJuHSJHUI2BNRB	\N	38.43.64.36	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZkozVWV5TlZEYnVlemVTbm5JaENOUVR1MlJjZGdwbHJCMFVYSEJpayI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vc2VwZXRhay5vcmcvYWRtaW4vbG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776365772
Dvp22FD18SPFO3c5bxnorlLZCnO7BE0uLimgDy0p	\N	103.4.250.57	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZFN6Z21MaEU1MkU1RXQ2VzVOdDlSeXY2VEtzVDZjN0RiT2FSTkw4NSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776360886
vfEKkaeyF8g6QZ3ACFh2EshpnZJt6iRGAIp7nwg4	\N	3.93.241.41	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiT1ppVXlNWmt1ZlFnOTc4YnRaZ21odkZNM3hOeTlIUjU0SVZVSVNGRiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776361126
VSSbtHsti4LVD8HiMtClgV2AuZD0O5olzbhV8vYv	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZHRkMWdjMHd3UEZGb1dhcm1GT05MSUw1S2kyZkRIcFVwZmxJM05IVCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776361155
0XR1sHLN8ws6B2WC3ykn7scvlFclY9UU52HtnXtL	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoidFhoZmdwTm5XWlZnVzAybEN4OFNFWVVOeHRsVThLdGQyR2xiUFhlQSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvYmVyaXRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776361155
MazWU4rmp84FdVs2eXZ3YvcrtkUnFVAZSy8gEXiA	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiN0xSb0E5WVZzMzVGWllRVmltV2E3MFdqdkVpc0ZQRFA4NjIzbU9ScyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc2VwZXRhay5vcmcvZGFmdGFyLWFuZ2dvdGEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776361155
weITyh4pyHwukoPzkPQFQyKrhXQtAlJ0NFPFgrDg	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiaHljM1J1SUswbGVSa3YxYmxuMFRVRDN6YWNQVWpDYU9KV3h6RmFKYiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDA6Imh0dHBzOi8vc2VwZXRhay5vcmcvaGFsYW1hbi90ZW50YW5nLWthbWkiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776361155
GP7xTFgzxaqyC4Mfy5TX39srctMwej5wxL3sCUpl	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiWW1OaDVtOVNCMWR6cmJ4WnFvSnJpbmNPeERVS2tLbEN1NW51Zlc3MSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzc6Imh0dHBzOi8vc2VwZXRhay5vcmcvaGFsYW1hbi92aXNpLW1pc2kiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776361155
adUkkgSB6A9L4Boeo3uIYccHuQEjoOSZXbW433OE	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiV3JCUEJkbFFzZUpsaGRkWWx6b0Nqd0VLYURFTkRYSmFWbTlKaXRZWCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzU6Imh0dHBzOi8vc2VwZXRhay5vcmcvaGFsYW1hbi9zZWphcmFoIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776361155
TnIoxUYaT3zMmZJAUNHtSTcPqGPWf4Cdhg2PGnEQ	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZHd4d1B1VXh3VlQzalRFVHZXWUtldEQ5TXpLQlBlbjVKWWVpRm55eCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDc6Imh0dHBzOi8vc2VwZXRhay5vcmcvaGFsYW1hbi9zdHJ1a3R1ci1vcmdhbmlzYXNpIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776361155
EmbcVtfkhBCK52jOaHnOEr2v1EvY5jK6xCXSkjQA	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQnVMenJReFh3RFhFcVZ4bkpuQmVjNmd6TFQwbkJ5SWlEN0pVR2o1NSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDE6Imh0dHBzOi8vc2VwZXRhay5vcmcvaGFsYW1hbi93aWxheWFoLWtlcmphIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776361155
WrssjNZXCSQ37m1HDBBmBd7LCMLEaCeM8db9G6zQ	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZjAxaG04TmRBWmJRZ2tsUm5FRmVpYnpqOTNxd05FcGZFS2x4SVE1diI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc2VwZXRhay5vcmcvaGFsYW1hbi9rb250YWsiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776361155
D89yv2gNlVsmcFXj9X0hSgeMGlsYrP09mzcaUUJ8	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoieGFaY01tM0UxYWg3VjNlZUJuQlZWUlVOWXFDdjUwWXlkbVdPdE91USI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vc2VwZXRhay5vcmcvc2l0ZW1hcC54bWwiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776361155
p19uItXZVs4Q2E564jtapbyJ8THAXuXRD9LwA4n4	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiejJtelI4T0RpeEt5aVhvY0xRUW9YdW5jRVE3OXdib0NVNUpya01DNSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjg6Imh0dHBzOi8vc2VwZXRhay5vcmcvZmVlZC54bWwiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776361155
StvTgAOQCbWIJOiSZyRegShLQev15WYG1YRlbgEZ	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUHNTemNxNFkwM1JzUjhyY1F2anV5aVZXQ2RyQVVPVU41c1lEZ0RHUyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vc2VwZXRhay5vcmcvYWRtaW4vbG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776361156
tCzRXB2g29fUUw5Myf0pkddb0zuR7SB2E7GUCXSM	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoidzdzcVByaXZrNmRwSmFKa1NXenRWVTUwRUtwSGxvUWd3UEhPQ0REVyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvaGVhbHRoIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776361156
0FgErECyhECgdT2ErPpEieP55GjSEdjYODvKMkWa	\N	3.230.125.58	got (https://github.com/sindresorhus/got)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSzV0MjRCZzFkdHJZTHM2U255NFNJSUVkTjJobkJXd1RzSGt2S3AxcyI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czoxOToiaHR0cHM6Ly9zZXBldGFrLm9yZyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776366183
34IFStsVTnsrnndlx4LE3VWOOM1YOaG1bbMoWFQI	\N	3.230.125.58	got (https://github.com/sindresorhus/got)	YToyOntzOjY6Il90b2tlbiI7czo0MDoiMzNtdU9aTUE3bDc1WW5FdFIzTjYwT1FRTUNmcmxrcGNRbGZ5NmJvYyI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776366183
ZTMyxtbM1jLVWxU5iDsYv9P7cCZMcpIsgPHhXQdU	\N	3.230.125.58	got (https://github.com/sindresorhus/got)	YTozOntzOjY6Il90b2tlbiI7czo0MDoid0VJT3F6emhJWjYwcXlMYk8xWFdCT2ttYTJtNjQyZFZQcVhnenA1VyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vc2VwZXRhay5vcmcvYWRtaW4vbG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776366185
Vo4I0vNtoTtS0N0HyDXtDIhIBXAybsiebUxoWW0h	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoib1J2Q3hYS21NUUoydmhDc1JHcmw2ZjkzU2pNdEZrZTBsY3NwWlpQdiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvaGVhbHRoIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776361197
DmLXSDshnp3DcCsrgRK97DVvqcD2WDBF3grCQqXR	1	45.198.11.249	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiaWlXTlRyYmpCOWlIY1c5MVVJbE5VVWRyWkQyOHVCcWRRM0tselBKdSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO3M6MTc6InBhc3N3b3JkX2hhc2hfd2ViIjtzOjYwOiIkMnkkMTIkWHV2VGJtTWk2SlNEMEJIay8xZXJCZXIxQkNhNWtjaW1BRzZNL0JId2poRDJRdlRZazFFaWEiO30=	1776366873
E30IBUWFWrlFX1M31o6GKxQGli5nfoEAlMxPS0LC	\N	72.61.143.92	curl/8.14.1	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiSzB5dGNjYXRSYW1Xa3VrQnl5VWFZRG4ybHU0QTV5QVZEU0VNMVJQUiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vc2VwZXRhay5vcmcvYWRtaW4vbG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjM6InVybCI7YToxOntzOjg6ImludGVuZGVkIjtzOjM4OiJodHRwczovL3NlcGV0YWsub3JnL2FkbWluL3Bvc3RzL2NyZWF0ZSI7fX0=	1776366515
lnJfj12duitO0GTLFA87nB7UEjg4RCTlivRcjvWb	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoidVZLNDIyMXBFZ2RLQ3ZRbnVxZmRnbnkybmhvMHBoRE4xUFN1dEx5cyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vc2VwZXRhay5vcmcvYWRtaW4vbG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776366629
YEZLhLkevJxrtMj1bPliOFWscCA1NKZdIFxnUrnI	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoicHY4ejZmMWp1b1RZRUp1WklHUnB4WDJSR0tqVkJCWkRjQUM4Q1J4ZyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776361197
0l4IBOftW3fBkIGo2HRKAaNjT45WtlRrIKG8SDra	\N	45.198.11.249	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVG1YZUZqdDZpMGlTOEJFOHF0d25NYkhyUW5pS2d1bnN4bG4wTWdTQyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776361201
0MKj1Jczv64gVo6MQBabnqc3dZYULpd4rDxJXi66	\N	35.165.215.140	Go-http-client/2.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoicmN1ZHloUTZPVEw0ZU1odkFRNWtoaldXbm8xeDNqS2pLcWdDTDFTRCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776361233
mFD5u0a08Mc04JJ84rjUf7CppEQ9ckSrZvKUPlwp	\N	35.165.215.140	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/142.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoicHBTSTV0N1ZUMUF6bTVtQ3hPWWlVeGNBQ3o4YXhlZ3FsaG1EWUV5SSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776361234
wJI5MxAZaYKf0uy5hEop05bqPBRmbK5vZ6Jx3a23	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiNEZKSmphZ3phS1NaaTY5dDZQYWIzQ2VzVnFvUmYxZjQyejQyYkR2eiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvaGVhbHRoIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776361290
Q0iv0MA7hxsVfblr8CTdH1uTT5SXyOpLjACgeyDg	\N	3.82.48.170	okhttp/5.3.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiS2J2ckpLUHBPMENYazRpU2JXdjVXejRMWWN2bnZ4SURiV3lEMDd4aiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776361493
X1yHlGJ1IO6Qwl52xSskpG0ZzmiXfNQ2CkfXpWFM	\N	3.82.48.170	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/138.0.7204.23 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiV0tuajBONXBjT2FOVkNKTkVXM2RHYW5waXRHTUdzUThjOHFYTERkaSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776361546
Yh4uAdfGumovYu9wmrPhUgrhXL80zZ1AYv3WoU2W	\N	54.159.55.108	axios/1.13.6	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUkVVWExmR05mcnI0VjhacHl3VDBFbURPRHkxeFpXT1JtaU9IYk5haSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776361825
nqw7lWizu8KV5xxyNK3uVUSkAFi83sGhNM7ypZ4Y	\N	54.159.55.108	axios/1.13.6	YTozOntzOjY6Il90b2tlbiI7czo0MDoidDc5b0xCV21vWjBHRmo0b3hRakxVQkxLVDdVN1BRcWQ4R1FmQ05ZNCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776361827
81X6biHqmmDqb2EE48lnSUr4q6MgEjHQuwf0rolQ	\N	8.230.113.214	Mozilla/5.0 (Linux; U; Android 10; en-US; CPH2015) AppleWebKit/537.36 (KHTML, like Gecko) UCBrowser/13.5.8.1311 Mobile Safari/537.36	YToyOntzOjY6Il90b2tlbiI7czo0MDoiZlJWWFloWmVZU3pKVjJKank1WVpnb3h2ZXNScFNWUW9PckczcWlkTSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776361918
LwrDEcjecxGZQVXf1EdiRjYH33BblSPkgBlFoo21	\N	3.93.238.235	okhttp/5.3.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiNGx3QmluUjhHRmRlZWlwVWdtUXNhOFg2SW1xN1BnaUp4ejhkMzN4ayI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776362274
vsaMHibjYHWlPrHV6fRIqe5FSiw6fKjpZoy1Orre	\N	3.93.238.235	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/138.0.7204.23 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUXRvQzJRZHVCVncyQnpMdzhoajdVbEZnWElyMDlnc0tPM1M4aDltOSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776362328
a03tKKqyLWavU3SFDVtsBoEEok46Ehh61jSgvCen	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoibUh1cTlLbDNUckZrUjl4dGtMVzZoNXFlcGpFcmJaaW5vMUxuem5GRyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776362853
lclZWq2W4DjFcD6MwbYFnUT8hzGxhDOFzQxYSuX1	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiN0doU1M4QTUxSmlGbW0xWTlmdXFKdWk5SEtxa2VoSDN6TlkzaFRsRCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvYmVyaXRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776362853
XCJzGuNKOUkLXZQy1eUAM3lXMpI9quGAQztvRG7k	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSnpDMHNmUVhGbllGRURGZHM4SUNJRzIxM3pybUFGdDloRjc2U3NaMyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDA6Imh0dHBzOi8vc2VwZXRhay5vcmcvaGFsYW1hbi90ZW50YW5nLWthbWkiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776362854
QBZbX1hza6gTSfzvvOTz1WuVeucZMGDS69WT18lo	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMkFyT2JaZEtxdnVHYUxXMUZMdThkcVluTFczSjA4SkY5RFljekFlNCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvaGVhbHRoIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776362854
LfcAxJFhQz2NTIkFdfTbnktGQpK6URfpgN2IWyGj	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoic1FiN0tBYjVxdDdIb0xlNE8yTGp2Q1BjVnA5RHMyNGY4RVE3ODhPdiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjg6Imh0dHBzOi8vc2VwZXRhay5vcmcvZmVlZC54bWwiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776362854
d2dM7llfhorNV8sadOuAmH9qRntR3kqAdbXcOrAC	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoicEV5TkJnaTJzZjMydHExeVdHU0tSYmtvM05FM3ZzZXp1UkNNcld1YSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc2VwZXRhay5vcmcvZGFmdGFyLWFuZ2dvdGEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776362864
lIraEjNUtH7HQg47ZwXHDvv79S7QXBgP6BTh81n8	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiT1l1ekVOanVETGFPaGs2TkdUbzFJaGI3N3JwR0tlUVowZkRpc1JIMiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776362909
n7EK778KPCvMM3nSqd2VFPnhz60dEql7oFzJb9sw	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiaWE5dEFjN25xMTExQUVha1hMQ0VnaDVpbTFRUUNXMzZQR2wyalFadiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvYmVyaXRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776362910
GeqCgmvQ4Ah20f81OV4RLhXefOSSECLLSaprxVhs	\N	3.230.125.58	got (https://github.com/sindresorhus/got)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZEdwNlBUYzRpZFBlMjU2VGZFUFRZc0V0QkdVcVdkN3J6TU5PM1JyeCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vc2VwZXRhay5vcmcvYWRtaW4vbG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776366184
vooixKTisXo68mQvjlZLeX8NzJuY2j5k6Y71tsDy	\N	72.61.143.92	curl/8.14.1	YToyOntzOjY6Il90b2tlbiI7czo0MDoiSDlQblJNWEdkZXFIUFB0aXp2TjlWY1lncTRsTVBTOUxSaEV2aGs5OSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776366484
BVBzSYzORGvZ6qh0W4fW6RUWoheIHMxDbc4QXonM	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiWkJJQmJSRU42RUNrRUdIdXRLdkpQSkl5ZG1oZk1Nd0owWEVuYXh6bCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc2VwZXRhay5vcmcvZGFmdGFyLWFuZ2dvdGEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776362910
dPVNOSACxgHkQo2DKG3P6Vpt9OMfrr2Wn0InZ0xw	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMWREVWx1eUtsZUFMbVFCOTJSRlc0VFlVNlN2dXVETUJRMGkxR1RlayI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDA6Imh0dHBzOi8vc2VwZXRhay5vcmcvaGFsYW1hbi90ZW50YW5nLWthbWkiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776362910
xa3q9gduMNkOZuvlc2mqX9CJGSNu2HKFD6TmjfKf	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiREs1SjRXVlI5cGxaQUZaUXNPdGhaRnF5aGZvTWFwTkNWRk5rNmpCUCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzU6Imh0dHBzOi8vc2VwZXRhay5vcmcvaGFsYW1hbi9zZWphcmFoIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776362910
KTWhDOmXxbeLqH5bi1yy7hBGcWSjf2Ri1WPPotdS	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTXZ3OXZBTXp2Qm96WTI0TkVsbjJTdUZodE8wQ0YwWDJwdHJYOGlDaiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDc6Imh0dHBzOi8vc2VwZXRhay5vcmcvaGFsYW1hbi9zdHJ1a3R1ci1vcmdhbmlzYXNpIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776362910
JPSFdEsEJFlf9mPAL3aXh8qnOJswmXe3URldCYyh	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVVhFU1oyckZzUHpISHhxV01sMEZQUVhQUXNmOUQyNzdUbVNSSlJXSSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzc6Imh0dHBzOi8vc2VwZXRhay5vcmcvaGFsYW1hbi92aXNpLW1pc2kiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776362910
doYUtxr5XK3ttexQMeAKeIVtlyb6PwguuADLR1ua	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUHg3amVYR3lFMlRJVHp5V3ZjbDVBTEtTakRIMW9BRElQSllLN0czMiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc2VwZXRhay5vcmcvaGFsYW1hbi9rb250YWsiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776362910
cKgE6XGR1oh85iO3kafb1QeFpr3lZaWxjBsMV1SB	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoickJlSWd5Y1BmZGJoOVBKS0ZSWE1LaTFSOVdkczdXcVFtWjRVVTV3ZiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjg6Imh0dHBzOi8vc2VwZXRhay5vcmcvZmVlZC54bWwiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776362910
Gbzqqs8A3MxguhIO8L3Y0hMNBPnL0IBNPr0GJtvM	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiNVlNWG0xNXZDUVlUcFgzSW5XTW42dzk4MHBvSmx0VnpzMVNKelNVRSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vc2VwZXRhay5vcmcvc2l0ZW1hcC54bWwiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776362910
aXvn0ClBCu7DOcAtxxybgt8ejl4Bg066ytX68JKI	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoicER4eko2cFVtRUVNSzNJRGxOSEhHQVRVU1E3b2hRUkozeGpyNTVQUSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvaGVhbHRoIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776362910
ENIbhjo0amsW49CFkbgL8RB6gDT85n7GmbRnqhSd	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQVhqeGp1UEJHYzdEOFFpeUxYMEtPYTVtWXpNZEdtOXNWVzg2RENRSCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vc2VwZXRhay5vcmcvYWRtaW4vbG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776362910
CFHe66CBajJPjWpEvSEYdmkzyjDwsnAJOy91OuUD	\N	3.230.125.58	got (https://github.com/sindresorhus/got)	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiOUVhQ2JHajdGWlhUWVd6dEZXVWFNZ3pGanJ5cnRGRndMQ0g0Q1BiMSI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czozODoiaHR0cHM6Ly9zZXBldGFrLm9yZy9hZG1pbi9wb3N0cy9jcmVhdGUiO31zOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czozODoiaHR0cHM6Ly9zZXBldGFrLm9yZy9hZG1pbi9wb3N0cy9jcmVhdGUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776366185
Cb4SEe7RgSnLKOi0mJbD6uonL3rRrnU2qveAXW6D	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiOTdwRHJDSkcybElId2FxZERkQlN5eHdOR3RuV0Y1UkVoS0FSbTF1WCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vc2VwZXRhay5vcmcvYWRtaW4vbG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776366484
6nRLZEWwQ2YD1W2DhjWlLprhBfhhA38KSHMJ68QI	\N	34.69.11.156	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.137 Safari/4E423F	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTGltVjc2cG1UY05TVkVzSzRJWlh2Q1NpbWpGaFVjNWRudVVNTHhZRCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776366524
Y0YrZ5DGimbY4v2JOGDu6fqxVPShFtiqA8o56tKt	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoib2JNTFZtaU1selY2TEZlcEw0enoxdE96RjhRMmlubGI5Rmt6U1dnUCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776363606
vMRHqdutzwi4y0JXTvBUwx6jAmo4NlZFttVhleRC	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiWWpXcWlWYVJuTmRZUlJOU3RpeGhFaVhWMlludkRxWG1UQ1pKRnUxQyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvYmVyaXRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776363606
8aAr76h9plcNyqb9bIMxcdZYimrNYm3qU0nuBZZ1	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVXd5Q09WQ3BEU0dhZ1A0bG9KNmU2VmVOTmlySVY2VmJUcE5xY3FjTCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc2VwZXRhay5vcmcvZGFmdGFyLWFuZ2dvdGEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776363606
f65eUSi4cWzPWOGK1xEiHfjMudGTfA6I9IaH1mPq	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSThVeXFtS0lPTGYzVWU5MFNWWWhvd1NLb2xTTFFqdklkVFBhaUJ1cyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDA6Imh0dHBzOi8vc2VwZXRhay5vcmcvaGFsYW1hbi90ZW50YW5nLWthbWkiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776363606
aoTvIW9sVN0kYPZG9AAYGThGwGBWyeThAAcTIBOy	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiREtDenVKbFNWaGszUHAzeDAxVzVsZGVZYUlzd2ZyZkZUenBBa08wcSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzU6Imh0dHBzOi8vc2VwZXRhay5vcmcvaGFsYW1hbi9zZWphcmFoIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776363606
cWFpCHqyWAThEr0HcLxkZc1LldyZf0HK3FULR4L6	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZ0dhdnE2azFlM1hIUGhKa3MxMTRHZFVheHM2elV4azY1OE9MWXJLSyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776363606
ehRpJg2PHaWA2kQlsnvu9dcCaH0YrydntizKcCBN	\N	169.150.201.27	Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQW1kNGxqckJpWXI3VnJIMHBoU2dhMHJ3dFoyTTYxTzcydEhOVXpGMSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776363865
7V5TxYrK5iPrRZNvbCJXSA7JREZQeDjhpUYJNulT	\N	169.150.201.27	Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiWnd5aGw3TnRtTXV0R1h1bjN5NDRhV012Mmh5TlROeEd3a3VIUEwwQyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjg6Imh0dHBzOi8vc2VwZXRhay5vcmcvZmVlZC54bWwiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776363873
wZvNGuPNEsRPMQGggEwDwrIY2Y1ShWJLP4Yeg4Bk	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVjdCU29HSWJZaXhQTXZRVXc3dTdTRHptRWVxRjlQZHFiUWtoZUNSeiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776363985
nq7NuNIyqJkXmtkBcGvwt83YOKnkWC6qnUj9myZ5	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMUN1Q0U3QVFsR05XbElyUTRmS1lMQjVQWmhMV0JQdzVhQk5Wc045SSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364451
wyH8VizaRx1M29LXzBeXthJsltax45FsS3bPTcL4	\N	72.61.143.92	curl/8.14.1	YToyOntzOjY6Il90b2tlbiI7czo0MDoiNnljeUE5emdMNndqUDh6NW1FNk1iMjFFQ2lvNWNUNUpWZHFKRnBLNyI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776364456
00RyQnVg5WDBsPXRZJEb2G3Fvp8dgEagOWkEpGWx	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoid1NZT1BCTjc2U0JhRFpaYkFkbVRsV3lLOVlTU1lJYmxwejRHcUo3eiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364456
hY5v85HpzBWPIMe83pt6YmKKc1nKkfHeEhwr49ZP	\N	72.61.143.92	curl/8.14.1	YToyOntzOjY6Il90b2tlbiI7czo0MDoiZXp3TElZYk82ZXN3RWdNUmVlQnpPSU8zdTFPUGtKcjRPa0R6QTM3dCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776364493
Y8UXSiwvlzWoh2KksRjbmCuCFWXNz78IJQBn0qmu	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUUlJeW84bzJzbVFDRDk1MkxGZ2k2RlRnSDFiT0ZKYTVsQVNuNE5pciI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364493
Tsl6zfd7RWhgKRjaZoxWPAyqaiT7CyRNRo5bgNk9	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSUFrU1dXbmJHOXBtTVEyU2s1cFJNN1FZd1VjNmhYajJxM2J1OGRzZCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364503
iUtTvu8vHl0QRW9ZxEcyYSDdnvQCyIzAUpSe2Riy	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoibUlFU1pWb1pqcEFnZHlQR0dEa0o5Z3oybDRKYm1xVUYxQWhOTElQMCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvYmVyaXRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776364503
Qa3i1fCfzar2HO8uyIxxGj2adYdhpdHKU2AaYiXY	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoia1RBNGZrVEJPUEE0UmtiWWgzUEVpUUpWMkJCYmc0WVBuTzFIbU1vaCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc2VwZXRhay5vcmcvZGFmdGFyLWFuZ2dvdGEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364504
X6sHgJnUueItmpc3bA8dsLotZbIYPgkegxaqfYOM	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZE1MbkFISUFDelVQcWNEMzN4cUtCNzdjNzN1RmI1Z1FDaVRmMEdQQyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364511
onWNNaPtjv1VnsnVhRlRE450p6vJPdhrfWNdDoJR	\N	72.61.143.92	curl/8.14.1	YToyOntzOjY6Il90b2tlbiI7czo0MDoiZkVsaDNGWm13VHBwQkNsMkszTzZOSVl3aTJsejhaVFJjVlFhdDQyMiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776364527
cu0oYRVlutSYrXRSIJeDXw2Sxa6d5h3YMNjjOdFV	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSVo5dm8yb0dXY2lFY1NJRVVFWVVRSEFOVnQwRmRXNUc2Sk1Rc25UViI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364527
2UF26ItClpHm8Lb7d10tfr4trvlwwvAOUIPmiXvV	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoibEVFanpQNnlMNW5Ub0JaWkE3akp5R0JoN2ZNVFd0dVJTTGlxY2xMbyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364537
DDCBExqCcpsudGkfgsKtyjWLqrTfNsdfAxhpYEmy	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiWGZqaDlMaHp5dHg2Uk5iWmxUZm5nZmNibDBMYzlWVDloSHpSaW9nWCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364537
LzfqFWMEjDonBVVDgVZl52JWl4HpxNdyktt1EmsF	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSzNSZmpRQVRRRG5qVzVVZ1c5a3Q4Qkk0Y3VVcFRKRkJyRFhlckQxNiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvYmVyaXRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776364537
L1J0F6o2X70tgZCjtS5UFfRCSd9kMT0auQQwCrHI	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZ0FseTZ1cWlLU0NuTHVYNWVOZk9KOUJRTzVzM2FFTGlsWVRkbm5BMiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc2VwZXRhay5vcmcvZGFmdGFyLWFuZ2dvdGEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364537
IjjaycxFJ88VYmTjZY7aUFZ0gAWwvrO2SYKZT42E	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiWmxoZnFYNzFYdlFXWUVhSkw4d011R2lreEVlNkhNeUM1ZlVTSnJWdSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364537
d5OlRoasHD6svln4KHjpS2jEzOxJUhoKofAVtQwO	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVlpFclZlQ1hsckwzUVJadXNKRG10Z2UwUll2S1o3VzBLOXhRc2Y0OCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvYmVyaXRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776364537
HOmybXWQ2ISzsEkt8hJUhc0rRNVMzzVVFJBuzlRg	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoicEE3NVBOQ1V3Y1ZUaHhOdEIxS0tHZzVHeEs4SDE4a0QyMm9qWDJDViI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc2VwZXRhay5vcmcvZGFmdGFyLWFuZ2dvdGEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364537
oJHNu2YnYK0yR7yerS9wIn7UzUYoltsgr3dRaPLp	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiOFE2OEVUZlJGSnA3bHpLS3l1b0x1eFRBT3lNTUlqMU9uZ1h1TVJadSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364538
jSiaQBW4SWUAdmBIT3SEDsorI21nmlzNmN2o4U5y	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUlhtMDl0bU85NVBsczdhTGVaeTlqVkhVam1rcVdDZFR3WFVNNEJDcyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvYmVyaXRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776364538
KwE8x7xpyWDCZscQW5Xo8B4xwZH2VOsDxrHnWS4O	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZHpqUE5TdVlEZ1JnYUttZmcyZHFSdDVoNVIxbUNUMkdGRjdRcGtLMiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc2VwZXRhay5vcmcvZGFmdGFyLWFuZ2dvdGEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364538
6I5Jri4Zfjx0rCE7laPW0KZnsZRcyycIMjIl0rnn	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiN241MUp3bXphckI4aWlvdUloeDFEa2NkT2FDVU1od3ZqZXREa3E0VyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364538
ykFs39jDaVL8tqYLz4TaGoGr5ygjDfbb2YB56ERP	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoicEZ6OU15NHVzbjREVXhua01mSlNkVlA0YmN2YlVBeWdzTHZTVWpKbyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvYmVyaXRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776364538
MH4JYSvrx03Z92MMWOQX0HwRugWX0vGBWNH9zxbb	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoidm5NSXFoTVJSSGlsUUxESHM0TzlKeDZnZmUyTmszNkRYTmhLZFNadiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc2VwZXRhay5vcmcvZGFmdGFyLWFuZ2dvdGEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364538
qFOLshTgFE4QHG3Pc8TH1kU65WnW6xsa7TIrVlT4	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSGdmbkdrOE45SzJ3andNRUs5cDd2bWwzcmxaTjZmYnE4d0VDYTRhaSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364538
kgl7fYnCtF9dMCtN2oi5zcQc2fdlxOiZ8AtlfmTf	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiM1d0TUplYmhFblhvQVA3aFpkU0VwR0xNdkxJOWtwTmFJVHEyOWQ4YyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvYmVyaXRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776364538
ly9NPjCGUTQxidUWorMDRMKNZeuzHa6MramBOGO7	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTW1MR1d2VUpUamtTb3VDU052cXpjeG5XM0dSYjJ6QmFGcGJldWRNSCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc2VwZXRhay5vcmcvZGFmdGFyLWFuZ2dvdGEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364538
JhlI4N38MEwjbvXz5co6TFf06zeWNca72Xr4k8uS	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTWJTWmNKYlY1TnZaMm5USm84TkVlcnZ6TlFHdEJpMzNhUXd0Wmd1cCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364538
SrgtiMB1slCy7OB3Gmcy0EGAa5NPMjs3PXEeheXH	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiRUIxcUI0SGhNS284a0J2MlhidndGS2ZqdTNDNXp2a0gxZENkQkRieSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvYmVyaXRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776364538
URKRHqQbSUKUojz0dTdsT42p9UWG2GM2wsxDwZwl	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQTZ0akN2UTRoY0JQdExZek5yVUx1cW5YcGwxNHREbkRpNmtEZmlUWiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc2VwZXRhay5vcmcvZGFmdGFyLWFuZ2dvdGEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364538
XPqgz4ZZAXSoZMq5SRjDjD2fcwoenyru8TEFoNWW	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMnFwbzlzWHNTN0lqTDF0SkQ2MktFZU1HVnJwUWNnVFp4c0tOeXR1SiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364538
QAOf4AEmGYzzWy9bTHlqgVxB0WetJ9TNDETwQ9Ef	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiY2c4dzhzZ2M2Y0x6R3ZTUE9JOUEyY0Y5eVpqUm1Qd3ZncktTR3AyQSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvYmVyaXRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776364538
8YNtAsFOeOAeztbKXgQw09nkxBcUkgAJKnLuzYG8	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiS1N4T1V3QUtyT2tzTHhFWjdSaWEzc0R0MHpNQ2xpUWpicTVOVExwYSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc2VwZXRhay5vcmcvZGFmdGFyLWFuZ2dvdGEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364538
Ja8Y25act01sFK9CgyFtMf40DEZWEQtzPi8dewYL	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoieTJLZkE1VWxQOW1UUlZ0Y0Z4QXljUWpjbk15WUpsRWIyUGRHWmkwdSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364539
lz6c2Xd0821UA4rpaoUVgXN20N1brITu2TUoSCQT	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQ0VEVUhwaTJjT3MzQWRkQjZKTDMzUDJ0eG1vWGtDVXBsSXdDSmJjNCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvYmVyaXRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776364539
MVH5WPLafev5j34u50eoIMue563fb2twmLOQq5RT	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSjlaQjhGaW9GYWR0d0tyYjMzaVNWNlZseWhXM0V6aEpuOU5pdlpOZCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc2VwZXRhay5vcmcvZGFmdGFyLWFuZ2dvdGEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364539
bJRVie0Ia23S0GAXPsQqApEMbpRXV25moJ0RZGZZ	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTlJWYVQwMGtkbW0xSHVZTlVob0toa0ltek04ZlBPVlpSNFZTQXVWSSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364539
rFSjNxKfHzJAJ3Mp3tQSyhghYufXzLyyC0NrbXeQ	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiekV2blF2V2ZpeFhuVEtOelN5dDl5SmszamRVNTcyUjAzV09kTjIwViI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvYmVyaXRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776364539
tNtj4fSxA4LmX8CZnCxXqf7C2GvS8fEO1qyIjWip	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUjk5VlNUS2lJVXlib1EwNlJLaVVnSVpxTXltQ2JsdU0zRlpaQjAwUiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc2VwZXRhay5vcmcvZGFmdGFyLWFuZ2dvdGEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364539
In84OaGzDZVqcgiSLY7Rmn0oVm1dwiCD7NodnHmK	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiU0M0UHVvTHI3dmlRZ0Z1VkcyZXk2R1pWdGVVZkR5QWo2TjNUcXpLaiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364539
5nYUZRZkBHy9vg48aFeqlhlmpzFv16t7AGgT3zH8	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiYU5FR3U0dngxZVU2WG9BZkVxbThZbFVqT0ZUVGZpTFNMYnZHNnJyNSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvYmVyaXRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776364539
JlS6kyTRtmRexsxCwS7bKH4rXw0HBZPHduEwEbPD	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiOGNRNXh4OFh4WU82WnA1bUlpdmJKeWFCMnBrM1NqT2FZdUw5SFVjeCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc2VwZXRhay5vcmcvZGFmdGFyLWFuZ2dvdGEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364539
Fla6Or1lnaMr342GOmm4V1ZY8gVpfLrPEFG6tQBn	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSmJYMW81Z0xTa3NBN3Mwb3d1Q0pOVDlad3c5RUh1Qnhzd21DS2dWSCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364539
zDRxiU1Y3iljc4qHBGAgGFrQ2807qYLYil0G2IhW	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoib0h5blp1WU5FbXltMUhJZWY5YzRpR2U4cFRJZThpRG5QM29BRDV0aiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvYmVyaXRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776364539
aAFgUOzg8qDlKI0p1KF8wmKbwJhX3ToXdTnw4xeL	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoid29pTWxLN3VwNktCVkhLTHRwMTJsME44T3h0ZzlzSms4OTlYNVE5OCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc2VwZXRhay5vcmcvZGFmdGFyLWFuZ2dvdGEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364539
xuhP9nmb9Yi0RQ9XD1SvndxHKdmagQ2OgQ8xrAK5	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoibFlxYlhWbzhkTUhKYlNmaFhyUDB3VHVsemtaTXJDWmQxd2l3dEFxNyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364539
sbMcrumFsmMzr3vkIiSevls4TmBw0xBoaCI7gFSe	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoid1UzSEVPWWNrQVNrMEI3eEd4RGlSYnhLekJwaTRJQ2Q2M0NYTHhRYSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvYmVyaXRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776364539
OoSFhv5IbUSHVth3gVhsY2gG3cC6iMD0Pi3sF7iR	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMjFrZ3p6WndkTzFCbzVkalc2dXdtVU9pZVM5dVdZdkVQbmo3cXh0NSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc2VwZXRhay5vcmcvZGFmdGFyLWFuZ2dvdGEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364540
bSaGLecfHX9nwHCJlYasZ35kZEBlbO9cZWL1UbrB	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiclJocm5VaHU0UXFEVkhCTlNEQkdyVUxkZWRuNzlESjdRbWNndGNVViI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364540
aPA965HtxYRtryJzXglAKtHwZ4dZCgkKSlBFB1sc	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUVZxM3IxQ0YwZjJ5NU1RekkxNVRKbGpObGZDNnVQUGFPaXhyemlTeCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvYmVyaXRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776364540
XBOt1cbB91YFwHlcxBmBL1z6gLmySBVSszZh9x3b	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoibnFGN3FsSXNHR1loVDdQMlFwSFpSb1ZubXdid3BLTGRCV0Z5NTBaMCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc2VwZXRhay5vcmcvZGFmdGFyLWFuZ2dvdGEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364540
V5sSu48CNuZTIdbEq50xlFtxUPffwo2UfxTtchtn	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiV3dUYXZ3RHIyZEU1eUxFWVgwZFlrN2JwYlpiTGVBVHdpNG9wTTRRYiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364540
Fc6BbCKdTe5nWF1cwQEADP7NwkC2cPPlWAEtDAC6	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoibTQwM1o2clcwbDNZbFVJcDkwR2JKcDVyVklwb254ajZCWERhcnZBTiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvYmVyaXRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776364540
mIE7RWHyfW8hEPRXNNAEygFxPYkhd91tvbsKyzxl	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQjNESVFmQWw0eEZPWXVxbGR3U2dZcjlQWEI5WlBTbGFmRXdnZUJneiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc2VwZXRhay5vcmcvZGFmdGFyLWFuZ2dvdGEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364540
N2ZUPoeAJclsczNty5BSqYdAoWv9Tvg2T183f08m	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoielJBWEFwd3EzUDBPMDZ5V241cEhZaW1ZclRUYW9YR1FmNHJyamlxVyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364540
10GlcLRI5lGNngde8Xrx09hNkyEgezGiPZqAKIYV	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSGxRcnBSMFBrRUtzeUlPdk1yTjJUcFdlRWh2SW1mUlR1MlE4YkxTZSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvYmVyaXRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776364540
B7evVgQQdDNpp4orF1sWpkV3KZMpgI6KO1pDTir3	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZUs3dmVlbXhlNjFsczNhSk80elJmcWFVbUxzY0hKbk5ianViTmtzSSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc2VwZXRhay5vcmcvZGFmdGFyLWFuZ2dvdGEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364540
AaIt9hZMfApD0alZvi9qbjfHNDEOKw3Yxol0FA5H	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoidlRUek5SU3dCRmg2dEh6UHRFZ1RMUmNYaWNNcGJaUklpNEsyblJZSCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364540
BHScw3nRGKfAvSjLet0wJk5zz1DpeIiJKEKu4nM3	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUDdOSWxoVVVCMExyVmJzaXp0ZXp3WDRaSHgyYk4xczY1cWR1QjNTayI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvYmVyaXRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776364540
BtJw3w50NQ66MfETGk1xq0f1buvn52ijauLpofVt	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVVAxQXdtampSZVRTUGlVbnpkRWR3dTJzVll6aEFMTVdhTHJKT2UxWiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc2VwZXRhay5vcmcvZGFmdGFyLWFuZ2dvdGEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364540
X7zSt4X5vgWtJ61cTyXtRHtO0t2xMmGhoWJJKQLD	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoidDVnaVpncVdqZ0dnMHZEbm1IZ2x0dHo5a0lHUGQ2STdDWmFZVFRSbiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364540
SPabTULLxcxxx7GHrPqT5uLoGLiIoAPxHcT2y452	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSnJ1Z3ZrbGJHZFFCanp2NmI2Y2p6SWZPZFlrQ2lleDBnMjJaa1JueCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvYmVyaXRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776364540
3qEO5v4lDHNPmxmI0xdwPP6pe9e1A5d1NhYIo7uC	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiRjFhU0Y5UmhHZmRLUzVqMlV2QVpFdGxXQ1VSOWlWZjlhTFJjTUN5TCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc2VwZXRhay5vcmcvZGFmdGFyLWFuZ2dvdGEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364541
rv7MB3mIrHNmWe1tNo2x3n6KO9jUlLMSXVDItsFv	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoib1l4bWVncXBqUk5jeXM5czdwbnNBdnlrNlFGaWFWelpscmxKVFhFdiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364854
wwp2hl37RTb0ou4IMlG6CFJZNyPhs5QTZJvs5fau	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQnQwREFrWFZGMmZyR3hUUDNaUG5ESVVTa0JnZU44SDh3bUJkZkxaUiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc2VwZXRhay5vcmcvYmVyaXRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776364854
dD2FSSUdmNb0QUZlxBJK3AoFlg4G66rL1gPkKyh7	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoidENGUDIyRmRwNGlQdlJXdlRTY3V3Y2JibzVraHRnVHNWSm1aYlBPayI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc2VwZXRhay5vcmcvZGFmdGFyLWFuZ2dvdGEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364854
TOPa1pVbugRVvC1obWoIbQk22BeWPrE9cH4qhC1e	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoidHZlV0dCWGRPNHNhWnFRTElhV0p3R3ByeGJESVFndDJVcFRTYTBUayI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776364854
p8lQwB4MIDdaSBNdBvxD6CCoj7hSplDQTmvIS3Oj	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiYWEyUVJESGFreGFrejlWeHJlWVRpWnRza3VxVW1sYktqbGE2MFlwYyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776365259
eaF1AgyrSYGe6k3HdGNWlDjcVVjwaoBsqyXUMZTH	\N	45.198.11.249	WhatsApp/2.23.20.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSFpBY3ZMcEp5TEpZMWd6bFFZTXVOQXpSMjhDNGhkMXBtcFZxbERjYiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776365284
Hug1A7f75XEQVnAiNtKLyQ91G7DgJZjtlAdwB7eQ	\N	198.13.159.15	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Safari/605.1.15	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQlo1TlozcXFtcW4xdlF6UXRxN3ZDclVFMEhRVmNQSlFxS042cHZJYiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776365372
PozuyEWoVpr4SFHNdOm7XLIQysGxFwmUtQT0mgVV	\N	45.198.11.249	WhatsApp/2.23.20.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiWXZpbnFWcUp0MU5GSWFpRXVIYVVYZk9VVzMwVTBtd1Q2WEJoTUYyTyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc2VwZXRhay5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776365393
biJLJrcMwv5clRKwsczg5JWR4tlFvC6tcBio9Crb	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMEVabzA1WENGT3BXNnpBVmlKREhIdmlJQ3FTSW5SczZTZVdaZ3gyaiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vc2VwZXRhay5vcmcvYWRtaW4vbG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776365715
Xml5U37HaJcVXsLo2vpZVxd4Ug7jV9tkmNyJAXa4	\N	72.61.143.92	curl/8.14.1	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiOXJWSElTRW9Pc3ZmSVkya0wzSWpUSmFUQXlVaWJJVXpWVExUOVF3aSI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czoyNToiaHR0cHM6Ly9zZXBldGFrLm9yZy9hZG1pbiI7fXM6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjI1OiJodHRwczovL3NlcGV0YWsub3JnL2FkbWluIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776365741
bipUkYzqrkzUuRdb9I3VD4jjCzz4waEt3xzHAtXM	\N	72.61.143.92	curl/8.14.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiaGRKYkpuT3pnOEdwT3pKUGE4T2tERm9DbHV0M3RsbGJ3Z0hDeDY4MSI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czoxOToiaHR0cHM6Ly9zZXBldGFrLm9yZyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776365741
\.


--
-- Data for Name: site_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.site_settings (id, setting_key, setting_value, group_name, created_at, updated_at) FROM stdin;
4	contact_email	info@sepetak.org	contact	2026-04-16 15:32:51	2026-04-16 15:32:51
7	social_facebook		social	2026-04-16 15:32:51	2026-04-16 15:32:51
8	social_instagram		social	2026-04-16 15:32:51	2026-04-16 15:32:51
9	social_twitter		social	2026-04-16 15:32:51	2026-04-16 15:32:51
1	site_name	SEPETAK - Serikat Pekerja Tani Karawang	general	2026-04-16 15:32:51	2026-04-16 16:32:49
6	contact_address	Kabupaten Karawang, Jawa Barat, Indonesia	contact	2026-04-16 15:32:51	2026-04-16 16:32:49
2	site_tagline	Rebut Kedaulatan Agraria, Bangun Industrialisasi Pertanian	general	2026-04-16 15:32:51	2026-04-16 16:44:51
3	site_description	SEPETAK (Serikat Pekerja Tani Karawang) adalah organisasi massa berbasis pekerja tani dan nelayan di Kabupaten Karawang, Jawa Barat, yang memperjuangkan TANI MOTEKAR (Tanah, Infrastruktur, Modal, Teknologi, Akses Pasar) sejak 10 Desember 2007.	general	2026-04-16 15:32:51	2026-04-16 16:44:51
5	contact_phone		contact	2026-04-16 15:32:51	2026-04-16 16:44:51
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tags (id, name, slug, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, name, email, email_verified_at, password, remember_token, is_active, last_login_at, created_at, updated_at, deleted_at) FROM stdin;
1	Administrator SEPETAK	admin@sepetak.org	\N	$2y$12$XuvTbmMi6JSD0BHk/1erBer1BCa5kcimAG6M/BHwjhD2QvTYk1Eia	UDUoSqWSsotNsM5SPWbKFpDyx1SI0S5q6FOHRwex3t0pmMX5zR9txXpTHFbQ	t	\N	2026-04-16 15:32:51	2026-04-17 00:32:25	\N
28	Smoke Test	smoke-test@sepetak.local	\N	$2y$12$B/tpk5Jz8jV1qdQFJyE5TexJoUa2cgsmH40GgoaWus7xBFfqIp8K2	\N	t	\N	2026-04-17 02:08:25	2026-04-17 02:10:09	2026-04-17 02:10:09
2	Redaksi SEPETAK	redaksi@sepetak.org	\N	$2y$12$1kfq1dWXIBS3ct8laJV/leuqaBvBVLkALbcPmXfvVb8TZ/FHkeKai	\N	t	\N	2026-04-16 16:08:01	2026-04-17 00:32:25	\N
3	Akun Viewer SEPETAK	publik@sepetak.org	\N	$2y$12$D3/JPwe5cavrjMevfR1yV.ctz9qWAVfXPM2CTpQWWzGobOcB9GGPq	\N	t	\N	2026-04-16 16:08:01	2026-04-17 00:32:25	\N
\.


--
-- Name: addresses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.addresses_id_seq', 2, true);


--
-- Name: advocacy_actions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.advocacy_actions_id_seq', 8, true);


--
-- Name: advocacy_programs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.advocacy_programs_id_seq', 5, true);


--
-- Name: agrarian_case_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agrarian_case_files_id_seq', 1, false);


--
-- Name: agrarian_case_parties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agrarian_case_parties_id_seq', 7, true);


--
-- Name: agrarian_case_updates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agrarian_case_updates_id_seq', 1, false);


--
-- Name: agrarian_cases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agrarian_cases_id_seq', 11, true);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 1, false);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.categories_id_seq', 5, true);


--
-- Name: event_attendance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.event_attendance_id_seq', 1, true);


--
-- Name: events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.events_id_seq', 2, true);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.jobs_id_seq', 1, false);


--
-- Name: media_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.media_id_seq', 1, false);


--
-- Name: member_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_documents_id_seq', 1, false);


--
-- Name: members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.members_id_seq', 12, true);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.migrations_id_seq', 25, true);


--
-- Name: pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pages_id_seq', 7, true);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.permissions_id_seq', 7, true);


--
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.posts_id_seq', 10, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.roles_id_seq', 4, true);


--
-- Name: site_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.site_settings_id_seq', 11, true);


--
-- Name: tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tags_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 28, true);


--
-- Name: addresses addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.addresses
    ADD CONSTRAINT addresses_pkey PRIMARY KEY (id);


--
-- Name: advocacy_actions advocacy_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.advocacy_actions
    ADD CONSTRAINT advocacy_actions_pkey PRIMARY KEY (id);


--
-- Name: advocacy_programs advocacy_programs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.advocacy_programs
    ADD CONSTRAINT advocacy_programs_pkey PRIMARY KEY (id);


--
-- Name: advocacy_programs advocacy_programs_program_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.advocacy_programs
    ADD CONSTRAINT advocacy_programs_program_code_unique UNIQUE (program_code);


--
-- Name: agrarian_case_files agrarian_case_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_case_files
    ADD CONSTRAINT agrarian_case_files_pkey PRIMARY KEY (id);


--
-- Name: agrarian_case_parties agrarian_case_parties_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_case_parties
    ADD CONSTRAINT agrarian_case_parties_pkey PRIMARY KEY (id);


--
-- Name: agrarian_case_updates agrarian_case_updates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_case_updates
    ADD CONSTRAINT agrarian_case_updates_pkey PRIMARY KEY (id);


--
-- Name: agrarian_cases agrarian_cases_case_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_cases
    ADD CONSTRAINT agrarian_cases_case_code_unique UNIQUE (case_code);


--
-- Name: agrarian_cases agrarian_cases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_cases
    ADD CONSTRAINT agrarian_cases_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: cache_locks cache_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cache_locks
    ADD CONSTRAINT cache_locks_pkey PRIMARY KEY (key);


--
-- Name: cache cache_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cache
    ADD CONSTRAINT cache_pkey PRIMARY KEY (key);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: categories categories_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_slug_unique UNIQUE (slug);


--
-- Name: event_attendance event_attendance_event_id_member_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_attendance
    ADD CONSTRAINT event_attendance_event_id_member_id_unique UNIQUE (event_id, member_id);


--
-- Name: event_attendance event_attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_attendance
    ADD CONSTRAINT event_attendance_pkey PRIMARY KEY (id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: job_batches job_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_batches
    ADD CONSTRAINT job_batches_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: media media_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_pkey PRIMARY KEY (id);


--
-- Name: media media_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_uuid_unique UNIQUE (uuid);


--
-- Name: member_documents member_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_documents
    ADD CONSTRAINT member_documents_pkey PRIMARY KEY (id);


--
-- Name: members members_member_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_member_code_unique UNIQUE (member_code);


--
-- Name: members members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: model_has_permissions model_has_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_has_permissions
    ADD CONSTRAINT model_has_permissions_pkey PRIMARY KEY (permission_id, model_id, model_type);


--
-- Name: model_has_roles model_has_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_has_roles
    ADD CONSTRAINT model_has_roles_pkey PRIMARY KEY (role_id, model_id, model_type);


--
-- Name: pages pages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_pkey PRIMARY KEY (id);


--
-- Name: pages pages_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_unique UNIQUE (slug);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


--
-- Name: permissions permissions_name_guard_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_name_guard_name_unique UNIQUE (name, guard_name);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: post_category post_category_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_category
    ADD CONSTRAINT post_category_pkey PRIMARY KEY (post_id, category_id);


--
-- Name: post_tag post_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_tag
    ADD CONSTRAINT post_tag_pkey PRIMARY KEY (post_id, tag_id);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- Name: posts posts_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_slug_unique UNIQUE (slug);


--
-- Name: role_has_permissions role_has_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_pkey PRIMARY KEY (permission_id, role_id);


--
-- Name: roles roles_name_guard_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_guard_name_unique UNIQUE (name, guard_name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: site_settings site_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_settings
    ADD CONSTRAINT site_settings_pkey PRIMARY KEY (id);


--
-- Name: site_settings site_settings_setting_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_settings
    ADD CONSTRAINT site_settings_setting_key_unique UNIQUE (setting_key);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: tags tags_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_slug_unique UNIQUE (slug);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: jobs_queue_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX jobs_queue_index ON public.jobs USING btree (queue);


--
-- Name: media_model_type_model_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX media_model_type_model_id_index ON public.media USING btree (model_type, model_id);


--
-- Name: media_order_column_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX media_order_column_index ON public.media USING btree (order_column);


--
-- Name: model_has_permissions_model_id_model_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_has_permissions_model_id_model_type_index ON public.model_has_permissions USING btree (model_id, model_type);


--
-- Name: model_has_roles_model_id_model_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_has_roles_model_id_model_type_index ON public.model_has_roles USING btree (model_id, model_type);


--
-- Name: sessions_last_activity_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_last_activity_index ON public.sessions USING btree (last_activity);


--
-- Name: sessions_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_user_id_index ON public.sessions USING btree (user_id);


--
-- Name: advocacy_actions advocacy_actions_advocacy_program_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.advocacy_actions
    ADD CONSTRAINT advocacy_actions_advocacy_program_id_foreign FOREIGN KEY (advocacy_program_id) REFERENCES public.advocacy_programs(id) ON DELETE CASCADE;


--
-- Name: advocacy_actions advocacy_actions_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.advocacy_actions
    ADD CONSTRAINT advocacy_actions_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: advocacy_programs advocacy_programs_lead_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.advocacy_programs
    ADD CONSTRAINT advocacy_programs_lead_user_id_foreign FOREIGN KEY (lead_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: agrarian_case_files agrarian_case_files_agrarian_case_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_case_files
    ADD CONSTRAINT agrarian_case_files_agrarian_case_id_foreign FOREIGN KEY (agrarian_case_id) REFERENCES public.agrarian_cases(id) ON DELETE CASCADE;


--
-- Name: agrarian_case_parties agrarian_case_parties_agrarian_case_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_case_parties
    ADD CONSTRAINT agrarian_case_parties_agrarian_case_id_foreign FOREIGN KEY (agrarian_case_id) REFERENCES public.agrarian_cases(id) ON DELETE CASCADE;


--
-- Name: agrarian_case_updates agrarian_case_updates_agrarian_case_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_case_updates
    ADD CONSTRAINT agrarian_case_updates_agrarian_case_id_foreign FOREIGN KEY (agrarian_case_id) REFERENCES public.agrarian_cases(id) ON DELETE CASCADE;


--
-- Name: agrarian_case_updates agrarian_case_updates_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_case_updates
    ADD CONSTRAINT agrarian_case_updates_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: agrarian_cases agrarian_cases_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_cases
    ADD CONSTRAINT agrarian_cases_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: agrarian_cases agrarian_cases_lead_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_cases
    ADD CONSTRAINT agrarian_cases_lead_user_id_foreign FOREIGN KEY (lead_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: agrarian_cases agrarian_cases_updated_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agrarian_cases
    ADD CONSTRAINT agrarian_cases_updated_by_foreign FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_logs audit_logs_actor_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_actor_id_foreign FOREIGN KEY (actor_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: event_attendance event_attendance_event_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_attendance
    ADD CONSTRAINT event_attendance_event_id_foreign FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: event_attendance event_attendance_member_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_attendance
    ADD CONSTRAINT event_attendance_member_id_foreign FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: events events_organizer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_organizer_id_foreign FOREIGN KEY (organizer_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: member_documents member_documents_member_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_documents
    ADD CONSTRAINT member_documents_member_id_foreign FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: members members_address_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_address_id_foreign FOREIGN KEY (address_id) REFERENCES public.addresses(id) ON DELETE SET NULL;


--
-- Name: members members_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: members members_updated_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_updated_by_foreign FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: members members_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: model_has_permissions model_has_permissions_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_has_permissions
    ADD CONSTRAINT model_has_permissions_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: model_has_roles model_has_roles_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_has_roles
    ADD CONSTRAINT model_has_roles_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: pages pages_author_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_author_id_foreign FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: post_category post_category_category_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_category
    ADD CONSTRAINT post_category_category_id_foreign FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: post_category post_category_post_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_category
    ADD CONSTRAINT post_category_post_id_foreign FOREIGN KEY (post_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: post_tag post_tag_post_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_tag
    ADD CONSTRAINT post_tag_post_id_foreign FOREIGN KEY (post_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: post_tag post_tag_tag_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_tag
    ADD CONSTRAINT post_tag_tag_id_foreign FOREIGN KEY (tag_id) REFERENCES public.tags(id) ON DELETE CASCADE;


--
-- Name: posts posts_author_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_author_id_foreign FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: role_has_permissions role_has_permissions_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_has_permissions role_has_permissions_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict v2IsFGoLtc2UHKmNdwgB9VbftfLqY0ZYoLG1wFmHiYiKPhQcfgCoCc8zWmaXgbd

